﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmExistingRequestedDescription : Form
    {
        public static string email;
        public frmExistingRequestedDescription()
        {
            InitializeComponent();
        }

        public frmExistingRequestedDescription(string e)
        {
            InitializeComponent();
            email = e;
        }
        private void Existing_Load(object sender, EventArgs e)
        {
            ArrayList arrayService = new ArrayList();
            arrayService = customer.getService(email);

            //service,urgency,date, status, description , orderiD, to pay, amount
            lblServiceRequested.Text = arrayService[0].ToString();
            lblUrgency.Text = arrayService[1].ToString();
            if (arrayService.Count > 2)
            {
                lblDate.Text = arrayService[2].ToString();
                lblStatus.Text = arrayService[3].ToString();
                lblDescription.Text = arrayService[4].ToString();
                lblOrderID.Text = arrayService[5].ToString();
            }
            lblAmount.Text = displayPrice(arrayService[0].ToString(), arrayService[1].ToString());
            lblShowTtlAmount.Text = displayPrice(lblServiceRequested.Text, arrayService[1].ToString());

        }

        public string displayPrice(string service, string urgency)
        {
            string price = "0.00";

            if (service == "Remove virus, malware or spyware" && urgency == "Normal")
                price = "50.00";
            else if (service == "Remove virus, malware or spyware" && urgency == "Urgent")
                price = "80.00";
            else if (service == "Troubleshot and fix computer running slow" && urgency == "Normal")
                price = "60.00";
            else if (service == "Troubleshot and fix computer running slow" && urgency == "Urgent")
                price = "90.00";
            else if (service == "Laptop screen replacement" && urgency == "Normal")
                price = "380.00";
            else if (service == "Laptop screen replacement" && urgency == "Urgent")
                price = "430.00";
            else if (service == "Laptop keyboard replacement" && urgency == "Normal")
                price = "160.00";
            else if (service == "Laptop keyboard replacement" && urgency == "Urgent")
                price = "200.00";
            else if (service == "Laptop battery replacement" && urgency == "Normal")
                price = "180.00";
            else if (service == "Laptop battery replacement" && urgency == "Urgent")
                price = "210.00";
            else if (service == "Operating System Format and Installation" && urgency == "Normal")
                price = "100.00";
            else if (service == "Operating System Format and Installation" && urgency == "Urgent")
                price = "150.00";
            else if (service == "Data backup and recovery" && urgency == "Normal")
                price = "80.00";
            else if (service == "Data backup and recovery" && urgency == "Urgent")
                price = "130.00";
            else if (service == "Internet connectivity issues" && urgency == "Normal")
                price = "70.00";
            else if (service == "Internet connectivity issues" && urgency == "Urgent")
                price = "100.00";

            return (price);
        }

        private void btnChangeRequest_Click(object sender, EventArgs e)
        {
            if (lblStatus.Text != "complete")
            {
                frmChangeRequestedService obj1 = new frmChangeRequestedService(email);
                obj1.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Unable to update, service has been completed");
            }
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
