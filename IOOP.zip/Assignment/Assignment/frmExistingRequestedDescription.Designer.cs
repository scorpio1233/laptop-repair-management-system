﻿namespace Assignment
{
    partial class frmExistingRequestedDescription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblTtlAmount = new System.Windows.Forms.Label();
            this.btnChangeRequest = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.lblServiceRequested = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblDescription = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblShowTtlAmount = new System.Windows.Forms.Label();
            this.lblUrgency = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(130, 31);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(542, 48);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Existing Requested Description";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Items.AddRange(new object[] {
            " Collection",
            "     Date             Order ID                    Service Request                " +
                "                           To Pay            Status",
            "---------------------------------------------------------------------------------" +
                "---------------------------------------"});
            this.listBox1.Location = new System.Drawing.Point(15, 109);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(858, 154);
            this.listBox1.TabIndex = 1;
            // 
            // lblTtlAmount
            // 
            this.lblTtlAmount.AutoSize = true;
            this.lblTtlAmount.Font = new System.Drawing.Font("Segoe UI Semilight", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblTtlAmount.Location = new System.Drawing.Point(530, 268);
            this.lblTtlAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTtlAmount.Name = "lblTtlAmount";
            this.lblTtlAmount.Size = new System.Drawing.Size(146, 30);
            this.lblTtlAmount.TabIndex = 2;
            this.lblTtlAmount.Text = "Total Amount :";
            // 
            // btnChangeRequest
            // 
            this.btnChangeRequest.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnChangeRequest.Location = new System.Drawing.Point(588, 442);
            this.btnChangeRequest.Margin = new System.Windows.Forms.Padding(4);
            this.btnChangeRequest.Name = "btnChangeRequest";
            this.btnChangeRequest.Size = new System.Drawing.Size(195, 64);
            this.btnChangeRequest.TabIndex = 4;
            this.btnChangeRequest.Text = "Change Request";
            this.btnChangeRequest.UseVisualStyleBackColor = true;
            this.btnChangeRequest.Click += new System.EventHandler(this.btnChangeRequest_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMenu.Location = new System.Drawing.Point(130, 442);
            this.btnMenu.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(186, 64);
            this.btnMenu.TabIndex = 5;
            this.btnMenu.Text = "Back to Menu";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.Snow;
            this.lblDate.Location = new System.Drawing.Point(29, 194);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(19, 25);
            this.lblDate.TabIndex = 7;
            this.lblDate.Text = "-";
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.BackColor = System.Drawing.Color.Snow;
            this.lblOrderID.Location = new System.Drawing.Point(130, 194);
            this.lblOrderID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(19, 25);
            this.lblOrderID.TabIndex = 8;
            this.lblOrderID.Text = "-";
            // 
            // lblServiceRequested
            // 
            this.lblServiceRequested.AutoSize = true;
            this.lblServiceRequested.BackColor = System.Drawing.Color.Snow;
            this.lblServiceRequested.Location = new System.Drawing.Point(260, 194);
            this.lblServiceRequested.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblServiceRequested.Name = "lblServiceRequested";
            this.lblServiceRequested.Size = new System.Drawing.Size(19, 25);
            this.lblServiceRequested.TabIndex = 9;
            this.lblServiceRequested.Text = "-";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.BackColor = System.Drawing.Color.Snow;
            this.lblAmount.Location = new System.Drawing.Point(682, 194);
            this.lblAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(19, 25);
            this.lblAmount.TabIndex = 11;
            this.lblAmount.Text = "-";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.Snow;
            this.lblStatus.Location = new System.Drawing.Point(779, 194);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(19, 25);
            this.lblStatus.TabIndex = 12;
            this.lblStatus.Text = "-";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblDescription);
            this.panel1.Location = new System.Drawing.Point(174, 271);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(312, 156);
            this.panel1.TabIndex = 13;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(4, 12);
            this.lblDescription.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(19, 25);
            this.lblDescription.TabIndex = 0;
            this.lblDescription.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semilight", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(42, 271);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 30);
            this.label9.TabIndex = 14;
            this.label9.Text = "Description :";
            // 
            // lblShowTtlAmount
            // 
            this.lblShowTtlAmount.AutoSize = true;
            this.lblShowTtlAmount.BackColor = System.Drawing.Color.Snow;
            this.lblShowTtlAmount.Location = new System.Drawing.Point(706, 274);
            this.lblShowTtlAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShowTtlAmount.Name = "lblShowTtlAmount";
            this.lblShowTtlAmount.Size = new System.Drawing.Size(19, 25);
            this.lblShowTtlAmount.TabIndex = 15;
            this.lblShowTtlAmount.Text = "-";
            // 
            // lblUrgency
            // 
            this.lblUrgency.AutoSize = true;
            this.lblUrgency.BackColor = System.Drawing.Color.GhostWhite;
            this.lblUrgency.Location = new System.Drawing.Point(381, 228);
            this.lblUrgency.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUrgency.Name = "lblUrgency";
            this.lblUrgency.Size = new System.Drawing.Size(19, 25);
            this.lblUrgency.TabIndex = 16;
            this.lblUrgency.Text = "-";
            // 
            // frmExistingRequestedDescription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(889, 562);
            this.Controls.Add(this.lblUrgency);
            this.Controls.Add(this.lblShowTtlAmount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.lblServiceRequested);
            this.Controls.Add(this.lblOrderID);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnChangeRequest);
            this.Controls.Add(this.lblTtlAmount);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExistingRequestedDescription";
            this.Text = "Existing Requested Description";
            this.Load += new System.EventHandler(this.Existing_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private ListBox listBox1;
        private Label lblTtlAmount;
        private Button btnChangeRequest;
        private Button btnMenu;
        private Label lblDate;
        private Label lblOrderID;
        private Label lblServiceRequested;
        private Label lblAmount;
        private Label lblStatus;
        private Panel panel1;
        private Label lblDescription;
        private Label label9;
        private Label lblShowTtlAmount;
        private Label lblUrgency;
    }
}