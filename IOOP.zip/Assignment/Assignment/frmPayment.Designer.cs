﻿namespace Assignment
{
    partial class frmPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMethod = new System.Windows.Forms.Label();
            this.cmbPayMethod = new System.Windows.Forms.ComboBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblPaid = new System.Windows.Forms.Label();
            this.txtPaidAmt = new System.Windows.Forms.TextBox();
            this.lblChange = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTotalPayAmt = new System.Windows.Forms.Label();
            this.lblChangeAmt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblMethod
            // 
            this.lblMethod.AutoSize = true;
            this.lblMethod.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMethod.Location = new System.Drawing.Point(141, 121);
            this.lblMethod.Name = "lblMethod";
            this.lblMethod.Size = new System.Drawing.Size(198, 32);
            this.lblMethod.TabIndex = 10;
            this.lblMethod.Text = "Payment Method";
            // 
            // cmbPayMethod
            // 
            this.cmbPayMethod.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmbPayMethod.FormattingEnabled = true;
            this.cmbPayMethod.Items.AddRange(new object[] {
            "Cash",
            "Credit Card",
            "Boost",
            "Shopee Pay",
            "Grab Pay"});
            this.cmbPayMethod.Location = new System.Drawing.Point(370, 121);
            this.cmbPayMethod.Name = "cmbPayMethod";
            this.cmbPayMethod.Size = new System.Drawing.Size(182, 40);
            this.cmbPayMethod.TabIndex = 11;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTotal.Location = new System.Drawing.Point(129, 198);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(210, 32);
            this.lblTotal.TabIndex = 12;
            this.lblTotal.Text = "Total Payable (RM)";
            // 
            // lblPaid
            // 
            this.lblPaid.AutoSize = true;
            this.lblPaid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPaid.Location = new System.Drawing.Point(131, 271);
            this.lblPaid.Name = "lblPaid";
            this.lblPaid.Size = new System.Drawing.Size(208, 32);
            this.lblPaid.TabIndex = 13;
            this.lblPaid.Text = "Paid Amount (RM)";
            // 
            // txtPaidAmt
            // 
            this.txtPaidAmt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPaidAmt.Location = new System.Drawing.Point(370, 268);
            this.txtPaidAmt.Name = "txtPaidAmt";
            this.txtPaidAmt.Size = new System.Drawing.Size(182, 39);
            this.txtPaidAmt.TabIndex = 14;
            this.txtPaidAmt.TextChanged += new System.EventHandler(this.txtPaidAmt_TextChanged);
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblChange.Location = new System.Drawing.Point(186, 341);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(153, 32);
            this.lblChange.TabIndex = 15;
            this.lblChange.Text = "Change (RM)";
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.Blue;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnConfirm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnConfirm.Location = new System.Drawing.Point(246, 432);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(200, 62);
            this.btnConfirm.TabIndex = 10;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(216, 25);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(261, 45);
            this.lblTitle.TabIndex = 29;
            this.lblTitle.Text = "Accept Payment";
            // 
            // lblTotalPayAmt
            // 
            this.lblTotalPayAmt.AutoSize = true;
            this.lblTotalPayAmt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTotalPayAmt.Location = new System.Drawing.Point(370, 198);
            this.lblTotalPayAmt.Name = "lblTotalPayAmt";
            this.lblTotalPayAmt.Size = new System.Drawing.Size(84, 32);
            this.lblTotalPayAmt.TabIndex = 32;
            this.lblTotalPayAmt.Text = "150.00";
            // 
            // lblChangeAmt
            // 
            this.lblChangeAmt.AutoSize = true;
            this.lblChangeAmt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblChangeAmt.Location = new System.Drawing.Point(370, 341);
            this.lblChangeAmt.Name = "lblChangeAmt";
            this.lblChangeAmt.Size = new System.Drawing.Size(24, 32);
            this.lblChangeAmt.TabIndex = 33;
            this.lblChangeAmt.Text = "-";
            // 
            // frmPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(692, 547);
            this.Controls.Add(this.lblChangeAmt);
            this.Controls.Add(this.lblTotalPayAmt);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.lblChange);
            this.Controls.Add(this.txtPaidAmt);
            this.Controls.Add(this.lblPaid);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.cmbPayMethod);
            this.Controls.Add(this.lblMethod);
            this.Name = "frmPayment";
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.frmPayment_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label lblMethod;
        private ComboBox cmbPayMethod;
        private Label lblTotal;
        private Label lblPaid;
        private TextBox txtPaidAmt;
        private Label lblChange;
        private Button btnConfirm;
        private Label lblTitle;
        private Label lblTotalPayAmt;
        private Label lblChangeAmt;
    }
}