﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class technician
    {
        //member field
        private string techemail;

        static SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        //constructor
        public technician(string email)
        {
            techemail = email;
        }

        //methods
        public string getName(string email)
        {
            Con.Open();

            //Sql command
            SqlCommand cmd = new SqlCommand("select Name from Technician where Email='" + techemail + "'", Con);
            string techName = cmd.ExecuteScalar().ToString();

            Con.Close();
            return techName;
        }

        public string getId(string email)
        {
            Con.Open();

            SqlCommand cmd2 = new SqlCommand("select TechId from Technician where Email='" + techemail + "'", Con);
            string techId = cmd2.ExecuteScalar().ToString();

            Con.Close();
            return techId;
        }

        public string getTel(string email)
        {
            Con.Open();

            SqlCommand cmd3 = new SqlCommand("select TelNum from Technician where Email='" + techemail + "'", Con);
            string techTel = cmd3.ExecuteScalar().ToString();

            Con.Close();
            return techTel;
        }

        public string getStart(string email)
        {
            Con.Open();

            SqlCommand cmd4 = new SqlCommand("select StartWork from Technician where Email='" + techemail + "'", Con);
            string techStart = cmd4.ExecuteScalar().ToString();

            Con.Close();
            return techStart;
        }

        public string getEnd(string email)
        {
            Con.Open();

            SqlCommand cmd5 = new SqlCommand("select EndWork from Technician where Email='" + techemail + "'", Con);
            string techEnd = cmd5.ExecuteScalar().ToString();

            Con.Close();
            return techEnd;
        }

        public string updateProfile(string tel, string start, string end)
        {
            string status;
            Con.Open();

            string techTel = tel;
            string techStart = start;
            string techEnd = end;

            SqlCommand cmd = new SqlCommand("update Technician set TelNum ='" + techTel + "',StartWork='" + techStart + "',EndWork='" + techEnd + "'where Email ='" + techemail + "'", Con);

            int i = cmd.ExecuteNonQuery();
            if (i == 0)
                status = "Update failed :(";
            else
                status = "Update successful :)";
            Con.Close();

            return status;
        }
    }
}
