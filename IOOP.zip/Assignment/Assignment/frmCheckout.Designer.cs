﻿namespace Assignment
{
    partial class frmCheckout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReceptionist = new System.Windows.Forms.Label();
            this.btnPayment = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblStatue = new System.Windows.Forms.Label();
            this.grpDetail = new System.Windows.Forms.GroupBox();
            this.lblCusStatue = new System.Windows.Forms.Label();
            this.lblCusService = new System.Windows.Forms.Label();
            this.lblCusName = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblRecName = new System.Windows.Forms.Label();
            this.grpSummary = new System.Windows.Forms.GroupBox();
            this.btnDiscount = new System.Windows.Forms.Button();
            this.lblPercent = new System.Windows.Forms.Label();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.checkDiscount = new System.Windows.Forms.CheckBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblCusTotal = new System.Windows.Forms.Label();
            this.lblCusDiscountAmt = new System.Windows.Forms.Label();
            this.lblCusSubTotal = new System.Windows.Forms.Label();
            this.lblDiscountAmt = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.grpDetail.SuspendLayout();
            this.grpSummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblReceptionist
            // 
            this.lblReceptionist.AutoSize = true;
            this.lblReceptionist.Location = new System.Drawing.Point(62, 97);
            this.lblReceptionist.Name = "lblReceptionist";
            this.lblReceptionist.Size = new System.Drawing.Size(117, 25);
            this.lblReceptionist.TabIndex = 0;
            this.lblReceptionist.Text = "Receptionist: ";
            // 
            // btnPayment
            // 
            this.btnPayment.BackColor = System.Drawing.Color.Blue;
            this.btnPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPayment.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPayment.ForeColor = System.Drawing.SystemColors.Control;
            this.btnPayment.Location = new System.Drawing.Point(291, 677);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(146, 53);
            this.btnPayment.TabIndex = 13;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblName.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblName.Location = new System.Drawing.Point(45, 40);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(63, 25);
            this.lblName.TabIndex = 17;
            this.lblName.Text = "Name:";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblService.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblService.Location = new System.Drawing.Point(37, 88);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(71, 25);
            this.lblService.TabIndex = 19;
            this.lblService.Text = "Service:";
            // 
            // lblStatue
            // 
            this.lblStatue.AutoSize = true;
            this.lblStatue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblStatue.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStatue.Location = new System.Drawing.Point(43, 136);
            this.lblStatue.Name = "lblStatue";
            this.lblStatue.Size = new System.Drawing.Size(65, 25);
            this.lblStatue.TabIndex = 21;
            this.lblStatue.Text = "Statue:";
            // 
            // grpDetail
            // 
            this.grpDetail.BackColor = System.Drawing.Color.LightBlue;
            this.grpDetail.Controls.Add(this.lblCusStatue);
            this.grpDetail.Controls.Add(this.lblCusService);
            this.grpDetail.Controls.Add(this.lblCusName);
            this.grpDetail.Controls.Add(this.lblStatue);
            this.grpDetail.Controls.Add(this.lblService);
            this.grpDetail.Controls.Add(this.lblName);
            this.grpDetail.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpDetail.Location = new System.Drawing.Point(62, 148);
            this.grpDetail.Name = "grpDetail";
            this.grpDetail.Size = new System.Drawing.Size(596, 206);
            this.grpDetail.TabIndex = 26;
            this.grpDetail.TabStop = false;
            this.grpDetail.Text = "Customer Detail";
            // 
            // lblCusStatue
            // 
            this.lblCusStatue.AutoSize = true;
            this.lblCusStatue.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusStatue.Location = new System.Drawing.Point(117, 132);
            this.lblCusStatue.Name = "lblCusStatue";
            this.lblCusStatue.Size = new System.Drawing.Size(82, 30);
            this.lblCusStatue.TabIndex = 28;
            this.lblCusStatue.Text = "Urgent";
            // 
            // lblCusService
            // 
            this.lblCusService.AutoSize = true;
            this.lblCusService.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusService.Location = new System.Drawing.Point(117, 84);
            this.lblCusService.Name = "lblCusService";
            this.lblCusService.Size = new System.Drawing.Size(425, 30);
            this.lblCusService.TabIndex = 27;
            this.lblCusService.Text = "Operating System Format and Installation";
            // 
            // lblCusName
            // 
            this.lblCusName.AutoSize = true;
            this.lblCusName.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusName.Location = new System.Drawing.Point(117, 36);
            this.lblCusName.Name = "lblCusName";
            this.lblCusName.Size = new System.Drawing.Size(70, 30);
            this.lblCusName.TabIndex = 26;
            this.lblCusName.Text = "Bryan";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(239, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(255, 45);
            this.lblTitle.TabIndex = 28;
            this.lblTitle.Text = "Check Out Page";
            // 
            // lblRecName
            // 
            this.lblRecName.AutoSize = true;
            this.lblRecName.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRecName.Location = new System.Drawing.Point(185, 97);
            this.lblRecName.Name = "lblRecName";
            this.lblRecName.Size = new System.Drawing.Size(59, 25);
            this.lblRecName.TabIndex = 33;
            this.lblRecName.Text = "Cindy";
            // 
            // grpSummary
            // 
            this.grpSummary.BackColor = System.Drawing.Color.LightBlue;
            this.grpSummary.Controls.Add(this.btnDiscount);
            this.grpSummary.Controls.Add(this.lblPercent);
            this.grpSummary.Controls.Add(this.txtDiscount);
            this.grpSummary.Controls.Add(this.checkDiscount);
            this.grpSummary.Controls.Add(this.lblTotal);
            this.grpSummary.Controls.Add(this.lblCusTotal);
            this.grpSummary.Controls.Add(this.lblCusDiscountAmt);
            this.grpSummary.Controls.Add(this.lblCusSubTotal);
            this.grpSummary.Controls.Add(this.lblDiscountAmt);
            this.grpSummary.Controls.Add(this.lblSubtotal);
            this.grpSummary.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpSummary.Location = new System.Drawing.Point(62, 385);
            this.grpSummary.Name = "grpSummary";
            this.grpSummary.Size = new System.Drawing.Size(596, 265);
            this.grpSummary.TabIndex = 30;
            this.grpSummary.TabStop = false;
            this.grpSummary.Text = "Summary";
            // 
            // btnDiscount
            // 
            this.btnDiscount.BackColor = System.Drawing.Color.Orange;
            this.btnDiscount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDiscount.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDiscount.Location = new System.Drawing.Point(415, 90);
            this.btnDiscount.Name = "btnDiscount";
            this.btnDiscount.Size = new System.Drawing.Size(164, 40);
            this.btnDiscount.TabIndex = 33;
            this.btnDiscount.Text = "Confirm Discount";
            this.btnDiscount.UseVisualStyleBackColor = false;
            this.btnDiscount.Click += new System.EventHandler(this.btnDiscount_Click);
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPercent.Location = new System.Drawing.Point(378, 97);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(31, 30);
            this.lblPercent.TabIndex = 32;
            this.lblPercent.Text = "%";
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.Color.Silver;
            this.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiscount.Cursor = System.Windows.Forms.Cursors.No;
            this.txtDiscount.Location = new System.Drawing.Point(212, 97);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.ReadOnly = true;
            this.txtDiscount.Size = new System.Drawing.Size(150, 30);
            this.txtDiscount.TabIndex = 31;
            // 
            // checkDiscount
            // 
            this.checkDiscount.AutoSize = true;
            this.checkDiscount.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkDiscount.Location = new System.Drawing.Point(72, 97);
            this.checkDiscount.Name = "checkDiscount";
            this.checkDiscount.Size = new System.Drawing.Size(117, 29);
            this.checkDiscount.TabIndex = 30;
            this.checkDiscount.Text = "Discount :";
            this.checkDiscount.UseVisualStyleBackColor = true;
            this.checkDiscount.CheckedChanged += new System.EventHandler(this.checkDiscount_CheckedChanged);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.LightBlue;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTotal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTotal.Location = new System.Drawing.Point(8, 207);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(181, 25);
            this.lblTotal.TabIndex = 10;
            this.lblTotal.Text = "Total Amount (RM):";
            // 
            // lblCusTotal
            // 
            this.lblCusTotal.AutoSize = true;
            this.lblCusTotal.Font = new System.Drawing.Font("Segoe UI Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusTotal.ForeColor = System.Drawing.Color.Black;
            this.lblCusTotal.Location = new System.Drawing.Point(217, 191);
            this.lblCusTotal.Name = "lblCusTotal";
            this.lblCusTotal.Size = new System.Drawing.Size(121, 45);
            this.lblCusTotal.TabIndex = 29;
            this.lblCusTotal.Text = "150.00";
            // 
            // lblCusDiscountAmt
            // 
            this.lblCusDiscountAmt.AutoSize = true;
            this.lblCusDiscountAmt.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusDiscountAmt.Location = new System.Drawing.Point(217, 154);
            this.lblCusDiscountAmt.Name = "lblCusDiscountAmt";
            this.lblCusDiscountAmt.Size = new System.Drawing.Size(22, 30);
            this.lblCusDiscountAmt.TabIndex = 27;
            this.lblCusDiscountAmt.Text = "-";
            // 
            // lblCusSubTotal
            // 
            this.lblCusSubTotal.AutoSize = true;
            this.lblCusSubTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusSubTotal.Location = new System.Drawing.Point(217, 40);
            this.lblCusSubTotal.Name = "lblCusSubTotal";
            this.lblCusSubTotal.Size = new System.Drawing.Size(75, 30);
            this.lblCusSubTotal.TabIndex = 26;
            this.lblCusSubTotal.Text = "150.00";
            // 
            // lblDiscountAmt
            // 
            this.lblDiscountAmt.AutoSize = true;
            this.lblDiscountAmt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDiscountAmt.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblDiscountAmt.Location = new System.Drawing.Point(28, 154);
            this.lblDiscountAmt.Name = "lblDiscountAmt";
            this.lblDiscountAmt.Size = new System.Drawing.Size(161, 25);
            this.lblDiscountAmt.TabIndex = 19;
            this.lblDiscountAmt.Text = "Discount Amount :";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSubtotal.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblSubtotal.Location = new System.Drawing.Point(53, 44);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(136, 25);
            this.lblSubtotal.TabIndex = 17;
            this.lblSubtotal.Text = "Sub Total (RM) :";
            // 
            // frmCheckout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(728, 741);
            this.Controls.Add(this.grpSummary);
            this.Controls.Add(this.lblRecName);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpDetail);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.lblReceptionist);
            this.Name = "frmCheckout";
            this.Text = "Check Out Page";
            this.Load += new System.EventHandler(this.Checkout_Load);
            this.grpDetail.ResumeLayout(false);
            this.grpDetail.PerformLayout();
            this.grpSummary.ResumeLayout(false);
            this.grpSummary.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblReceptionist;
        private Button btnPayment;
        private Label lblName;
        private Label lblService;
        private Label lblStatue;
        private GroupBox grpDetail;
        private Label lblTitle;
        private Label lblRecName;
        private Label lblCusStatue;
        private Label lblCusService;
        private Label lblCusName;
        private GroupBox grpSummary;
        private Label lblPercent;
        private TextBox txtDiscount;
        private CheckBox checkDiscount;
        private Label lblTotal;
        private Label lblCusTotal;
        private Label lblCusDiscountAmt;
        private Label lblCusSubTotal;
        private Label lblDiscountAmt;
        private Label lblSubtotal;
        private Button btnDiscount;
    }
}