﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class credentials
    {
        private string techemail;

        static SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        public credentials(string email)
        {
            techemail = email;
        }

        public string updatePass(string email, string pw)
        {
            string status;
            string Pass = pw;
            Con.Open();

            //Sql command
            SqlCommand cmd = new SqlCommand("update Login set Pass='"+ Pass +"'where Email='"+techemail+"'",Con);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Password update successfully :)";
            else
                status = "Update failed :(";
            Con.Close();

            return status;
        }

        public string setQues(string email, string ques, string ans)
        {
            string status;
            Con.Open();

            //Sql command
            SqlCommand cmd = new SqlCommand("update Login set QuestionID='" + ques + "'where Email='" + techemail + "'", Con);
            int i = cmd.ExecuteNonQuery();

            SqlCommand cmd2 = new SqlCommand("update Login set Ans= @ans where Email='" + techemail + "'", Con);
            //SqlCommand cmd2 = new SqlCommand("update Login set Ans='" + ans + "'where Email='" + techemail + "'", Con);
            cmd2.Parameters.AddWithValue("@ans", ans);
            int z = cmd2.ExecuteNonQuery();


            if (i!=0 && z!=0)
                status = "Your security question is successfully set :)";
            else
                status = "Update failed :(";
            Con.Close();

            return status;
        }
    }
}
