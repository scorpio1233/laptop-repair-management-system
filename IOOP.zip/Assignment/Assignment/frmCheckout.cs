﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmCheckout : Form
    {
        public static string receptionistName;
        public static string orderID;
        public static string cusName;
        public static string service;
        public static string urgency;

        public frmCheckout()
        {
            InitializeComponent();
        }

        //constructor overload - accept from frmPaySelect
        public frmCheckout(string cReceptionistName, string cOrderID, string cCusName, string cService, string cUrgency)
        {
            InitializeComponent();
            receptionistName = cReceptionistName;
            orderID = cOrderID;
            cusName = cCusName;
            service = cService;
            urgency = cUrgency;
        }

        private void Checkout_Load(object sender, EventArgs e)
        {
            lblRecName.Text = receptionistName;
            lblCusName.Text = cusName;
            lblCusService.Text = service;
            lblCusStatue.Text = urgency;
            lblCusSubTotal.Text = displayPrice();
            lblCusTotal.Text = lblCusSubTotal.Text;
        }




        private void btnPayment_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmPayment pay = new frmPayment(orderID, lblCusSubTotal.Text, lblCusTotal.Text, receptionistName);
            pay.ShowDialog();
            this.Close();
        }

        private void btnDiscount_Click(object sender, EventArgs e)
        {
            double discountPercent;
            lblCusTotal.Text = lblCusSubTotal.Text;
            lblCusDiscountAmt.Text = "-";
            if (double.TryParse(txtDiscount.Text, out discountPercent))
            {
                if (discountPercent > 0 && discountPercent <= 100)
                {
                    double discount_amount = double.Parse(lblCusSubTotal.Text) * discountPercent / 100;
                    discount_amount = Math.Round(discount_amount, 2);
                    lblCusDiscountAmt.Text = discount_amount.ToString();
                    lblCusDiscountAmt.Text += addDecimal(discount_amount.ToString());
                    double totalPrice = double.Parse(lblCusTotal.Text) - discount_amount;
                    totalPrice = Math.Round(totalPrice, 2);
                    lblCusTotal.Text = totalPrice.ToString();
                    lblCusTotal.Text += addDecimal(totalPrice.ToString());
                }
                else
                    MessageBox.Show("discount percent must larger than 0 and lower than 100");
            }
            else
                MessageBox.Show("Please enter valid number.");
        }

        private void checkDiscount_CheckedChanged(object sender, EventArgs e)
        {
            if (checkDiscount.Checked)
            {
                txtDiscount.ReadOnly = false;
                txtDiscount.Cursor = Cursors.IBeam;
                txtDiscount.BackColor = Color.White;
            }
            else
            {
                txtDiscount.ReadOnly = true;
                txtDiscount.Cursor = Cursors.No;
                txtDiscount.BackColor = Color.Silver;
                txtDiscount.Text = string.Empty;
                lblCusTotal.Text = lblCusSubTotal.Text;
                lblCusDiscountAmt.Text = "-";
            }
        }

        //display price method
        public string displayPrice()
        {            
            string price = "0.00";

            if (service == "Remove virus, malware or spyware" && urgency == "Normal")
                price = "50.00";
            else if (service == "Remove virus, malware or spyware" && urgency == "Urgent")
                price = "80.00";
            else if (service == "Troubleshot and fix computer running slow" && urgency == "Normal")
                price = "60.00";
            else if (service == "Troubleshot and fix computer running slow" && urgency == "Urgent")
                price = "90.00";
            else if (service == "Laptop screen replacement" && urgency == "Normal")
                price = "380.00";
            else if (service == "Laptop screen replacement" && urgency == "Urgent")
                price = "430.00";
            else if (service == "Laptop keyboard replacement" && urgency == "Normal")
                price = "160.00";
            else if (service == "Laptop keyboard replacement" && urgency == "Urgent")
                price = "200.00";
            else if (service == "Laptop battery replacement" && urgency == "Normal")
                price = "180.00";
            else if (service == "Laptop battery replacement" && urgency == "Urgent")
                price = "210.00";
            else if (service == "Operating System Format and Installation" && urgency == "Normal")
                price = "100.00";
            else if (service == "Operating System Format and Installation" && urgency == "Urgent")
                price = "150.00";
            else if (service == "Data backup and recovery" && urgency == "Normal")
                price = "80.00";
            else if (service == "Data backup and recovery" && urgency == "Urgent")
                price = "130.00";
            else if (service == "Internet connectivity issues" && urgency == "Normal")
                price = "70.00";
            else if (service == "Internet connectivity issues" && urgency == "Urgent")
                price = "100.00";

            return (price);
        }

        //Make the amount form 2 decimal places
        public string addDecimal(string amount)
        {
            string result = null;
            if (int.TryParse(amount, out int amt))
                result = ".00";
            else
            {
                string[] arrayAmount = amount.Split('.');
                if (arrayAmount[1].Length == 1)
                    result = "0";
            }

            return result;
        }         


    }
}
