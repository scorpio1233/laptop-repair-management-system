﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class payment
    {
        //member field
        private string orderID;
        private string subtotal;
        private string total;
        private double paidAmount;
        private string receptionistName;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());


        //constructor - payment
        public payment(string cOrderID, string cSubtotal, string cTotal, double cTotalPaidAmount, string cReceptionistName)
        {
            orderID = cOrderID;
            subtotal = cSubtotal;
            total = cTotal;
            paidAmount = cTotalPaidAmount;
            receptionistName = cReceptionistName;
        }

        //constructor - receipt
        public payment(string cOrderID)
        {
            orderID = cOrderID;
        }

        //add payment into payment table
        public string addPayment()
        {
            string result = null;
            con.Open();

            //generate receipt ID
            string newReceiptID = "REP";
            SqlCommand cmd2 = new SqlCommand("select count(*) from [Payment]", con);
            int countreceiptID = Convert.ToInt32(cmd2.ExecuteScalar().ToString()) + 1;

            if (countreceiptID < 10)
                newReceiptID += ("000" + countreceiptID.ToString());
            else if (countreceiptID < 100 && countreceiptID >= 10)
                newReceiptID += ("00" + countreceiptID.ToString());
            else if (countreceiptID < 1000 && countreceiptID >= 100)
                newReceiptID += ("0" + countreceiptID.ToString());
            else
                newReceiptID += countreceiptID.ToString();

            //insert detail into payment table
            SqlCommand cmd = new SqlCommand("insert into [Payment] values (@orderID, @subTotal, @total, @paidAmt, @receiptID, @paymentDate, @receptionistName)", con);

            cmd.Parameters.AddWithValue("@orderID", orderID);
            cmd.Parameters.AddWithValue("@subTotal", double.Parse(subtotal));
            cmd.Parameters.AddWithValue("@total", double.Parse(total));
            cmd.Parameters.AddWithValue("@paidAmt", paidAmount);
            cmd.Parameters.AddWithValue("@receiptID", newReceiptID);
            cmd.Parameters.AddWithValue("@paymentDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.Parameters.AddWithValue("@receptionistName", receptionistName);

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                result = "Payment Successful.";

                //Update Order
                SqlCommand cmd3 = new SqlCommand("update [Order] set Status = 'Paid' where OrderID = '" + orderID + "'", con);
                cmd3.ExecuteNonQuery();

                //find customer
                SqlCommand cmd4 = new SqlCommand("select CustomerID from [Order]  where OrderID = '" + orderID + "'", con);
                string cusID = cmd4.ExecuteScalar().ToString();

                //Update Customer
                SqlCommand cmd5 = new SqlCommand("update [Customer] set Status = 'Complete' where CustomerID = '" + cusID + "'", con);
                cmd5.ExecuteNonQuery();
            }
            else
                result = "Fail.";

            con.Close();
            return result;
        }

        //generate receipt
        public static ArrayList genReceipt(string orderIDforReceipt)
        {
            //cusName, cusAddress, cusTel,  service, urgency, receiptNo, paydatetime, receptionistname, subtotal, total, paidAmt
            ArrayList receipt_detail = new ArrayList();
            con.Open();

            //find customer ID
            SqlCommand cmd = new SqlCommand("select CustomerID from [Order] where OrderID = '" + orderIDforReceipt + "'", con);
            string customerID = cmd.ExecuteScalar().ToString();

            //add customer detail
            SqlCommand cmd2 = new SqlCommand("select Name, Street, Postcode, City, State, telNum from [Customer] where CustomerID = '" + customerID + "'", con);
            SqlDataReader rd2 = cmd2.ExecuteReader();
            while (rd2.Read())
            {
                receipt_detail.Add(rd2.GetString(0));
                string address = rd2.GetString(1) + "\n" + rd2.GetInt32(2).ToString() + ", " + rd2.GetString(3) + ", " + rd2.GetString(4);
                receipt_detail.Add(address);
                receipt_detail.Add("Tel: " + rd2.GetString(5));
            }
            rd2.Close();

            //add order detail
            SqlCommand cmd3 = new SqlCommand("select Item, Type from [Order] where OrderID = '" + orderIDforReceipt + "'", con);
            SqlDataReader rd3 = cmd3.ExecuteReader();
            while (rd3.Read())
            {
                receipt_detail.Add(rd3.GetString(0));
                receipt_detail.Add(rd3.GetString(1));
            }
            rd3.Close();

            //add payment detail
            SqlCommand cmd4 = new SqlCommand("select ReceiptID, PaymentDate, ReceptionistName, subTotal, Total, paidAmt from [Payment] where OrderID = '" + orderIDforReceipt + "'", con);
            SqlDataReader rd4 = cmd4.ExecuteReader();
            while (rd4.Read())
            {
                receipt_detail.Add(rd4.GetString(0));
                receipt_detail.Add(rd4.GetDateTime(1).ToString());
                receipt_detail.Add(rd4.GetString(2));
                receipt_detail.Add(rd4.GetDecimal(3));
                receipt_detail.Add(rd4.GetDecimal(4));
                receipt_detail.Add(rd4.GetDecimal(5));
            }

            con.Close();
            return receipt_detail;
        }

        public static ArrayList viewAllPayment()
        {
            //orderID, receiptNo, date, Total
            ArrayList all_payment = new ArrayList(); 
            con.Open();

            SqlCommand cmd = new SqlCommand("select OrderID, ReceiptID, PaymentDate, Total from [Payment]", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //Split datetime into date and time
                //string[] arrayDatetime = rd.GetDateTime(2).ToString().Split(' ');
                //add all item into array
                all_payment.Add(rd.GetString(0));
                all_payment.Add(rd.GetString(1));
                all_payment.Add(rd.GetDateTime(2).ToString("dd/MM/yyyy"));
                all_payment.Add(rd.GetDecimal(3).ToString());
            }
            con.Close();
            return all_payment;
        }
    }
}
