﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmRegRecp : Form
    {
        public frmRegRecp()
        {
            InitializeComponent();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (txtName.Text != string.Empty && txtNumber.Text != string.Empty && txtEmail.Text != string.Empty && txtAddress.Text != string.Empty && txtCity.Text != string.Empty && txtRegion.Text != string.Empty && txtPostCode.Text != string.Empty)
            {
                AdmReceptionist obj1 = new AdmReceptionist(txtName.Text, txtNumber.Text, txtEmail.Text, txtAddress.Text, txtCity.Text, txtRegion.Text, txtPostCode.Text);
                string str = obj1.addReceptionist();
                MessageBox.Show(str);
                this.Close();
            }
            else
                MessageBox.Show("Error");

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
