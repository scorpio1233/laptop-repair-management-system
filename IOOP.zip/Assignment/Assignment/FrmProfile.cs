﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmProfile : Form
    {
        public static string techEmail;
        public FrmProfile(string email)
        {
            InitializeComponent();
            techEmail = email;
        }
        public FrmProfile()
        {
            InitializeComponent();
        }


        private void FrmProfile_Load(object sender, EventArgs e)
        {
            technician obj1 = new technician(techEmail);
            lblName.Text = obj1.getName(techEmail);
            lblID.Text = obj1.getId(techEmail);
            txtTel.Text = obj1.getTel(techEmail);
            txtTel.Text = obj1.getTel(techEmail);
            lblEmail.Text = techEmail;
            int s = Int32.Parse(obj1.getStart(techEmail));
            txtStart.Text = s.ToString();
            int en = Int32.Parse(obj1.getEnd(techEmail));
            txtEnd.Text = en.ToString();
        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            FrmChangePass form = new FrmChangePass(techEmail);
            form.Show();
        }

        private void btnSecureQ_Click(object sender, EventArgs e)
        {
            FrmSetSecure form = new FrmSetSecure(techEmail);
            form.Show();
        }

        private void btnBProfile_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtTel.Text.All(char.IsDigit) && txtStart.Text.All(char.IsDigit) && txtEnd.Text.All(char.IsDigit))
            {    
                if (Int32.Parse(txtStart.Text) > 6 && Int32.Parse(txtStart.Text) < 11)
                {
                    if (Int32.Parse(txtEnd.Text) > 4 && Int32.Parse(txtEnd.Text) < 11)
                    {
                        technician obj1 = new technician(techEmail);
                        MessageBox.Show(obj1.updateProfile(txtTel.Text, txtStart.Text, txtEnd.Text));
                    }
                    else
                    {
                        MessageBox.Show("End work time should be between 5 to 10 pm, kindly only insert number into the text box ^.^  ");
                    }
                }
                else
                {
                    MessageBox.Show("Start work time should be between 7 to 10 am, kindly only insert number into the text box ^.^ ");
                }
            }
            else
            {
                MessageBox.Show("Only digits are allowed!");
            }
        }
    }
}
