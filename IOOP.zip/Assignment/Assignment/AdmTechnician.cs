﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class AdmTechnician
    {
        private string name;
        private string email;
        private string telNum;
        private string StartWork;
        private string EndWork;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string TelNum { get => telNum; set => telNum = value; }


        //Constructor
        public AdmTechnician(string tName, string tTelNum, string tEmail, string tStartWork, string tEndWork)
        {
            Name = tName;
            TelNum = tTelNum;
            Email = tEmail;
            StartWork = tStartWork;
            EndWork = tEndWork;
        }

        //Constructor 
        public AdmTechnician(string tEmail)
        {
            Email = tEmail;
        }

        public string addTechnician()
        {
            string status = null;
            con.Open();

            //check is there repeated email
            SqlCommand cmd = new SqlCommand("select count(*) from Technician where email = @email", con);
            cmd.Parameters.AddWithValue("@email", email);
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0) //Email already existed
                status = "Unable to register. Email already existed.";
            else
            {
                string default_pwd = "TEC";
                var last4 = TelNum.Substring(TelNum.Length - 4,4);
                default_pwd = default_pwd + last4;

                //Generate tech id
                string techid = getTechID();

                //Insert data into table Login and Technician
                SqlCommand cmd2 = new SqlCommand("insert into Login(email, Pass, Role) values (@email, @default_pwd, 'Technician')", con);
                SqlCommand cmd3 = new SqlCommand("insert into Technician values (@TechID, @name, @telNum, @email, @start, @end)", con);
                //Login table
                cmd2.Parameters.AddWithValue("@email", email);
                cmd2.Parameters.AddWithValue("@default_pwd", default_pwd);
                //Technician table
                cmd3.Parameters.AddWithValue("@techID", techid);
                cmd3.Parameters.AddWithValue("@name", name);
                cmd3.Parameters.AddWithValue("@telNum", telNum);
                cmd3.Parameters.AddWithValue("@email", email);
                cmd3.Parameters.AddWithValue("@start", StartWork);
                cmd3.Parameters.AddWithValue("@End", EndWork);



                //check insert succesfully or not
                int j = cmd2.ExecuteNonQuery();
                int i = cmd3.ExecuteNonQuery();
                if (j != 0 && i != 0)
                    status = "Registration Successful. \nThis is your default password: " + default_pwd;
                else
                    status = "Unable to register.";
            }
            con.Close();
            return status;
        }

        public string getTechID()
        {
            string ID = "ID";
            SqlCommand cmd2 = new SqlCommand("select count(*) from [Technician]", con);
            int count = Convert.ToInt32(cmd2.ExecuteScalar().ToString()) + 1;

            if (count < 10)
                ID += ("00" + count.ToString());
            else if (count < 100 && count >= 10)
                ID += ("0" + count.ToString());
            else
                ID += count.ToString();

            return ID;
        }



    }

    
}
