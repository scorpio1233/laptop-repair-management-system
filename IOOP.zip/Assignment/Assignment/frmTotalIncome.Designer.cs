﻿namespace Assignment
{
    partial class frmTotalIncome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCompany = new System.Windows.Forms.Label();
            this.grpEarning = new System.Windows.Forms.GroupBox();
            this.lblTotalEarn = new System.Windows.Forms.Label();
            this.lblWhen = new System.Windows.Forms.Label();
            this.lblMonth = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.cmbMonth = new System.Windows.Forms.ComboBox();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.btnFetch = new System.Windows.Forms.Button();
            this.grpEarning.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(15, 22);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(415, 60);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "Company Income";
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCompany.Location = new System.Drawing.Point(26, 100);
            this.lblCompany.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(277, 24);
            this.lblCompany.TabIndex = 13;
            this.lblCompany.Text = "FIX-IT FELIX Laptop Repair";
            // 
            // grpEarning
            // 
            this.grpEarning.BackColor = System.Drawing.Color.Turquoise;
            this.grpEarning.Controls.Add(this.lblTotalEarn);
            this.grpEarning.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpEarning.Location = new System.Drawing.Point(26, 180);
            this.grpEarning.Margin = new System.Windows.Forms.Padding(4);
            this.grpEarning.Name = "grpEarning";
            this.grpEarning.Padding = new System.Windows.Forms.Padding(4);
            this.grpEarning.Size = new System.Drawing.Size(584, 368);
            this.grpEarning.TabIndex = 14;
            this.grpEarning.TabStop = false;
            this.grpEarning.Text = "Total Earning";
            // 
            // lblTotalEarn
            // 
            this.lblTotalEarn.AutoSize = true;
            this.lblTotalEarn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalEarn.Font = new System.Drawing.Font("MS Reference Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTotalEarn.Location = new System.Drawing.Point(146, 158);
            this.lblTotalEarn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalEarn.Name = "lblTotalEarn";
            this.lblTotalEarn.Size = new System.Drawing.Size(2, 62);
            this.lblTotalEarn.TabIndex = 0;
            // 
            // lblWhen
            // 
            this.lblWhen.AutoSize = true;
            this.lblWhen.BackColor = System.Drawing.Color.Ivory;
            this.lblWhen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblWhen.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWhen.Location = new System.Drawing.Point(787, 343);
            this.lblWhen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWhen.Name = "lblWhen";
            this.lblWhen.Size = new System.Drawing.Size(2, 27);
            this.lblWhen.TabIndex = 29;
            this.lblWhen.Click += new System.EventHandler(this.lblModel_Click);
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblMonth.Location = new System.Drawing.Point(636, 338);
            this.lblMonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(111, 32);
            this.lblMonth.TabIndex = 28;
            this.lblMonth.Text = "Month: ";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(26, 610);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(95, 36);
            this.btnBack.TabIndex = 36;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCheck.Location = new System.Drawing.Point(1050, 610);
            this.btnCheck.Margin = new System.Windows.Forms.Padding(4);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(95, 36);
            this.btnCheck.TabIndex = 37;
            this.btnCheck.Text = "Check";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // cmbMonth
            // 
            this.cmbMonth.FormattingEnabled = true;
            this.cmbMonth.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbMonth.Location = new System.Drawing.Point(636, 180);
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Size = new System.Drawing.Size(182, 33);
            this.cmbMonth.TabIndex = 38;
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2025",
            "2026",
            "2027",
            "2028",
            "2029",
            "2030"});
            this.cmbYear.Location = new System.Drawing.Point(842, 180);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(182, 33);
            this.cmbYear.TabIndex = 39;
            // 
            // btnFetch
            // 
            this.btnFetch.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnFetch.Location = new System.Drawing.Point(1050, 180);
            this.btnFetch.Margin = new System.Windows.Forms.Padding(4);
            this.btnFetch.Name = "btnFetch";
            this.btnFetch.Size = new System.Drawing.Size(95, 36);
            this.btnFetch.TabIndex = 40;
            this.btnFetch.Text = "Fetch";
            this.btnFetch.UseVisualStyleBackColor = true;
            this.btnFetch.Click += new System.EventHandler(this.btnFetch_Click);
            // 
            // frmTotalIncome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(1195, 661);
            this.Controls.Add(this.btnFetch);
            this.Controls.Add(this.cmbYear);
            this.Controls.Add(this.cmbMonth);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblWhen);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.grpEarning);
            this.Controls.Add(this.lblCompany);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmTotalIncome";
            this.Text = "Total Income (Monthly)";
            this.Load += new System.EventHandler(this.frmTotalIncome_Load);
            this.grpEarning.ResumeLayout(false);
            this.grpEarning.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label lblCompany;
        private GroupBox grpEarning;
        private Label lblTotalEarn;
        private Label lblWhen;
        private Label lblMonth;
        private Button btnBack;
        private Button btnCheck;
        private ComboBox cmbMonth;
        private ComboBox cmbYear;
        private Button btnFetch;
    }
}