﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmRegExistCus : Form
    {

        public frmRegExistCus()
        {
            InitializeComponent();
        }

        private void frmRegExistCus_Load(object sender, EventArgs e)
        {
            cmbService.SelectedIndex = 0;

            ArrayList allCus = new ArrayList();
            //CusID, Name, Email, TelNum
            allCus = customer.viewCompletedCus();

            for (int i = 0; i < allCus.Count; i = i + 4)
            {
                ListViewItem item = new ListViewItem(allCus[i].ToString());
                item.SubItems.Add(allCus[i + 1].ToString());
                item.SubItems.Add(allCus[i + 2].ToString());
                item.SubItems.Add(allCus[i + 3].ToString());

                lvCustomer.Items.Add(item);
            }
            lvCustomer.Items[0].Remove();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //Identify urgency
            string Urgency = null;
            if (radNormal.Checked == true)
                Urgency = "Normal";
            else if (radUrgent.Checked == true)
                Urgency = "Urgent";

            if (lvCustomer.SelectedItems.Count > 0)
            {
                if (txtRemark.Text != string.Empty)
                {
                    order or = new order(lvCustomer.SelectedItems[0].SubItems[2].Text, cmbService.SelectedItem.ToString(), Urgency, txtRemark.Text);
                    MessageBox.Show("Customer Name: " + lvCustomer.SelectedItems[0].SubItems[1].Text + "\n" +or.addOrder(), "Result");

                    //update customer to progressing 
                    customer cr = new customer(lvCustomer.SelectedItems[0].SubItems[2].Text); //email
                    cr.updateCustomerStatus();
                    this.Close();
                }
                else
                    MessageBox.Show("Please fill in the laptop model.");
            }
            else
                MessageBox.Show("Please select an order first.");            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtRemark.Text = string.Empty;
            cmbService.SelectedIndex = 0;
            radNormal.Checked = true;
            lvCustomer.SelectedItems.Clear();
        }
    }
}
