﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmGenReceipt : Form
    {
        public frmGenReceipt()
        {
            InitializeComponent();
        }

        private void frmGenReceipt_Load(object sender, EventArgs e)
        {
            fillAllPayment();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (lvReceipt.SelectedItems.Count > 0)
            {
                frmReceipt re = new frmReceipt(lvReceipt.SelectedItems[0].SubItems[2].Text); //Order ID
                re.ShowDialog();
            }
            else
                MessageBox.Show("Please select a receipt first.");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DateTime iDate = datePicker.Value;

            fillAllPayment();
            for (int i = lvReceipt.Items.Count - 1; i >= 0; i--)
            {
                if (iDate.ToString("dd/MM/yyyy") != lvReceipt.Items[i].SubItems[1].Text)
                    lvReceipt.Items[i].Remove();
            }

            if (lvReceipt.Items.Count == 0)
                lblNoRecord.Visible = true;
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            fillAllPayment();
        }



        //fill in all payment
        public void fillAllPayment()
        {
            for (int i = lvReceipt.Items.Count - 1; i >= 0; i--)
            {
                lvReceipt.Items[i].Remove();
            }

            lblNoRecord.Visible = false;
            int count = 0;
            ArrayList allPayment = new ArrayList(); 
            ArrayList allService = new ArrayList();
            ArrayList allOrderID = new ArrayList();
            allPayment = payment.viewAllPayment(); //orderID, receiptNo, date, Total

            for (int j = 0; j < allPayment.Count; j += 4)
            {
                allOrderID.Add(allPayment[j]);
            }
            allService = order.getService(allOrderID); //Service

            for (int i = 0; i < allPayment.Count; i = i + 4)
            {
                ListViewItem item = new ListViewItem(allPayment[i + 1].ToString());
                item.SubItems.Add(allPayment[i + 2].ToString());
                item.SubItems.Add(allPayment[i].ToString());
                item.SubItems.Add(allService[count].ToString());
                item.SubItems.Add(allPayment[i + 3].ToString());

                lvReceipt.Items.Add(item);
                count++;
            }

            if (lvReceipt.Items.Count == 0)
                lblNoRecord.Visible = true;
        }

        
    }
}
