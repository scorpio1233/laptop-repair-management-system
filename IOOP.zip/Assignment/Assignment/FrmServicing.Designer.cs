﻿namespace Assignment
{
    partial class FrmServicing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBService = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCusName = new System.Windows.Forms.Label();
            this.lblLaptop = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblChk = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.btnDescribe = new System.Windows.Forms.Button();
            this.chkComplete = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnComplete = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBService
            // 
            this.btnBService.BackColor = System.Drawing.Color.LightPink;
            this.btnBService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBService.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBService.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBService.Location = new System.Drawing.Point(12, 12);
            this.btnBService.Name = "btnBService";
            this.btnBService.Size = new System.Drawing.Size(96, 36);
            this.btnBService.TabIndex = 9;
            this.btnBService.Text = "Back";
            this.btnBService.UseVisualStyleBackColor = false;
            this.btnBService.Click += new System.EventHandler(this.btnBService_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(47, 62);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 41);
            this.label1.TabIndex = 10;
            this.label1.Text = "Customer Name  :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(51, 103);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(264, 41);
            this.label2.TabIndex = 11;
            this.label2.Text = "Laptop Model     :";
            // 
            // lblCusName
            // 
            this.lblCusName.AutoSize = true;
            this.lblCusName.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusName.Location = new System.Drawing.Point(322, 62);
            this.lblCusName.Name = "lblCusName";
            this.lblCusName.Size = new System.Drawing.Size(106, 41);
            this.lblCusName.TabIndex = 12;
            this.lblCusName.Text = "Daniel";
            // 
            // lblLaptop
            // 
            this.lblLaptop.AutoSize = true;
            this.lblLaptop.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblLaptop.Location = new System.Drawing.Point(322, 103);
            this.lblLaptop.Name = "lblLaptop";
            this.lblLaptop.Size = new System.Drawing.Size(278, 41);
            this.lblLaptop.TabIndex = 13;
            this.lblLaptop.Text = "HP Pavilion cs x100";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblChk);
            this.panel1.Controls.Add(this.lblDesc);
            this.panel1.Controls.Add(this.lblService);
            this.panel1.Controls.Add(this.btnDescribe);
            this.panel1.Controls.Add(this.chkComplete);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(51, 172);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(724, 227);
            this.panel1.TabIndex = 14;
            // 
            // lblChk
            // 
            this.lblChk.AutoSize = true;
            this.lblChk.ForeColor = System.Drawing.Color.Red;
            this.lblChk.Location = new System.Drawing.Point(353, 190);
            this.lblChk.Name = "lblChk";
            this.lblChk.Size = new System.Drawing.Size(0, 20);
            this.lblChk.TabIndex = 6;
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Location = new System.Drawing.Point(533, 103);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(170, 20);
            this.lblDesc.TabIndex = 5;
            this.lblDesc.Text = "No Description Added :(";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblService.Location = new System.Drawing.Point(35, 49);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(75, 28);
            this.lblService.TabIndex = 4;
            this.lblService.Text = "battery";
            // 
            // btnDescribe
            // 
            this.btnDescribe.BackColor = System.Drawing.Color.Gainsboro;
            this.btnDescribe.Location = new System.Drawing.Point(568, 137);
            this.btnDescribe.Name = "btnDescribe";
            this.btnDescribe.Size = new System.Drawing.Size(135, 29);
            this.btnDescribe.TabIndex = 3;
            this.btnDescribe.Text = "Add description";
            this.btnDescribe.UseVisualStyleBackColor = false;
            this.btnDescribe.Click += new System.EventHandler(this.btnDescribe_Click);
            // 
            // chkComplete
            // 
            this.chkComplete.AutoSize = true;
            this.chkComplete.Location = new System.Drawing.Point(374, 186);
            this.chkComplete.Name = "chkComplete";
            this.chkComplete.Size = new System.Drawing.Size(343, 24);
            this.chkComplete.TabIndex = 2;
            this.chkComplete.Text = "I have completed servicing and checked this PC";
            this.chkComplete.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(22, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 35);
            this.label3.TabIndex = 0;
            this.label3.Text = "Service Requested";
            // 
            // btnComplete
            // 
            this.btnComplete.BackColor = System.Drawing.Color.Gold;
            this.btnComplete.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnComplete.Location = new System.Drawing.Point(633, 423);
            this.btnComplete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(142, 45);
            this.btnComplete.TabIndex = 15;
            this.btnComplete.Text = "COMPLETE";
            this.btnComplete.UseVisualStyleBackColor = false;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // FrmServicing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(834, 510);
            this.Controls.Add(this.btnComplete);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblLaptop);
            this.Controls.Add(this.lblCusName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBService);
            this.Name = "FrmServicing";
            this.Text = "Servicing Page";
            this.Load += new System.EventHandler(this.FrmServicing_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnBService;
        private Label label1;
        private Label label2;
        private Label lblCusName;
        private Label lblLaptop;
        private Panel panel1;
        private Label label3;
        private Button btnDescribe;
        private CheckBox chkComplete;
        private Button btnComplete;
        private Label lblService;
        private Label lblDesc;
        private Label lblChk;
    }
}