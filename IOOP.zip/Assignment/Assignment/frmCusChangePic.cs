﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmCusChangePic : Form
    {
        public static string email;

        public frmCusChangePic()
        {
            InitializeComponent();
        }

        public frmCusChangePic(string em)
        {
            InitializeComponent();
            email = em;
        }

        private void ChangePic_Load(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click_1(object sender, EventArgs e)
        {
            string pic = null;
            if (radPic1.Checked)
                pic = "PIC01";
            else if (radPic2.Checked)
                pic = "PIC02";

            customer r = new customer(email);
            MessageBox.Show(r.changePic(pic));
            this.Close();
        }
    }
}
