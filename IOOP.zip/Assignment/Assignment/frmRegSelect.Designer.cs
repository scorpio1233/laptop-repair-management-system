﻿namespace Assignment
{
    partial class frmRegSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegSelect));
            this.picExistCus = new System.Windows.Forms.PictureBox();
            this.btnExistCus = new System.Windows.Forms.Button();
            this.picNewCus = new System.Windows.Forms.PictureBox();
            this.btnNewCus = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picExistCus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNewCus)).BeginInit();
            this.SuspendLayout();
            // 
            // picExistCus
            // 
            this.picExistCus.BackColor = System.Drawing.Color.DodgerBlue;
            this.picExistCus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picExistCus.BackgroundImage")));
            this.picExistCus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picExistCus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picExistCus.Location = new System.Drawing.Point(414, 173);
            this.picExistCus.Name = "picExistCus";
            this.picExistCus.Size = new System.Drawing.Size(78, 68);
            this.picExistCus.TabIndex = 26;
            this.picExistCus.TabStop = false;
            this.picExistCus.Click += new System.EventHandler(this.picExistCus_Click);
            // 
            // btnExistCus
            // 
            this.btnExistCus.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExistCus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExistCus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExistCus.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExistCus.Location = new System.Drawing.Point(362, 137);
            this.btnExistCus.Name = "btnExistCus";
            this.btnExistCus.Size = new System.Drawing.Size(177, 183);
            this.btnExistCus.TabIndex = 25;
            this.btnExistCus.Text = "Register Existing Customer";
            this.btnExistCus.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExistCus.UseVisualStyleBackColor = false;
            this.btnExistCus.Click += new System.EventHandler(this.btnExistCus_Click);
            // 
            // picNewCus
            // 
            this.picNewCus.BackColor = System.Drawing.Color.DodgerBlue;
            this.picNewCus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picNewCus.BackgroundImage")));
            this.picNewCus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picNewCus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picNewCus.Location = new System.Drawing.Point(206, 173);
            this.picNewCus.Name = "picNewCus";
            this.picNewCus.Size = new System.Drawing.Size(78, 68);
            this.picNewCus.TabIndex = 24;
            this.picNewCus.TabStop = false;
            this.picNewCus.Click += new System.EventHandler(this.picNewCus_Click);
            // 
            // btnNewCus
            // 
            this.btnNewCus.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnNewCus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewCus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnNewCus.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNewCus.Location = new System.Drawing.Point(157, 137);
            this.btnNewCus.Name = "btnNewCus";
            this.btnNewCus.Size = new System.Drawing.Size(177, 183);
            this.btnNewCus.TabIndex = 23;
            this.btnNewCus.Text = "Register New Customer";
            this.btnNewCus.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNewCus.UseVisualStyleBackColor = false;
            this.btnNewCus.Click += new System.EventHandler(this.btnNewCus_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(206, 26);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(295, 45);
            this.lblTitle.TabIndex = 47;
            this.lblTitle.Text = "Register Customer";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(157, 100);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(110, 25);
            this.lblDescription.TabIndex = 49;
            this.lblDescription.Text = "Please select";
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBack.Location = new System.Drawing.Point(28, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(57, 60);
            this.btnBack.TabIndex = 50;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmRegNewOld
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(696, 383);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.picExistCus);
            this.Controls.Add(this.btnExistCus);
            this.Controls.Add(this.picNewCus);
            this.Controls.Add(this.btnNewCus);
            this.Name = "frmRegNewOld";
            this.Text = "Select Customer";
            ((System.ComponentModel.ISupportInitialize)(this.picExistCus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNewCus)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox picExistCus;
        private Button btnExistCus;
        private PictureBox picNewCus;
        private Button btnNewCus;
        private Label lblTitle;
        private Label lblDescription;
        private Button btnBack;
    }
}