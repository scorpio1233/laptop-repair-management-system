﻿namespace Assignment
{
    partial class FrmPending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lvPending = new System.Windows.Forms.ListView();
            this.order_ID = new System.Windows.Forms.ColumnHeader();
            this.cus_id = new System.Windows.Forms.ColumnHeader();
            this.cus_name = new System.Windows.Forms.ColumnHeader();
            this.service = new System.Windows.Forms.ColumnHeader();
            this.laptop = new System.Windows.Forms.ColumnHeader();
            this.status = new System.Windows.Forms.ColumnHeader();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnAddPending = new System.Windows.Forms.Button();
            this.btnBPending = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 9;
            // 
            // lvPending
            // 
            this.lvPending.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.order_ID,
            this.cus_id,
            this.cus_name,
            this.service,
            this.laptop,
            this.status});
            this.lvPending.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lvPending.FullRowSelect = true;
            this.lvPending.Location = new System.Drawing.Point(28, 113);
            this.lvPending.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lvPending.MultiSelect = false;
            this.lvPending.Name = "lvPending";
            this.lvPending.Size = new System.Drawing.Size(970, 385);
            this.lvPending.TabIndex = 5;
            this.lvPending.UseCompatibleStateImageBehavior = false;
            this.lvPending.View = System.Windows.Forms.View.Details;
            this.lvPending.SelectedIndexChanged += new System.EventHandler(this.lvPending_SelectedIndexChanged);
            // 
            // order_ID
            // 
            this.order_ID.Text = "Order ID";
            this.order_ID.Width = 100;
            // 
            // cus_id
            // 
            this.cus_id.Text = "Customer ID";
            this.cus_id.Width = 130;
            // 
            // cus_name
            // 
            this.cus_name.Text = "Customer Name";
            this.cus_name.Width = 180;
            // 
            // service
            // 
            this.service.Text = "Service Requested";
            this.service.Width = 200;
            // 
            // laptop
            // 
            this.laptop.Text = "Laptop Model";
            this.laptop.Width = 250;
            // 
            // status
            // 
            this.status.Text = "Status";
            this.status.Width = 100;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Gold;
            this.btnStart.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnStart.Location = new System.Drawing.Point(842, 524);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(142, 45);
            this.btnStart.TabIndex = 6;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnAddPending
            // 
            this.btnAddPending.BackColor = System.Drawing.Color.Azure;
            this.btnAddPending.Location = new System.Drawing.Point(760, 58);
            this.btnAddPending.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAddPending.Name = "btnAddPending";
            this.btnAddPending.Size = new System.Drawing.Size(224, 33);
            this.btnAddPending.TabIndex = 7;
            this.btnAddPending.Text = "Add new pending job";
            this.btnAddPending.UseVisualStyleBackColor = false;
            this.btnAddPending.Click += new System.EventHandler(this.btnAddPending_Click);
            // 
            // btnBPending
            // 
            this.btnBPending.BackColor = System.Drawing.Color.LightPink;
            this.btnBPending.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBPending.Location = new System.Drawing.Point(12, 12);
            this.btnBPending.Name = "btnBPending";
            this.btnBPending.Size = new System.Drawing.Size(96, 36);
            this.btnBPending.TabIndex = 8;
            this.btnBPending.Text = "Back";
            this.btnBPending.UseVisualStyleBackColor = false;
            this.btnBPending.Click += new System.EventHandler(this.btnBPending_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(127, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 41);
            this.label2.TabIndex = 11;
            this.label2.Text = "PENDING JOB";
            // 
            // FrmPending
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(1021, 591);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBPending);
            this.Controls.Add(this.btnAddPending);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lvPending);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmPending";
            this.Text = "Pending Job";
            this.Load += new System.EventHandler(this.FrmPending_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label1;
        private ListView lvPending;
        private ColumnHeader laptop;
        private ColumnHeader service;
        private ColumnHeader status;
        private Button btnStart;
        private Button btnAddPending;
        private Button btnBPending;
        private ColumnHeader order_ID;
        private Label label2;
        private ColumnHeader cus_name;
        private ColumnHeader cus_id;
    }
}