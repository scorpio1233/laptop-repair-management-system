﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmCollection : Form
    {
        public static string orderId;
        public static string cusid;
        public static string cusname;
        public static string service;
        public static string laptop;
        public FrmCollection(string ordid, string idcus, string namecus, string serv, string lp)
        {
            InitializeComponent();
            orderId = ordid;
            cusid = idcus;
            cusname = namecus;
            service = serv;
            laptop = lp;
        }

        private void FrmCollection_Load(object sender, EventArgs e)
        {
            job obj1 = new job(orderId);
            lblDate.Text = obj1.getdate(orderId);
            lblOrdId.Text = orderId;
            lblCusId.Text = cusid;
            lblCusName.Text = cusname;
            lblServ.Text = service;
            lblLaptop.Text = laptop;
        }

        private void btnBCollect_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
