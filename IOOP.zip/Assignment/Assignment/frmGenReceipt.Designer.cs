﻿namespace Assignment
{
    partial class frmGenReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGenReceipt));
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.grpReceipt = new System.Windows.Forms.GroupBox();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.lblNoRecord = new System.Windows.Forms.Label();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.lblFilter = new System.Windows.Forms.Label();
            this.lvReceipt = new System.Windows.Forms.ListView();
            this.columnReceiptNo = new System.Windows.Forms.ColumnHeader();
            this.columnDate = new System.Windows.Forms.ColumnHeader();
            this.columnOrderID = new System.Windows.Forms.ColumnHeader();
            this.columnService = new System.Windows.Forms.ColumnHeader();
            this.columnTotal = new System.Windows.Forms.ColumnHeader();
            this.btnSearch = new System.Windows.Forms.Button();
            this.grpReceipt.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(317, 27);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(274, 45);
            this.lblTitle.TabIndex = 32;
            this.lblTitle.Text = "Generate Receipt";
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.Blue;
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPrint.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPrint.Location = new System.Drawing.Point(387, 407);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(134, 50);
            this.btnPrint.TabIndex = 38;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(57, 60);
            this.btnBack.TabIndex = 39;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // grpReceipt
            // 
            this.grpReceipt.BackColor = System.Drawing.Color.LightBlue;
            this.grpReceipt.Controls.Add(this.btnViewAll);
            this.grpReceipt.Controls.Add(this.lblNoRecord);
            this.grpReceipt.Controls.Add(this.datePicker);
            this.grpReceipt.Controls.Add(this.lblFilter);
            this.grpReceipt.Controls.Add(this.lvReceipt);
            this.grpReceipt.Controls.Add(this.btnSearch);
            this.grpReceipt.Location = new System.Drawing.Point(23, 98);
            this.grpReceipt.Name = "grpReceipt";
            this.grpReceipt.Size = new System.Drawing.Size(863, 286);
            this.grpReceipt.TabIndex = 49;
            this.grpReceipt.TabStop = false;
            this.grpReceipt.Text = "Select Receipt";
            // 
            // btnViewAll
            // 
            this.btnViewAll.BackColor = System.Drawing.Color.Orange;
            this.btnViewAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnViewAll.ForeColor = System.Drawing.Color.Black;
            this.btnViewAll.Location = new System.Drawing.Point(670, 30);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(112, 34);
            this.btnViewAll.TabIndex = 44;
            this.btnViewAll.Text = "View All";
            this.btnViewAll.UseVisualStyleBackColor = false;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // lblNoRecord
            // 
            this.lblNoRecord.AutoSize = true;
            this.lblNoRecord.BackColor = System.Drawing.SystemColors.Control;
            this.lblNoRecord.Location = new System.Drawing.Point(355, 170);
            this.lblNoRecord.Name = "lblNoRecord";
            this.lblNoRecord.Size = new System.Drawing.Size(152, 25);
            this.lblNoRecord.TabIndex = 43;
            this.lblNoRecord.Text = "No Record Found";
            this.lblNoRecord.Visible = false;
            // 
            // datePicker
            // 
            this.datePicker.CustomFormat = "";
            this.datePicker.Location = new System.Drawing.Point(187, 30);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(300, 31);
            this.datePicker.TabIndex = 42;
            this.datePicker.Value = new System.DateTime(2022, 6, 6, 0, 23, 31, 0);
            // 
            // lblFilter
            // 
            this.lblFilter.AutoSize = true;
            this.lblFilter.Location = new System.Drawing.Point(54, 35);
            this.lblFilter.Name = "lblFilter";
            this.lblFilter.Size = new System.Drawing.Size(116, 25);
            this.lblFilter.TabIndex = 41;
            this.lblFilter.Text = "Filter By Date";
            // 
            // lvReceipt
            // 
            this.lvReceipt.BackColor = System.Drawing.SystemColors.Control;
            this.lvReceipt.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnReceiptNo,
            this.columnDate,
            this.columnOrderID,
            this.columnService,
            this.columnTotal});
            this.lvReceipt.FullRowSelect = true;
            this.lvReceipt.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.lvReceipt.Location = new System.Drawing.Point(11, 87);
            this.lvReceipt.Name = "lvReceipt";
            this.lvReceipt.Size = new System.Drawing.Size(841, 176);
            this.lvReceipt.TabIndex = 40;
            this.lvReceipt.UseCompatibleStateImageBehavior = false;
            this.lvReceipt.View = System.Windows.Forms.View.Details;
            // 
            // columnReceiptNo
            // 
            this.columnReceiptNo.Text = "Receipt No";
            this.columnReceiptNo.Width = 120;
            // 
            // columnDate
            // 
            this.columnDate.Text = "Date";
            this.columnDate.Width = 120;
            // 
            // columnOrderID
            // 
            this.columnOrderID.Text = "Order ID";
            this.columnOrderID.Width = 120;
            // 
            // columnService
            // 
            this.columnService.Text = "Service Requested";
            this.columnService.Width = 340;
            // 
            // columnTotal
            // 
            this.columnTotal.Text = "Total (RM)";
            this.columnTotal.Width = 100;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSearch.Location = new System.Drawing.Point(524, 30);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(112, 34);
            this.btnSearch.TabIndex = 38;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // frmGenReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(908, 480);
            this.Controls.Add(this.grpReceipt);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.lblTitle);
            this.Name = "frmGenReceipt";
            this.Text = "Generate Receipt";
            this.Load += new System.EventHandler(this.frmGenReceipt_Load);
            this.grpReceipt.ResumeLayout(false);
            this.grpReceipt.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label lblTitle;
        private Button btnPrint;
        private Button btnBack;
        private GroupBox grpReceipt;
        private Label lblFilter;
        private ListView lvReceipt;
        private ColumnHeader columnReceiptNo;
        private ColumnHeader columnDate;
        private ColumnHeader columnOrderID;
        private ColumnHeader columnService;
        private ColumnHeader columnTotal;
        private Button btnSearch;
        private DateTimePicker datePicker;
        private Label lblNoRecord;
        private Button btnViewAll;
    }
}