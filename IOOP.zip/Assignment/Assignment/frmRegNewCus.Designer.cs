﻿namespace Assignment
{
    partial class frmRegNewCus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegNewCus));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.lblRemark = new System.Windows.Forms.Label();
            this.txtPhoneNum = new System.Windows.Forms.TextBox();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.lblService = new System.Windows.Forms.Label();
            this.radNormal = new System.Windows.Forms.RadioButton();
            this.radUrgent = new System.Windows.Forms.RadioButton();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.grpService = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.grpService.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(113, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(372, 45);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Register New Customer";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(80, 78);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(141, 25);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Customer Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(88, 116);
            this.txtName.Name = "txtName";
            this.txtName.PlaceholderText = "Name";
            this.txtName.Size = new System.Drawing.Size(436, 31);
            this.txtName.TabIndex = 2;
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.AutoSize = true;
            this.lblPhoneNum.Location = new System.Drawing.Point(80, 169);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(143, 25);
            this.lblPhoneNum.TabIndex = 4;
            this.lblPhoneNum.Text = "Contact Number";
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(30, 139);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(71, 25);
            this.lblRemark.TabIndex = 16;
            this.lblRemark.Text = "Remark";
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Location = new System.Drawing.Point(88, 207);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.PlaceholderText = "XXX-XXXXXXX";
            this.txtPhoneNum.Size = new System.Drawing.Size(436, 31);
            this.txtPhoneNum.TabIndex = 19;
            // 
            // cmbService
            // 
            this.cmbService.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Items.AddRange(new object[] {
            "Remove virus, malware or spyware",
            "Troubleshot and fix computer running slow",
            "Laptop screen replacement",
            "Laptop keyboard replacement",
            "Laptop battery replacement",
            "Operating System Format and Installation",
            "Data backup and recovery",
            "Internet connectivity issues"});
            this.cmbService.Location = new System.Drawing.Point(117, 39);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(343, 33);
            this.cmbService.TabIndex = 14;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(30, 42);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(67, 25);
            this.lblService.TabIndex = 15;
            this.lblService.Text = "Service";
            // 
            // radNormal
            // 
            this.radNormal.AutoSize = true;
            this.radNormal.Checked = true;
            this.radNormal.Location = new System.Drawing.Point(136, 92);
            this.radNormal.Name = "radNormal";
            this.radNormal.Size = new System.Drawing.Size(96, 29);
            this.radNormal.TabIndex = 16;
            this.radNormal.TabStop = true;
            this.radNormal.Text = "Normal";
            this.radNormal.UseVisualStyleBackColor = true;
            // 
            // radUrgent
            // 
            this.radUrgent.AutoSize = true;
            this.radUrgent.Location = new System.Drawing.Point(338, 92);
            this.radUrgent.Name = "radUrgent";
            this.radUrgent.Size = new System.Drawing.Size(91, 29);
            this.radUrgent.TabIndex = 17;
            this.radUrgent.Text = "Urgent";
            this.radUrgent.UseVisualStyleBackColor = true;
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(117, 139);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.PlaceholderText = "Laptop Model";
            this.txtRemark.Size = new System.Drawing.Size(343, 31);
            this.txtRemark.TabIndex = 17;
            // 
            // grpService
            // 
            this.grpService.Controls.Add(this.txtRemark);
            this.grpService.Controls.Add(this.radUrgent);
            this.grpService.Controls.Add(this.radNormal);
            this.grpService.Controls.Add(this.lblService);
            this.grpService.Controls.Add(this.cmbService);
            this.grpService.Controls.Add(this.lblRemark);
            this.grpService.Location = new System.Drawing.Point(56, 539);
            this.grpService.Name = "grpService";
            this.grpService.Size = new System.Drawing.Size(490, 205);
            this.grpService.TabIndex = 15;
            this.grpService.TabStop = false;
            this.grpService.Text = "Service Requested";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(88, 298);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PlaceholderText = "XXX@XX.com";
            this.txtEmail.Size = new System.Drawing.Size(436, 31);
            this.txtEmail.TabIndex = 21;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(80, 260);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(54, 25);
            this.lblEmail.TabIndex = 20;
            this.lblEmail.Text = "Email";
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(88, 435);
            this.txtCity.Name = "txtCity";
            this.txtCity.PlaceholderText = "City";
            this.txtCity.Size = new System.Drawing.Size(200, 31);
            this.txtCity.TabIndex = 24;
            // 
            // txtPostcode
            // 
            this.txtPostcode.Location = new System.Drawing.Point(88, 483);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.PlaceholderText = "Postcode";
            this.txtPostcode.Size = new System.Drawing.Size(436, 31);
            this.txtPostcode.TabIndex = 26;
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(88, 389);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.PlaceholderText = "Street Address";
            this.txtStreet.Size = new System.Drawing.Size(436, 31);
            this.txtStreet.TabIndex = 28;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(80, 351);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(77, 25);
            this.lblAddress.TabIndex = 27;
            this.lblAddress.Text = "Address";
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(325, 435);
            this.txtState.Name = "txtState";
            this.txtState.PlaceholderText = "State";
            this.txtState.Size = new System.Drawing.Size(200, 31);
            this.txtState.TabIndex = 29;
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.Blue;
            this.btnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegister.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRegister.Location = new System.Drawing.Point(351, 769);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(134, 50);
            this.btnRegister.TabIndex = 45;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(57, 60);
            this.btnBack.TabIndex = 47;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Salmon;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClear.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClear.Location = new System.Drawing.Point(98, 769);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(134, 50);
            this.btnClear.TabIndex = 49;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmRegNewCus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(603, 836);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtPostcode);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtPhoneNum);
            this.Controls.Add(this.grpService);
            this.Controls.Add(this.lblPhoneNum);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblTitle);
            this.Name = "frmRegNewCus";
            this.Text = "Register New Customer";
            this.Load += new System.EventHandler(this.frmRegNewCus_Load);
            this.grpService.ResumeLayout(false);
            this.grpService.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label lblName;
        private TextBox txtName;
        private Label lblPhoneNum;
        private Label lblRemark;
        private TextBox txtPhoneNum;
        private ComboBox cmbService;
        private Label lblService;
        private RadioButton radNormal;
        private RadioButton radUrgent;
        private TextBox txtRemark;
        private GroupBox grpService;
        private TextBox txtEmail;
        private Label lblEmail;
        private TextBox txtCity;
        private TextBox txtPostcode;
        private TextBox txtStreet;
        private Label lblAddress;
        private TextBox txtState;
        private Button btnRegister;
        private Button btnBack;
        private Button btnClear;
    }
}