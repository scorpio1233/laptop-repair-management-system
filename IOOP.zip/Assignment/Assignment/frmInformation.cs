﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmInformation : Form
    {
        public static string Date;
        public static string OrderID;
        public static string TechID;
        public static string Desc;

        public frmInformation()
        {
            InitializeComponent();
        }

        public frmInformation(string sdate, string sorderID, string stechID, string sdesc)
        {
            InitializeComponent();
            Date = sdate;
            OrderID = sorderID;
            TechID = stechID;
            Desc = sdesc;
        }

        private void frmInformation_Load(object sender, EventArgs e)
        {
            ArrayList allservice = new ArrayList();
            lblOrderID.Text = OrderID;
            lblTech.Text = TechID;
            lblDate.Text = Date;
            lblSerDescribe.Text = Desc;
            Admin ad = new Admin(OrderID, Date);
            allservice = ad.showSerInfo(); //CustomerID, Laptop, Status, total
            lblCusName.Text = allservice[0].ToString();
            lblModel.Text = allservice[1].ToString();
            lblStat.Text = allservice[2].ToString();
            lblPrice.Text = allservice[3].ToString();


        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
