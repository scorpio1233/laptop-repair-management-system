﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmFilter : Form
    {
        public static string techEmail;
        public static string techid;
        public FrmFilter(string email, string id)
        {
            InitializeComponent();
            techEmail = email;
            techid = id;
        }

        private void FrmFilter_Load(object sender, EventArgs e)
        {
            cmbFilter.SelectedItem = "Status";
            cmbStatus.SelectedItem = "Urgent";
           
        }

        private void cmbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFilter.SelectedItem == "Status")
            {
                cmbStatus.Show();
                cmbItems.Hide();
            }
            else
            {
                cmbStatus.Hide();
                cmbItems.Show();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            string filter = "";
            FrmViewJob form = new FrmViewJob(techEmail, techid, filter);
            form.Show();
            this.Close();
        }

        private void btnGO_Click(object sender, EventArgs e)
        {
            string filter ="";
            if (cmbFilter.SelectedItem == "Status")
            {
                if (cmbStatus.SelectedItem == "Urgent")
                {
                    filter = "1";
                }
                else
                    filter = "2";
            }
            if (cmbFilter.SelectedItem == "Service Requested")
            {
                if (cmbItems.SelectedItem == "Remove virus, malware or spyware")
                    filter = "3";
                else if(cmbItems.SelectedItem == "Troubleshoot and fix computer running slow")
                    filter = "4";
                else if (cmbItems.SelectedItem == "Laptop Screen Replacement")
                    filter = "5";
                else if (cmbItems.SelectedItem == "Laptop keyboard replacement")
                    filter = "6";
                else if (cmbItems.SelectedItem == "Laptop battery replacement")
                    filter = "7";
                else if (cmbItems.SelectedItem == "Operating System Format and installation")
                    filter = "8";
                else if (cmbItems.SelectedItem == "Data backup and recovery")
                    filter = "9";
                else if (cmbItems.SelectedItem == "Internet connectivity issues")
                    filter = "10";
            }


            FrmViewJob form = new FrmViewJob(techEmail, techid, filter);
            form.Show();
            this.Close();
        }
    }
}
