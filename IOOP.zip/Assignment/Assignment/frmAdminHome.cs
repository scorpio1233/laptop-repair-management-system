namespace Assignment
{
    public partial class frmAdminHome : Form
    {
        public static string email;
        public static string name;
        public frmAdminHome()
        {
            InitializeComponent();
        }

        public frmAdminHome(string em)
        {
            InitializeComponent();
            email = em;

        }

        private void btnRegTech_Click(object sender, EventArgs e)
        {
            frmRegTech f2 = new frmRegTech();
            f2.ShowDialog();
        }

        private void btnRegRep_Click(object sender, EventArgs e)
        {
            frmRegRecp f3 = new frmRegRecp();
            f3.ShowDialog();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            frmServiceReport f4 = new frmServiceReport();
            f4.ShowDialog();
        }

        private void btnIncome_Click(object sender, EventArgs e)
        {
            frmTotalIncome f5 = new frmTotalIncome();
            f5.ShowDialog();
        }

        private void frmAdminHome_Load(object sender, EventArgs e)
        {
            displayProfile();
        }

        public void displayProfile()
        {
            Admin obj1 = new Admin(email);
            Admin.viewProfile(obj1);
            string adminID1 = "ID: ADM";
            if (obj1.AdminID < 10)
                adminID1 += ("000" + obj1.AdminID.ToString());
            else if (obj1.AdminID < 100 && obj1.AdminID >= 10)
                adminID1 += ("00" + obj1.AdminID.ToString());
            else if (obj1.AdminID < 1000 && obj1.AdminID >= 100)
                adminID1 += ("0" + obj1.AdminID.ToString());
            else
                adminID1 += obj1.AdminID.ToString();

            lblName.Text = obj1.Name;
            lblAdmainID.Text = adminID1;

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmAdmPro ap = new frmAdmPro(email);
            ap.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            FrmChangePass form = new FrmChangePass(email);
            form.Show();
        }

        private void btnSQ_Click(object sender, EventArgs e)
        {
            FrmSetSecure form = new FrmSetSecure(email);
            form.Show();
        }
    }
}