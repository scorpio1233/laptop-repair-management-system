﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmCustomerProfile : Form
    {
        public static string email;
        public frmCustomerProfile()
        {
            InitializeComponent();
        }
        public frmCustomerProfile(string e)
        {
            InitializeComponent();
            email = e;

        }
      
        private void label6_Click(object sender, EventArgs e)
        {
            frmCusChangePic obj1 = new frmCusChangePic(email);
            obj1.ShowDialog();
            displayDetail();
        }

    

        private void Profile_Load(object sender, EventArgs e)
        {
            displayDetail();
        }

      

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (checkEmpty() == false)
            {
                if (Int32.TryParse(txtPostcode.Text, out int postcodeNum) && txtPostcode.Text.Length == 5)
                {
                    customer obj1 = new customer(email);
                    MessageBox.Show(obj1.updateProfile(txtContactNumber.Text, txtStreet.Text, txtCity.Text, txtState.Text, txtPostcode.Text));
                }
                else
                    MessageBox.Show("Postcode must be 5-digit number");
            }
            else
                MessageBox.Show("All text box cannot be empty.");
        }



        private void btnMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Display personal information
        public void displayDetail()
        {
            customer obj1 = new customer(email);
            string CustomerID = obj1.showID();
            customer.viewProfile(obj1);

            txtEmail.Text = obj1.Email;
            txtContactNumber.Text = obj1.TelNum;
            txtState.Text = obj1.State;
            txtStreet.Text = obj1.Street;
            txtCity.Text = obj1.City;
            txtPostcode.Text = obj1.Postcode.ToString();            
            lblName.Text = obj1.Name;

            string customerID = "ID: CUS";
            if (CustomerID.Length == 1)
                customerID += ("000" + CustomerID);
            else if (CustomerID.Length == 2)
                customerID += ("00" + CustomerID);
            else if (CustomerID.Length == 3)
                customerID += ("0" + CustomerID);
            else
                customerID += CustomerID;
            lblID.Text = customerID;

            if (obj1.PicID == "PIC01")
            {
                picGirl.Visible = false;
                picBoy.Visible = true;
            }
            else if (obj1.PicID == "PIC02")
            {
                picGirl.Visible = true;
                picBoy.Visible = false;
            }
        }

        public bool checkEmpty()
        {
            bool empty = false;
            if (txtContactNumber.Text == string.Empty || txtContactNumber.Text == string.Empty || txtState.Text == string.Empty || txtStreet.Text == string.Empty || txtCity.Text == string.Empty || txtPostcode.Text == string.Empty)
                empty = true;
            return empty;
        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            FrmChangePass obj1 = new FrmChangePass(email);
            obj1.ShowDialog();
        }

        private void btnSetSecurity_Click(object sender, EventArgs e)
        {
            FrmSetSecure obj1 = new FrmSetSecure(email);
            obj1.ShowDialog();
        }
    }


}
