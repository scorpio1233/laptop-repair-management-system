﻿namespace Assignment
{
    partial class frmChangeRequestedService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblRequest = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnUpdateRequest = new System.Windows.Forms.Button();
            this.lstUr = new System.Windows.Forms.ListBox();
            this.lstService = new System.Windows.Forms.ListBox();
            this.lblUr = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(204, 28);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(462, 48);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Change Requested Service";
            // 
            // lblRequest
            // 
            this.lblRequest.AutoSize = true;
            this.lblRequest.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRequest.Location = new System.Drawing.Point(130, 101);
            this.lblRequest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRequest.Name = "lblRequest";
            this.lblRequest.Size = new System.Drawing.Size(289, 30);
            this.lblRequest.TabIndex = 2;
            this.lblRequest.Text = "Select the request to change :";
            // 
            // btnMenu
            // 
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMenu.Location = new System.Drawing.Point(163, 449);
            this.btnMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(183, 64);
            this.btnMenu.TabIndex = 5;
            this.btnMenu.Text = "Back to Menu";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnUpdateRequest
            // 
            this.btnUpdateRequest.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateRequest.Location = new System.Drawing.Point(504, 449);
            this.btnUpdateRequest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUpdateRequest.Name = "btnUpdateRequest";
            this.btnUpdateRequest.Size = new System.Drawing.Size(214, 64);
            this.btnUpdateRequest.TabIndex = 6;
            this.btnUpdateRequest.Text = "Update Request";
            this.btnUpdateRequest.UseVisualStyleBackColor = true;
            this.btnUpdateRequest.Click += new System.EventHandler(this.btnUpdateRequest_Click);
            // 
            // lstUr
            // 
            this.lstUr.FormattingEnabled = true;
            this.lstUr.ItemHeight = 25;
            this.lstUr.Items.AddRange(new object[] {
            "Urgent ",
            "Normal"});
            this.lstUr.Location = new System.Drawing.Point(130, 308);
            this.lstUr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstUr.Name = "lstUr";
            this.lstUr.Size = new System.Drawing.Size(629, 54);
            this.lstUr.TabIndex = 20;
            // 
            // lstService
            // 
            this.lstService.FormattingEnabled = true;
            this.lstService.ItemHeight = 25;
            this.lstService.Items.AddRange(new object[] {
            "Remove virus, malware or spyware",
            "Troubleshot and fix computer running slow",
            "Laptop screen replacement",
            "Laptop keyboard replacement",
            "Laptop battery replacement",
            "Operating System Format and Installation",
            "Data backup and recovery",
            "Internet connectivity issues"});
            this.lstService.Location = new System.Drawing.Point(130, 134);
            this.lstService.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstService.Name = "lstService";
            this.lstService.Size = new System.Drawing.Size(629, 129);
            this.lstService.TabIndex = 21;
            // 
            // lblUr
            // 
            this.lblUr.AutoSize = true;
            this.lblUr.Location = new System.Drawing.Point(130, 279);
            this.lblUr.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUr.Name = "lblUr";
            this.lblUr.Size = new System.Drawing.Size(161, 25);
            this.lblUr.TabIndex = 22;
            this.lblUr.Text = "Urgent or Normal :";
            // 
            // frmChangeRequestedService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(889, 562);
            this.Controls.Add(this.lblUr);
            this.Controls.Add(this.lstService);
            this.Controls.Add(this.lstUr);
            this.Controls.Add(this.btnUpdateRequest);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.lblRequest);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmChangeRequestedService";
            this.Text = "Change Requested Service";
            this.Load += new System.EventHandler(this.frmChangeRequestedService_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label lblRequest;
        private Button btnMenu;
        private Button btnUpdateRequest;
        private ListBox lstUr;
        private ListBox lstService;
        private Label lblUr;
    }
}