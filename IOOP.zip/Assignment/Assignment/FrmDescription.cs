﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmDescription : Form
    {
        public static string orderId;
        public static string cusid;
        public static string cusname;
        public static string service;
        public static string laptop;
        public static string status;

        public FrmDescription(string id, string idcus, string namecus, string serv, string lp, string sta)
        {
            InitializeComponent();
            orderId = id;
            cusid = idcus;
            cusname = namecus;
            service = serv;
            laptop = lp;
            status = sta;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            job obj1 = new job(orderId);
            MessageBox.Show(obj1.updatedesc(txtDescription.Text, orderId));
            this.Close();

            //refresh the servicing form
            FrmServicing form = new FrmServicing(orderId, cusid, cusname, service, laptop, status);
            form.Show();
        }

        private void FrmDescription_Load(object sender, EventArgs e)
        {
            lblCusName.Text = cusname;
            lblLaptop.Text = laptop;
            lblService.Text = service;
            job obj1 = new job(orderId);
            txtDescription.Text = obj1.getdesc(orderId);
        }
    }
}
