﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmRegTech : Form
    {
        public frmRegTech()
        {
            InitializeComponent();
        }


        private void btnDone_Click(object sender, EventArgs e)
        {
            string[] emtpy = new[] { txtName.Text, txtNumber.Text, txtEmail.Text, txtStart.Text, txtEnd.Text};
            bool noVal = false;
            for (int i = 0; i < emtpy.Length; i++)
            {
                if(emtpy[i] == String.Empty)
                    noVal = true;
            }

            if (noVal == false)
            {
                if (txtEmail.Text.Contains(".") && txtEmail.Text.Contains("@"))
                {
                   
                    AdmTechnician obj1 = new AdmTechnician(txtName.Text, txtNumber.Text, txtEmail.Text, txtStart.Text, txtEnd.Text);
                    string result = obj1.addTechnician();
                    MessageBox.Show(result, "Result");
                }
                else
                    MessageBox.Show("Your email must contain @ and .");
            }
            else
                MessageBox.Show("Please fill in your information");

            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
