﻿namespace Assignment
{
    partial class frmAdminHome
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdminHome));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblAdmainID = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.lblID = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpDash = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnIncome = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnRegRep = new System.Windows.Forms.Button();
            this.btnRegTech = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnChangePass = new System.Windows.Forms.Button();
            this.btnSQ = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpDash.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.lblAdmainID);
            this.panel1.Controls.Add(this.btnEdit);
            this.panel1.Controls.Add(this.lblID);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblUser);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(28, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(511, 566);
            this.panel1.TabIndex = 0;
            // 
            // lblAdmainID
            // 
            this.lblAdmainID.AutoSize = true;
            this.lblAdmainID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAdmainID.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAdmainID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAdmainID.Location = new System.Drawing.Point(195, 488);
            this.lblAdmainID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAdmainID.Name = "lblAdmainID";
            this.lblAdmainID.Size = new System.Drawing.Size(2, 26);
            this.lblAdmainID.TabIndex = 6;
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnEdit.Location = new System.Drawing.Point(455, 530);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(56, 36);
            this.btnEdit.TabIndex = 5;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblID.Location = new System.Drawing.Point(150, 488);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 24);
            this.lblID.TabIndex = 3;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Sitka Banner", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblName.Location = new System.Drawing.Point(240, 416);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(0, 58);
            this.lblName.TabIndex = 2;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Showcard Gothic", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblUser.ForeColor = System.Drawing.Color.SandyBrown;
            this.lblUser.Location = new System.Drawing.Point(150, 351);
            this.lblUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(194, 65);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Admin";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(76, 16);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(329, 318);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // grpDash
            // 
            this.grpDash.BackColor = System.Drawing.Color.MediumTurquoise;
            this.grpDash.Controls.Add(this.label4);
            this.grpDash.Controls.Add(this.label3);
            this.grpDash.Controls.Add(this.label2);
            this.grpDash.Controls.Add(this.label1);
            this.grpDash.Controls.Add(this.btnIncome);
            this.grpDash.Controls.Add(this.btnReport);
            this.grpDash.Controls.Add(this.btnRegRep);
            this.grpDash.Controls.Add(this.btnRegTech);
            this.grpDash.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpDash.Location = new System.Drawing.Point(586, 15);
            this.grpDash.Margin = new System.Windows.Forms.Padding(4);
            this.grpDash.Name = "grpDash";
            this.grpDash.Padding = new System.Windows.Forms.Padding(4);
            this.grpDash.Size = new System.Drawing.Size(594, 631);
            this.grpDash.TabIndex = 1;
            this.grpDash.TabStop = false;
            this.grpDash.Text = "Dashboard";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(341, 396);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Monthly";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(45, 396);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "Monthly";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(341, 116);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Register";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(45, 116);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Register";
            // 
            // btnIncome
            // 
            this.btnIncome.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnIncome.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnIncome.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnIncome.Location = new System.Drawing.Point(330, 384);
            this.btnIncome.Margin = new System.Windows.Forms.Padding(4);
            this.btnIncome.Name = "btnIncome";
            this.btnIncome.Size = new System.Drawing.Size(245, 182);
            this.btnIncome.TabIndex = 3;
            this.btnIncome.Text = "Total \r\n          Income";
            this.btnIncome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIncome.UseVisualStyleBackColor = false;
            this.btnIncome.Click += new System.EventHandler(this.btnIncome_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnReport.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnReport.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnReport.Location = new System.Drawing.Point(32, 381);
            this.btnReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(245, 185);
            this.btnReport.TabIndex = 2;
            this.btnReport.Text = "Service \r\n             Report";
            this.btnReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.UseVisualStyleBackColor = false;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnRegRep
            // 
            this.btnRegRep.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnRegRep.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegRep.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRegRep.Location = new System.Drawing.Point(330, 101);
            this.btnRegRep.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegRep.Name = "btnRegRep";
            this.btnRegRep.Size = new System.Drawing.Size(245, 182);
            this.btnRegRep.TabIndex = 1;
            this.btnRegRep.Text = "Receptionist";
            this.btnRegRep.UseVisualStyleBackColor = false;
            this.btnRegRep.Click += new System.EventHandler(this.btnRegRep_Click);
            // 
            // btnRegTech
            // 
            this.btnRegTech.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnRegTech.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegTech.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRegTech.Location = new System.Drawing.Point(32, 101);
            this.btnRegTech.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegTech.Name = "btnRegTech";
            this.btnRegTech.Size = new System.Drawing.Size(245, 182);
            this.btnRegTech.TabIndex = 0;
            this.btnRegTech.Text = "Technician";
            this.btnRegTech.UseVisualStyleBackColor = false;
            this.btnRegTech.Click += new System.EventHandler(this.btnRegTech_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.Location = new System.Drawing.Point(15, 610);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(118, 36);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnChangePass
            // 
            this.btnChangePass.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnChangePass.Location = new System.Drawing.Point(140, 610);
            this.btnChangePass.Margin = new System.Windows.Forms.Padding(4);
            this.btnChangePass.Name = "btnChangePass";
            this.btnChangePass.Size = new System.Drawing.Size(191, 36);
            this.btnChangePass.TabIndex = 3;
            this.btnChangePass.Text = "Change Password";
            this.btnChangePass.UseMnemonic = false;
            this.btnChangePass.UseVisualStyleBackColor = true;
            this.btnChangePass.Click += new System.EventHandler(this.btnChangePass_Click);
            // 
            // btnSQ
            // 
            this.btnSQ.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSQ.Location = new System.Drawing.Point(339, 610);
            this.btnSQ.Margin = new System.Windows.Forms.Padding(4);
            this.btnSQ.Name = "btnSQ";
            this.btnSQ.Size = new System.Drawing.Size(222, 36);
            this.btnSQ.TabIndex = 4;
            this.btnSQ.Text = "Set Secirity Password";
            this.btnSQ.UseMnemonic = false;
            this.btnSQ.UseVisualStyleBackColor = true;
            this.btnSQ.Click += new System.EventHandler(this.btnSQ_Click);
            // 
            // frmAdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(1195, 661);
            this.Controls.Add(this.btnSQ);
            this.Controls.Add(this.btnChangePass);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.grpDash);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmAdminHome";
            this.Text = "Admin Home Page";
            this.Load += new System.EventHandler(this.frmAdminHome_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpDash.ResumeLayout(false);
            this.grpDash.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Label lblUser;
        private PictureBox pictureBox1;
        private Label lblID;
        private Label lblName;
        private GroupBox grpDash;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnIncome;
        private Button btnReport;
        private Button btnRegRep;
        private Button btnRegTech;
        private Button btnLogout;
        private Button btnChangePass;
        private Button btnSQ;
        private Button btnEdit;
        private Label lblAdmainID;
    }
}