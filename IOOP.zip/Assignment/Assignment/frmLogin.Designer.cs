﻿namespace Assignment
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.picMascot = new System.Windows.Forms.PictureBox();
            this.txtPwd = new System.Windows.Forms.TextBox();
            this.lblPwd = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.panelUsername = new System.Windows.Forms.Panel();
            this.picEmail = new System.Windows.Forms.PictureBox();
            this.panelPwd = new System.Windows.Forms.Panel();
            this.btnHide = new System.Windows.Forms.Button();
            this.btnVisible = new System.Windows.Forms.Button();
            this.picPwd = new System.Windows.Forms.PictureBox();
            this.btnForgot = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picMascot)).BeginInit();
            this.panelUsername.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEmail)).BeginInit();
            this.panelPwd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPwd)).BeginInit();
            this.SuspendLayout();
            // 
            // picMascot
            // 
            this.picMascot.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.picMascot.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picMascot.BackgroundImage")));
            this.picMascot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picMascot.Location = new System.Drawing.Point(70, 84);
            this.picMascot.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picMascot.Name = "picMascot";
            this.picMascot.Size = new System.Drawing.Size(207, 258);
            this.picMascot.TabIndex = 20;
            this.picMascot.TabStop = false;
            // 
            // txtPwd
            // 
            this.txtPwd.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPwd.Location = new System.Drawing.Point(37, 6);
            this.txtPwd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPwd.Name = "txtPwd";
            this.txtPwd.PasswordChar = '*';
            this.txtPwd.PlaceholderText = "Enter your password";
            this.txtPwd.Size = new System.Drawing.Size(183, 20);
            this.txtPwd.TabIndex = 18;
            // 
            // lblPwd
            // 
            this.lblPwd.AutoSize = true;
            this.lblPwd.Location = new System.Drawing.Point(334, 195);
            this.lblPwd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPwd.Name = "lblPwd";
            this.lblPwd.Size = new System.Drawing.Size(70, 20);
            this.lblPwd.TabIndex = 17;
            this.lblPwd.Text = "Password";
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Location = new System.Drawing.Point(37, 6);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PlaceholderText = "Enter your email";
            this.txtEmail.Size = new System.Drawing.Size(196, 20);
            this.txtEmail.TabIndex = 16;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(334, 124);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(50, 20);
            this.lblUsername.TabIndex = 15;
            this.lblUsername.Text = "Email ";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblWelcome.Location = new System.Drawing.Point(302, 93);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(198, 23);
            this.lblWelcome.TabIndex = 14;
            this.lblWelcome.Text = "Welcome. Please Login.";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTitle.Location = new System.Drawing.Point(89, 22);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(489, 50);
            this.lblTitle.TabIndex = 24;
            this.lblTitle.Text = "FIX-IT-FELIX Laptop Repair";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Orange;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClear.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnClear.Location = new System.Drawing.Point(339, 299);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(109, 33);
            this.btnClear.TabIndex = 26;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Blue;
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogin.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnLogin.Location = new System.Drawing.Point(461, 299);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(109, 33);
            this.btnLogin.TabIndex = 25;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // panelUsername
            // 
            this.panelUsername.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelUsername.Controls.Add(this.picEmail);
            this.panelUsername.Controls.Add(this.txtEmail);
            this.panelUsername.Location = new System.Drawing.Point(334, 150);
            this.panelUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelUsername.Name = "panelUsername";
            this.panelUsername.Size = new System.Drawing.Size(235, 33);
            this.panelUsername.TabIndex = 27;
            // 
            // picEmail
            // 
            this.picEmail.BackColor = System.Drawing.Color.White;
            this.picEmail.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picEmail.BackgroundImage")));
            this.picEmail.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picEmail.Location = new System.Drawing.Point(2, 2);
            this.picEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picEmail.Name = "picEmail";
            this.picEmail.Size = new System.Drawing.Size(32, 28);
            this.picEmail.TabIndex = 30;
            this.picEmail.TabStop = false;
            // 
            // panelPwd
            // 
            this.panelPwd.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelPwd.Controls.Add(this.btnHide);
            this.panelPwd.Controls.Add(this.btnVisible);
            this.panelPwd.Controls.Add(this.picPwd);
            this.panelPwd.Controls.Add(this.txtPwd);
            this.panelPwd.Location = new System.Drawing.Point(334, 222);
            this.panelPwd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelPwd.Name = "panelPwd";
            this.panelPwd.Size = new System.Drawing.Size(232, 33);
            this.panelPwd.TabIndex = 28;
            // 
            // btnHide
            // 
            this.btnHide.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHide.BackgroundImage")));
            this.btnHide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHide.Location = new System.Drawing.Point(202, 2);
            this.btnHide.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(28, 30);
            this.btnHide.TabIndex = 34;
            this.btnHide.UseVisualStyleBackColor = true;
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
            // 
            // btnVisible
            // 
            this.btnVisible.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVisible.BackgroundImage")));
            this.btnVisible.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVisible.Location = new System.Drawing.Point(202, 2);
            this.btnVisible.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnVisible.Name = "btnVisible";
            this.btnVisible.Size = new System.Drawing.Size(28, 30);
            this.btnVisible.TabIndex = 33;
            this.btnVisible.UseVisualStyleBackColor = true;
            this.btnVisible.Click += new System.EventHandler(this.btnVisible_Click);
            // 
            // picPwd
            // 
            this.picPwd.BackColor = System.Drawing.Color.White;
            this.picPwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPwd.BackgroundImage")));
            this.picPwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPwd.Location = new System.Drawing.Point(0, 2);
            this.picPwd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picPwd.Name = "picPwd";
            this.picPwd.Size = new System.Drawing.Size(32, 28);
            this.picPwd.TabIndex = 31;
            this.picPwd.TabStop = false;
            // 
            // btnForgot
            // 
            this.btnForgot.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnForgot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnForgot.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnForgot.FlatAppearance.BorderColor = System.Drawing.Color.LightBlue;
            this.btnForgot.FlatAppearance.BorderSize = 0;
            this.btnForgot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForgot.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.btnForgot.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnForgot.Location = new System.Drawing.Point(442, 259);
            this.btnForgot.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnForgot.Name = "btnForgot";
            this.btnForgot.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnForgot.Size = new System.Drawing.Size(129, 25);
            this.btnForgot.TabIndex = 29;
            this.btnForgot.Text = "forgot password?";
            this.btnForgot.UseVisualStyleBackColor = false;
            this.btnForgot.Click += new System.EventHandler(this.btnForgot_Click);
            // 
            // frmLogin
            // 
            this.AcceptButton = this.btnLogin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(640, 395);
            this.Controls.Add(this.btnForgot);
            this.Controls.Add(this.panelPwd);
            this.Controls.Add(this.panelUsername);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.picMascot);
            this.Controls.Add(this.lblPwd);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblWelcome);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmLogin";
            this.Text = "Login Page";
            this.Load += new System.EventHandler(this.frmLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picMascot)).EndInit();
            this.panelUsername.ResumeLayout(false);
            this.panelUsername.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEmail)).EndInit();
            this.panelPwd.ResumeLayout(false);
            this.panelPwd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPwd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private PictureBox picMascot;
        private TextBox txtPwd;
        private Label lblPwd;
        private TextBox txtEmail;
        private Label lblUsername;
        private Label lblWelcome;
        private Label lblTitle;
        private Button btnClear;
        private Button btnLogin;
        private Panel panelUsername;
        private Panel panelPwd;
        private Button btnForgot;
        private PictureBox picEmail;
        private PictureBox picPwd;
        private Button btnHide;
        private Button btnVisible;
    }
}