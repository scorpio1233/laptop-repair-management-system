﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnForgot_Click(object sender, EventArgs e)
        {
            //jump to Account Recovery Page
            frmAccRecovery obj1 = new frmAccRecovery();
            obj1.ShowDialog();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clear all the inputs
            txtEmail.Text = String.Empty;
            txtPwd.Text = String.Empty;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string stat;
            users obj1 = new users(txtEmail.Text, txtPwd.Text);
            stat = obj1.login(txtEmail.Text);
            if (stat != null)
            {
                MessageBox.Show(stat, "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            txtEmail.Text = String.Empty;
            txtPwd.Text = String.Empty;
        }


        private void btnHide_Click(object sender, EventArgs e)
        {
            if (txtPwd.PasswordChar == '*')
            {
                btnVisible.BringToFront();
                txtPwd.PasswordChar = '\0';
            }
        }

        private void btnVisible_Click(object sender, EventArgs e)
        {
            if (txtPwd.PasswordChar == '\0')
            {
                btnHide.BringToFront();
                txtPwd.PasswordChar = '*';
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
