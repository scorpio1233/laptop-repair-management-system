﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Admin
    {
        //member field
        private int adminID;
        private string name;
        private string email;
        private string telNum;
        private string street;
        private string city;
        private string state;
        private int postcode;
        private string picID;
        private string orderID;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string TelNum { get => telNum; set => telNum = value; }
        public string Street { get => street; set => street = value; }
        public string City { get => city; set => city = value; }
        public string State { get => state; set => state = value; }
        public int Postcode { get => postcode; set => postcode = value; }
        public string PicID { get => picID; set => picID = value; }
        public int AdminID { get => adminID; set => adminID = value; }

        //constructor
        public Admin(string eEmail)
        {
            email = eEmail;
        }

        //constructor
        public Admin(string cOrderID, string date)
        {
            orderID = cOrderID;
        }

        //show name in home page
        public string userName()
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("select Name from Admin where Email = '" + Email + "'", con);
            string name = cmd.ExecuteScalar().ToString();

            con.Close();
            return name;
        }

        //view profile
        public static void viewProfile(Admin ad)
        {
            con.Open();
            SqlCommand cmd2 = new SqlCommand("select * from [Admin] where Email = '" + ad.Email + "'", con);
            SqlDataReader SDR = cmd2.ExecuteReader();
            while (SDR.Read())
            {
                ad.AdminID = SDR.GetInt32(0);
                ad.Name = SDR.GetString(1);
                ad.Email = SDR.GetString(2);
                ad.TelNum = SDR.GetString(3);
                ad.Street = SDR.GetString(4);
                ad.City = SDR.GetString(5);
                ad.State = SDR.GetString(6);
                ad.Postcode = SDR.GetInt32(7);
                ad.PicID = SDR.GetString(8);
            }
            con.Close();
        }



        //update Profile
        public string updateProfile(string n_telnum, string n_street, string n_city, string n_state, string n_postcode)
        {
            string status;
            con.Open();

            TelNum = n_telnum;
            Street = n_street;
            City = n_city;
            State = n_state;
            Postcode = Int32.Parse(n_postcode);

            SqlCommand cmd4 = new SqlCommand("update [Admin] set TelNum = '" + TelNum + "', Street = '" + Street + "', City = '" + City + "', State = '" + State + "', postcode = '" + Postcode + "' where Email = '" + Email + "'", con);
            int i = cmd4.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();

            return status;
        }

        public ArrayList showSerInfo()
        {
            ArrayList allService = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select CustomerID, Laptop, Status from [Order] where OrderID = '" + orderID + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                allService.Add(rd.GetInt32(0).ToString());
                allService.Add(rd.GetString(1));
                allService.Add(rd.GetString(2));
            }
            rd.Close();
            SqlCommand cmd2 = new SqlCommand("select Total from [Payment] where OrderID = '" + orderID + "'", con);
            SqlDataReader rd2 = cmd2.ExecuteReader();
            while (rd2.Read())
            {
                allService.Add(rd2.GetSqlDecimal(0));
            }
            rd2.Close();

            con.Close();
            return allService;
        }



    }
}
