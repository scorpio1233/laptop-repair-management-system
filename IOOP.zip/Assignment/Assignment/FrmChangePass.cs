﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmChangePass : Form
    {
        public static string techEmail;
        public FrmChangePass(string email)
        {
            InitializeComponent();
            techEmail = email;
        }

        private void FrmChangePass_Load(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtNewPass.Text == txtConfirmPass.Text)
            {
                credentials obj1 = new credentials(techEmail);
                MessageBox.Show(obj1.updatePass(techEmail,txtNewPass.Text));
                this.Close();
            }
            else
            {
                MessageBox.Show("Please type in the same confirm password as your new password");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
