﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class order
    {
        //member field
        private string orderID;
        private string customerID;
        private string item;
        private string type;
        private string laptop;
        private string customer_email;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        //constructor
        public order(string cusEmail, string cItem, string cType, string cLaptop) 
        {
            customer_email = cusEmail;
            item = cItem;
            type = cType;
            laptop = cLaptop;
        }

        //method
        //add order
        public string addOrder()
        {
            con.Open();

            //find customerID
            SqlCommand cmd = new SqlCommand("select CustomerID from Customer where email = @email", con);
            cmd.Parameters.AddWithValue("@email", customer_email);
            int cusID = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            //generate order id
            string newOrderID = "ORD";
            SqlCommand cmd2 = new SqlCommand("select count(*) from [Order]", con);
            int countOrderID = Convert.ToInt32(cmd2.ExecuteScalar().ToString()) +1;

            if (countOrderID < 10)
                newOrderID += ("000" + countOrderID.ToString());
            else if (countOrderID < 100 && countOrderID >= 10)
                newOrderID += ("00" + countOrderID.ToString());
            else if (countOrderID < 1000 && countOrderID >= 100)
                newOrderID += ("0" + countOrderID.ToString());
            else
                newOrderID += countOrderID.ToString();
            
            //add new order into order table
            SqlCommand cmd3 = new SqlCommand("insert into [Order] values (@orderID, @customerID, @item, @urgency, @laptopModel, 'Unpaid')", con);

            cmd3.Parameters.AddWithValue("@orderID", newOrderID);
            cmd3.Parameters.AddWithValue("@customerID", cusID);
            cmd3.Parameters.AddWithValue("@item", item);
            cmd3.Parameters.AddWithValue("@urgency", type);
            cmd3.Parameters.AddWithValue("@laptopModel", laptop);

            cmd3.ExecuteNonQuery();
            con.Close();
            return ("Order succesfully created. \nThis is your orderID: " + newOrderID);
        }

        //view order method
        public static ArrayList viewOrder()
        {
            ArrayList all_order = new ArrayList();
            string cusIDFull = null;
            con.Open();

            SqlCommand cmd = new SqlCommand("select OrderID, CustomerID, Item, Type from [Order] where Status = 'Unpaid' ", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //generate cusID
                int cusID = rd.GetInt32(1);
                if (cusID < 10)
                    cusIDFull = ("CUS000" + cusID.ToString());
                else if (cusID < 100 && cusID >= 10)
                    cusIDFull = ("CUS00" + cusID.ToString());
                else if (cusID < 1000 && cusID >= 100)
                    cusIDFull = ("CUS0" + cusID.ToString());
                else
                    cusIDFull = ("CUS" + cusID.ToString());

                //add all item into array
                all_order.Add(rd.GetString(0));
                all_order.Add(cusIDFull);
                all_order.Add(rd.GetString(2));
                all_order.Add(rd.GetString(3));
            }
            con.Close();
            return all_order;
        }

 

        //get service through orderid - frmGenReceipt
        public static ArrayList getService(ArrayList allOrderID)
        {
            ArrayList allService = new ArrayList();
            con.Open();
            for (int i = 0; i < allOrderID.Count; i++)
            {
                //add service into allService array
                SqlCommand cmd4 = new SqlCommand("select Item from [Order] where OrderID = '" + allOrderID[i] +"'", con);
                SqlDataReader rd4 = cmd4.ExecuteReader();
                while (rd4.Read())
                {
                    allService.Add(rd4.GetString(0));
                }
                rd4.Close();
            }

            con.Close();
            
            return allService;

        }
    }
}
