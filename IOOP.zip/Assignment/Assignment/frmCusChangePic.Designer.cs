﻿namespace Assignment
{
    partial class frmCusChangePic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCusChangePic));
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.radPic2 = new System.Windows.Forms.RadioButton();
            this.radPic1 = new System.Windows.Forms.RadioButton();
            this.picGirl = new System.Windows.Forms.PictureBox();
            this.picBoy = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picGirl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoy)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(216, 12);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(211, 37);
            this.lblTitle.TabIndex = 53;
            this.lblTitle.Text = "Change Picture";
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnConfirm.Location = new System.Drawing.Point(279, 310);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(90, 27);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click_1);
            // 
            // radPic2
            // 
            this.radPic2.AutoSize = true;
            this.radPic2.Location = new System.Drawing.Point(424, 264);
            this.radPic2.Margin = new System.Windows.Forms.Padding(2);
            this.radPic2.Name = "radPic2";
            this.radPic2.Size = new System.Drawing.Size(87, 24);
            this.radPic2.TabIndex = 51;
            this.radPic2.Text = "Picture 2";
            this.radPic2.UseVisualStyleBackColor = true;
            // 
            // radPic1
            // 
            this.radPic1.AutoSize = true;
            this.radPic1.Checked = true;
            this.radPic1.Location = new System.Drawing.Point(131, 264);
            this.radPic1.Margin = new System.Windows.Forms.Padding(2);
            this.radPic1.Name = "radPic1";
            this.radPic1.Size = new System.Drawing.Size(87, 24);
            this.radPic1.TabIndex = 50;
            this.radPic1.TabStop = true;
            this.radPic1.Text = "Picture 1";
            this.radPic1.UseVisualStyleBackColor = true;
            // 
            // picGirl
            // 
            this.picGirl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picGirl.BackgroundImage")));
            this.picGirl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picGirl.Location = new System.Drawing.Point(372, 83);
            this.picGirl.Margin = new System.Windows.Forms.Padding(2);
            this.picGirl.Name = "picGirl";
            this.picGirl.Size = new System.Drawing.Size(186, 165);
            this.picGirl.TabIndex = 49;
            this.picGirl.TabStop = false;
            // 
            // picBoy
            // 
            this.picBoy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoy.BackgroundImage")));
            this.picBoy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoy.Location = new System.Drawing.Point(80, 83);
            this.picBoy.Margin = new System.Windows.Forms.Padding(2);
            this.picBoy.Name = "picBoy";
            this.picBoy.Size = new System.Drawing.Size(186, 165);
            this.picBoy.TabIndex = 48;
            this.picBoy.TabStop = false;
            // 
            // ChangePic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(638, 348);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.radPic2);
            this.Controls.Add(this.radPic1);
            this.Controls.Add(this.picGirl);
            this.Controls.Add(this.picBoy);
            this.Name = "ChangePic";
            this.Text = "ChangePic";
            this.Load += new System.EventHandler(this.ChangePic_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picGirl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Button btnConfirm;
        private RadioButton radPic2;
        private RadioButton radPic1;
        private PictureBox picGirl;
        private PictureBox picBoy;
    }
}