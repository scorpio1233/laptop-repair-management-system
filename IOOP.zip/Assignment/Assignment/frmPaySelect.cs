﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmPaySelect : Form
    {
        public static string receptionistName;
        public frmPaySelect()
        {
            InitializeComponent();
        }

        public frmPaySelect(string cReceptionistName)
        {
            InitializeComponent();
            receptionistName = cReceptionistName;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void frmPaySelect_Load(object sender, EventArgs e)
        {
            ArrayList cusName = new ArrayList();
            ArrayList allOrder = new ArrayList();
            int count = 0;            

            allOrder = order.viewOrder(); // OrderID, CustomerID, Item, Type
            cusName = customer.getCusName();
            for (int i = 0; i < allOrder.Count; i = i + 4)
            {
                ListViewItem item = new ListViewItem(allOrder[i].ToString()); 
                item.SubItems.Add(allOrder[i+1].ToString());
                item.SubItems.Add(cusName[count].ToString());
                item.SubItems.Add(allOrder[i + 2].ToString());
                item.SubItems.Add(allOrder[i + 3].ToString());

                lvOrder.Items.Add(item);
                count++;
            }
            lvOrder.Items[0].Remove();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (lvOrder.SelectedItems.Count > 0)
            {
                //receptionist name, orderid, customer name, service, urgency
                this.Hide();
                frmCheckout co = new frmCheckout(receptionistName, lvOrder.SelectedItems[0].Text, lvOrder.SelectedItems[0].SubItems[2].Text, lvOrder.SelectedItems[0].SubItems[3].Text, lvOrder.SelectedItems[0].SubItems[4].Text);
                co.ShowDialog();
                this.Close();
            }
            else
                MessageBox.Show("Please select an order first.");
        }

    }
}
