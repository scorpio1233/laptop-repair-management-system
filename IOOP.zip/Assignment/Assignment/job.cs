﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class job
    {
        private string techemail;
        private string techid;
        private string orderid;

        static SqlConnection Con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        public job(string email, string id)
        {
            techemail = email;
            techid = id;
        }

        public job(string email, string id, string ord)
        {
            techemail = email;
            techid = id;
            orderid = ord;
        }

        public job(string ordid)
        {
            orderid = ordid;
        }
        public static ArrayList getordid(string id)
        {
            string techid = id;
            ArrayList ordid = new ArrayList();
            Con.Open();
            SqlCommand cmd = new SqlCommand("select OrderID from Service where TechId = @id and Completion = 'pending'" , Con);
            cmd.Parameters.AddWithValue("@id", techid);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //get data of column 0
                ordid.Add(rd.GetString(0));
            }

            Con.Close();
            return ordid;
        }

        public string getcusid(string id)
        {
            string orderid = id;
            Con.Open();
            SqlCommand cmd2 = new SqlCommand("select CustomerID from [Order] where OrderID='" + orderid + "'", Con);
            string cusid = cmd2.ExecuteScalar().ToString();
            
            Con.Close();
            return cusid;
        }

        public string getcusnm(int id)
        {
            int cusid = id;
            Con.Open();
            SqlCommand cmd3 = new SqlCommand("select Name from [Customer] where CustomerID='" + cusid + "'", Con);
            string cusnm = cmd3.ExecuteScalar().ToString();

            Con.Close();
            return cusnm;
        }

        public string getservice(string id)
        {
            string orderid = id;
            Con.Open();
            SqlCommand cmd2 = new SqlCommand("select item from [Order] where OrderID='" + orderid + "'", Con);
            string service = cmd2.ExecuteScalar().ToString();

            Con.Close();
            return service;
        }

        public string getlaptop(string id)
        {
            string orderid = id;
            Con.Open();
            SqlCommand cmd2 = new SqlCommand("select Laptop from [Order] where OrderID='" + orderid + "'", Con);
            string laptop = cmd2.ExecuteScalar().ToString();

            Con.Close();
            return laptop;
        }

        public string getstatus(string id)
        {
            string orderid = id;
            Con.Open();
            SqlCommand cmd2 = new SqlCommand("select Type from [Order] where OrderID='" + orderid + "'", Con);
            string status = cmd2.ExecuteScalar().ToString();

            Con.Close();
            return status;
        }


        public static ArrayList getdiff()
        {
            ArrayList diff = new ArrayList();
            Con.Open();
            SqlCommand cmd = new SqlCommand("select OrderID from [Order] where OrderID not in(select OrderID from [Service])", Con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //get data of column 0
                diff.Add(rd.GetString(0));
            }

            Con.Close();
            return diff;
        }

        public string getdesc(string ordid)
        {
            Con.Open();

            SqlCommand cmd2 = new SqlCommand("select Description from [Service] where OrderID='" + ordid + "'", Con);
            string description = cmd2.ExecuteScalar().ToString();

            Con.Close();
            return description;
        }

        public string getdate(string ordid)
        {
            Con.Open();

            SqlCommand cmd2 = new SqlCommand("select Date from [Service] where OrderID='" + ordid + "'", Con);
            string date = cmd2.ExecuteScalar().ToString();

            Con.Close();
            return date;
        }

        public string updatedesc(string desc, string ordid)
        {
            string status;
            Con.Open();

            SqlCommand cmd = new SqlCommand("update [Service] set Description ='" + desc + "'where OrderID ='" + ordid + "'", Con);

            int i = cmd.ExecuteNonQuery();
            if (i == 0)
                status = "Update failed :(";
            else
                status = "Update successful :)";
            Con.Close();

            return status;
        }

        public string updjob(string ordid)
        {
            string status;
            Con.Open();

            SqlCommand cmd = new SqlCommand("update [Service] set Completion ='complete' where OrderID ='" + ordid + "'", Con);
            SqlCommand cmd2 = new SqlCommand("update [Service] set Date = GETDATE() where OrderID ='" + ordid + "'", Con);

            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i == 0)
                status = "Update failed :(";
            else
                status = "Job completed, we will notify the customer :)";
            Con.Close();

            return status;
        }

        public string takejob(string tech, string ord)
        {
            string status;
            Con.Open();

            SqlCommand cmd = new SqlCommand("INSERT INTO [Service] VALUES(@orderid, @techid, '','pending','')", Con);
            cmd.Parameters.AddWithValue("@orderid", ord);
            cmd.Parameters.AddWithValue("@techid", tech);

            int i = cmd.ExecuteNonQuery();
            if (i == 0)
                status = "Update failed :(";
            else
                status = "Update successful :)";
            Con.Close();

            return status;
        }

       
    }
}
