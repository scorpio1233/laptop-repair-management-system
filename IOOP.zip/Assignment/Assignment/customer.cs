﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class customer
    {
        //member field
        private string customerID;
        private string name;
        private string email;
        private string telNum;
        private string street;
        private string city;
        private string state;
        private string postcode;
        private string picID;
        private string status;
        private string item;
        private string type;
        private string paidAmt;


        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        //get set method
        public string CustomerID { get => customerID; set => customerID = value; }
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string TelNum { get => telNum; set => telNum = value; }
        public string Street { get => street; set => street = value; }
        public string City { get => city; set => city = value; }
        public string State { get => state; set => state = value; }
        public string Postcode { get => postcode; set => postcode = value; }
        public string PicID { get => picID; set => picID = value; }

        //Constructor
        public customer(string cName, string cEmail, string cTelNum, string cStreet, string cCity, string cState, string cPostcode)
        {
            name = cName;
            email = cEmail;
            telNum = cTelNum;
            street = cStreet;
            city = cCity;
            state = cState;
            postcode = cPostcode;
        }

        //Constructor 
        public customer(string cEmail)
        {
            email = cEmail;
        }

        public customer(string i, string t, string e)
        {
            item = i;
            type = t;
            email = e;
        }

        //addCustomer method
        public string addCustomer()
        {
            string status = null;
            con.Open();

            //check is there repeated email
            SqlCommand cmd = new SqlCommand("select count(*) from Login where email = @email", con);
            cmd.Parameters.AddWithValue("@email", email);
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0) //Email already existed
                status = "Unable to register. Email already existed.";
            else
            {
                //Generate default password = "CUS" + contact number last 3-digit numbers + Name first 2 characters 
                string default_pwd = "CUS";
                for (int cnt = telNum.Length - 1; cnt >= telNum.Length - 3; cnt--)
                    default_pwd += telNum[cnt]; //add Tel number last 3-digit numbers
                for (int cnt2 = 0; cnt2 <= 1; cnt2++)
                    default_pwd += name[cnt2].ToString().ToLower();  //add name first 2 characters
                //Insert data into table Login and Customer
                SqlCommand cmd2 = new SqlCommand("insert into Login(email, Pass, Role) values (@email, @default_pwd, 'Customer')", con);
                SqlCommand cmd3 = new SqlCommand("insert into Customer values (@name, @email, @telNum, @street, @city, @state, @postcode, 'Progressing', 'PIC01')", con);
                //Login table
                cmd2.Parameters.AddWithValue("@email", email);
                cmd2.Parameters.AddWithValue("@default_pwd", default_pwd);
                //Customer table
                cmd3.Parameters.AddWithValue("@name", name);
                cmd3.Parameters.AddWithValue("@email", email);
                cmd3.Parameters.AddWithValue("@telNum", telNum);
                cmd3.Parameters.AddWithValue("@street", street);
                cmd3.Parameters.AddWithValue("@city", city);
                cmd3.Parameters.AddWithValue("@state", state);
                cmd3.Parameters.AddWithValue("@postcode", Int32.Parse(postcode));
                
                //check insert succesfully or not
                int j = cmd2.ExecuteNonQuery();
                int i = cmd3.ExecuteNonQuery();
                if (i != 0 && j != 0)
                    status = "Registration Successful. \nThis is your default password: "+ default_pwd;
                else
                    status = "Unable to register.";
            }
            con.Close();
            return status;
        }

        //view all customers who have completed their previous order        
        public static ArrayList viewCompletedCus()
        {
            ArrayList allCompletedCus = new ArrayList();
            con.Open();

            SqlCommand cmd4 = new SqlCommand("select CustomerID, Name, Email, TelNum from [Customer] where Status = 'Complete' ", con);
            SqlDataReader rd4 = cmd4.ExecuteReader();
            while (rd4.Read())
            {
                int customer_ID = rd4.GetInt32(0);
                string cusID_for_register = "CUS";
                if (customer_ID < 10)
                    cusID_for_register = ("CUS000" + customer_ID.ToString());
                else if (customer_ID < 100 && customer_ID >= 10)
                    cusID_for_register = ("CUS00" + customer_ID.ToString());
                else if (customer_ID < 1000 && customer_ID >= 100)
                    cusID_for_register = ("CUS0" + customer_ID.ToString());
                else
                    cusID_for_register = ("CUS" + customer_ID.ToString());

                allCompletedCus.Add(cusID_for_register);
                allCompletedCus.Add(rd4.GetString(1));
                allCompletedCus.Add(rd4.GetString(2));
                allCompletedCus.Add(rd4.GetString(3));
            }

            con.Close();
            return allCompletedCus;
        }

        public void updateCustomerStatus()
        {
            con.Open();
            SqlCommand cmd5 = new SqlCommand("update [Customer] set Status = 'Progressing' where Email = '" + email + "'", con);
            cmd5.ExecuteNonQuery();
            con.Close();
        }

        //get customer name method
        public static ArrayList getCusName()
        {
            ArrayList cus_name = new ArrayList();
            ArrayList cus_id = new ArrayList();

            con.Open();

            //add customer id into cus_id array
            SqlCommand cmd2 = new SqlCommand("select CustomerID from [Order] where Status = 'Unpaid'", con);
            SqlDataReader rd2 = cmd2.ExecuteReader();
            while (rd2.Read())
            {
                cus_id.Add(rd2.GetInt32(0));
            }
            rd2.Close();

            //add customer name into cus_name
            for (int i = 0; i < cus_id.Count; i++)
            {
                SqlCommand cmd3 = new SqlCommand("select Name from [Customer] where customerID = '" + cus_id[i] + "'", con);
                cus_name.Add(cmd3.ExecuteScalar().ToString());
            }

            con.Close();
            return cus_name;
        }

        //show name in home page

        public string showName()
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("select Name from Customer where Email = '" + email + "'", con);
            string name = cmd.ExecuteScalar().ToString();

            con.Close();
            return name;
        }

        //show id in home page

        public string showID()
        {
            con.Open();

            SqlCommand cmd2 = new SqlCommand("select CustomerId from Customer where Email = '" + email + "'", con);
            string Id = cmd2.ExecuteScalar().ToString();

            con.Close();
            return Id;
        }

        //view profile
        public static void viewProfile(customer o1)
        {
            con.Open();
            SqlCommand cmd3 = new SqlCommand("select * from [Customer] where Email = '" + o1.email + "'", con);
            SqlDataReader rd2 = cmd3.ExecuteReader();
            while (rd2.Read())
            {
                o1.customerID = rd2.GetInt32(0).ToString();
                o1.name = rd2.GetString(1);
                o1.email = rd2.GetString(2);
                o1.telNum = rd2.GetString(3);
                o1.street = rd2.GetString(4);
                o1.city = rd2.GetString(5);
                o1.state = rd2.GetString(6);
                o1.postcode = rd2.GetInt32(7).ToString();
                o1.picID = rd2.GetString(9);
                o1.status = rd2.GetString(8);
            }
            con.Close();
        }

        //update Profile
        public string updateProfile(string new_telnum, string new_street, string new_city, string new_state, string new_postcode)
        {
            string status;
            con.Open();

            telNum = new_telnum;
            street = new_street;
            city = new_city;
            state = new_state;
            postcode = Int32.Parse(new_postcode).ToString();

            SqlCommand cmd4 = new SqlCommand("update [Customer] set TelNum = '" + telNum + "', Street = '" + street + "', City = '" + city + "', State = '" + state + "', postcode = '" + postcode + "' where Email = '" + email + "'", con);
            int i = cmd4.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();

            return status;
        }

        //change picture
        public string changePic(string pic)
        {
            string status = null;
            con.Open();
            picID = pic;
            SqlCommand cmd3 = new SqlCommand("update [Customer] set PicID = '" + picID + "' where Email = '" + email + "'", con);
            int i = cmd3.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();
            return status;
        }
        
        //Change Requested Service
        public string chgrequestservice()
        {
            string status = null;
            string stat = null;
            con.Open();;
            if (type == "0") 
            {

                type = "Urgent";
            }
            else if (type == "1")
            {
                type = "Normal";
            }
            // find customer ID
            SqlCommand cmd = new SqlCommand("select CustomerID from [Customer] where Email = '" + email + "'", con);
            string customerID = cmd.ExecuteScalar().ToString();
            //find Order ID
            SqlCommand cmd2 = new SqlCommand("select [ORDER].orderID from [order] where orderID = (select top 1 orderID from [order] where CustomerID =  '" + customerID + "' order by OrderID DESC)", con);
            string orderID = cmd2.ExecuteScalar().ToString();

            //Check is there order in service table
            SqlCommand cmd6 = new SqlCommand("select count(*) from Service where orderID = '" + orderID + "'", con);


            int count = Convert.ToInt32(cmd6.ExecuteScalar().ToString());
            if (count > 0)
            {
                //Check Status
                SqlCommand cmd4 = new SqlCommand("select Completion from [Service] where orderID = '" + orderID + "'", con);
                stat = cmd4.ExecuteScalar().ToString();
            }


            if (stat == "complete")
            {
                status = "Unable to update, service has been completed";
            }
            else
            {
                SqlCommand cmd3 = new SqlCommand("update [Order] set Item = '" + item + "', Type = '" + type + "' where orderID = '" + orderID + "'", con);
                int i = cmd3.ExecuteNonQuery();
                if (i != 0)
                    status = "Update Successfully.";
                else
                    status = "Unable to update.";
            }
                
            con.Close();

            return status;
        }
        

        //Existing Service
        public static ArrayList getService(string email)
        {
            con.Open();
            ArrayList arrayService = new ArrayList();
            //date, status, description , orderiD, service, Urgency
            // find customer ID
            SqlCommand cmd = new SqlCommand("select CustomerID from [Customer] where Email = '" + email + "'", con);
            string customerID = cmd.ExecuteScalar().ToString();

            // find order ID
            SqlCommand cmd2 = new SqlCommand("select [ORDER].orderID from [order] where orderID = (select top 1 orderID from [order] where CustomerID =  '" + customerID + "' order by OrderID DESC)", con);
            string orderID = cmd2.ExecuteScalar().ToString();
            //Add servie into array
            SqlCommand cmd4 = new SqlCommand("select item, type from [Order] where orderID = '" + orderID + "'", con);
            SqlDataReader rd4 = cmd4.ExecuteReader();
            while (rd4.Read())
            {
                arrayService.Add(rd4.GetString(0));
                arrayService.Add(rd4.GetString(1));
            }

            rd4.Close();
            //Check the order finish or not
            SqlCommand cmd5 = new SqlCommand("select count(*) from Service where OrderID = '" + orderID + "'", con);

            int count = Convert.ToInt32(cmd5.ExecuteScalar().ToString());

            if (count > 0)
            { //Put all data into array
                SqlCommand cmd3 = new SqlCommand("select Date, Completion,Description, orderid from [Service] where OrderID = '" + orderID + "'", con);
                SqlDataReader rd3 = cmd3.ExecuteReader();
                while (rd3.Read())
                {
                    arrayService.Add(rd3.GetDateTime(0).ToString("dd/MM/yyyy"));
                    arrayService.Add(rd3.GetString(1));
                    arrayService.Add(rd3.GetString(2));
                    arrayService.Add(rd3.GetString(3));
                }
                rd3.Close();
            }

            con.Close();
            return arrayService;
        }

    }
}
