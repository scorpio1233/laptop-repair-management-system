﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmSetSecure : Form
    {
        public static string techEmail;
        public FrmSetSecure(string email)
        {
            InitializeComponent();
            techEmail = email;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (txtAns.Text is null || txtAns.Text =="" || cmbQuestion.SelectedItem==null )
            {
                MessageBox.Show("Please complete the form first :)");
            }
            else
            {
                int ques = cmbQuestion.SelectedIndex + 1;
                string quesid = "QUS00"+ques.ToString();
                string ans = txtAns.Text;
                credentials obj1 = new credentials(techEmail);
                MessageBox.Show(obj1.setQues(techEmail, quesid, ans));
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmSetSecure_Load(object sender, EventArgs e)
        {

        }
    }
}
