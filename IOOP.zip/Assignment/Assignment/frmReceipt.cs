﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmReceipt : Form
    {
        public static string orderID;
        public frmReceipt()
        {
            InitializeComponent();
        }

        public frmReceipt(string cOrderID)
        {
            InitializeComponent();
            orderID = cOrderID;
        }

        private void Receipt_Load(object sender, EventArgs e)
        {
            ArrayList detail = new ArrayList();
            //cusName, cusAddress, cusTel, service, urgency, receiptNo, paydatetime, receptionistname, subtotal, total, paidAmt
            detail = payment.genReceipt(orderID); 
            lblCusName.Text = detail[0].ToString();
            lblAdress.Text = detail[1].ToString();
            lblCusTel.Text = detail[2].ToString();
            lblService.Text = detail[3].ToString();
            lblUrgency.Text = "( " + detail[4].ToString() + " )";
            lblReceiptNo.Text = detail[5].ToString();
            lblDatetime.Text = detail[6].ToString();
            lblReceptionistName.Text = detail[7].ToString();
            lblSubTotal.Text = "RM  " + detail[8].ToString();
            lblttl.Text = detail[8].ToString();
            lblTotal.Text = "RM  " + detail[9].ToString();
            lblPaidAmt.Text = "RM  " + detail[10].ToString();

            if (lblSubTotal.Text == lblTotal.Text)
                lblDiscountAmt.Text = "-";
            else
            {
                double discountAmount = double.Parse(detail[8].ToString()) - double.Parse(detail[9].ToString());
                discountAmount = Math.Round(discountAmount, 2);
                lblDiscountAmt.Text = "- RM  " + discountAmount.ToString();
                lblDiscountAmt.Text += addDecimal(discountAmount.ToString());
            }
            if (lblPaidAmt.Text == lblTotal.Text)
                lblChange.Text = "-";
            else
            {
                double changeAmount = double.Parse(detail[10].ToString()) - double.Parse(detail[9].ToString());
                changeAmount = Math.Round(changeAmount, 2);
                lblChange.Text = "RM  " + changeAmount.ToString();
                lblChange.Text += addDecimal(changeAmount.ToString());
            }            
        }

        //add decimal places to the integer
        public string addDecimal(string amount)
        {
            string result = null;
            if (int.TryParse(amount.ToString(), out int amt))
                result = ".00";
            else
            {
                string[] arrayAmount = amount.ToString().Split('.');
                if (arrayAmount[1].Length == 1)
                    result = "0";
            }

            return result;
        }

    }
}
