﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmReceptionistHome : Form
    {
        public static string email;
        public static string name;
        public frmReceptionistHome()
        {
            InitializeComponent();
        }

        public frmReceptionistHome(string em)
        {
            InitializeComponent();
            email = em;            
        }

        private void frmReceptionistHome_Load(object sender, EventArgs e)
        {
            timerDatetime.Start();
            receptionist sn = new receptionist(email);
            name = sn.showName();
            lblName.Text = "Name: " + name;
        }

        private void timerDatetime_Tick(object sender, EventArgs e)
        {
            lblDatetime.Text = DateTime.Now.ToString();
        }


        private void btnRegCus_Click(object sender, EventArgs e)
        {
            frmRegSelect obj1 = new frmRegSelect();
            obj1.ShowDialog();
        }

        private void picRegCus_Click(object sender, EventArgs e)
        {
            frmRegSelect obj1 = new frmRegSelect();
            obj1.ShowDialog();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            frmPaySelect obj1 = new frmPaySelect(name);
            obj1.ShowDialog();
        }

        private void picPayment_Click(object sender, EventArgs e)
        {
            frmPaySelect obj1 = new frmPaySelect(name);
            obj1.ShowDialog();
        }

        private void btnReceipt_Click(object sender, EventArgs e)
        {
            frmGenReceipt obj1 = new frmGenReceipt();
            obj1.ShowDialog();
        }

        private void picReceipt_Click(object sender, EventArgs e)
        {
            frmGenReceipt obj1 = new frmGenReceipt();
            obj1.ShowDialog();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            frmRecepProfile obj1 = new frmRecepProfile(email);
            obj1.ShowDialog();
        }

        private void picProfile_Click(object sender, EventArgs e)
        {
            frmRecepProfile obj1 = new frmRecepProfile(email);
            obj1.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
