﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmPending : Form
    {
        public static string techEmail;
        public static string techid;
        public FrmPending(string email, string id)
        {
            InitializeComponent();
            techEmail = email;
            techid = id;
        }

        private void lvPending_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmPending_Load(object sender, EventArgs e)
        {
            //get all pending job's order id and store into a array list
            ArrayList ordid = new ArrayList();
            ordid = job.getordid(techid);

            //find all data related to the order id and store in array list
            ArrayList cusid = new ArrayList();
            ArrayList cusname = new ArrayList();
            ArrayList service = new ArrayList();
            ArrayList laptop = new ArrayList();
            ArrayList status = new ArrayList();
            for (int cnt = 0; cnt < ordid.Count; cnt += 1)
            {
                string idnow = ordid[cnt].ToString();
                job obj1 = new job(techEmail, techid);
                string cusidsh = obj1.getcusid(idnow).ToString();
                int lgid = cusidsh.Length;
                if (lgid<10)
                {
                    cusid.Add("CUS00" + cusidsh);
                }
                else if (lgid<100)
                {
                    cusid.Add("CUS0" + cusidsh);
                }
                else if (lgid < 1000)
                {
                    cusid.Add("CUS" + cusidsh);
                }
                int shcusid = Int32.Parse(cusidsh);
                cusname.Add(obj1.getcusnm(shcusid).ToString());
                service.Add(obj1.getservice(idnow).ToString());
                laptop.Add(obj1.getlaptop(idnow).ToString());
                status.Add(obj1.getstatus(idnow).ToString());
            }

            //add data into listview
            for (int cnt=0; cnt < ordid.Count; cnt+=1)
            {
                ListViewItem item = new ListViewItem(ordid[cnt].ToString());
                lvPending.Items.Add(item);
                item.SubItems.Add(cusid[cnt].ToString());
                item.SubItems.Add(cusname[cnt].ToString());
                item.SubItems.Add(service[cnt].ToString());
                item.SubItems.Add(laptop[cnt].ToString());
                item.SubItems.Add(status[cnt].ToString());
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (lvPending.SelectedItems.Count > 0)
            {
                FrmServicing co = new FrmServicing(lvPending.SelectedItems[0].Text, lvPending.SelectedItems[0].SubItems[1].Text, lvPending.SelectedItems[0].SubItems[2].Text, lvPending.SelectedItems[0].SubItems[3].Text, lvPending.SelectedItems[0].SubItems[4].Text, lvPending.SelectedItems[0].SubItems[5].Text);
                co.ShowDialog();
                this.Close();
            }
            else
                MessageBox.Show("Please select a pending job first :)");
        }

        private void btnBPending_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddPending_Click(object sender, EventArgs e)
        {
            if (lvPending.Items.Count <= 2)
            {
                string filter = "";
                MessageBox.Show("You still have "+lvPending.Items.Count.ToString()+ " pending jobs. Are you sure to add more?");
                FrmViewJob form = new FrmViewJob(techEmail, techid, filter);
                form.Show();
                this.Close();
            }
            else 
            {
                MessageBox.Show("Please finish the pending job first, maximum is 3 pending job :)");

            }
        }
    }
}
