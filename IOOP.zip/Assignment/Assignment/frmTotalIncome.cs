﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmTotalIncome : Form
    {
        public frmTotalIncome()
        {
            InitializeComponent();
        }

        private void lblModel_Click(object sender, EventArgs e)
        {
            
        }

        private void lblPrice_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (cmbMonth.SelectedItem != null && cmbYear.SelectedItem != null)
            {
                frmIncomeDetail obj1 = new frmIncomeDetail(cmbMonth.SelectedItem.ToString(), cmbYear.SelectedItem.ToString());
                obj1.ShowDialog();
            }
            else
                MessageBox.Show("Please select month and year");
        }

        private void frmTotalIncome_Load(object sender, EventArgs e)
        {

        }

        private void btnFetch_Click(object sender, EventArgs e)
        {
            if (cmbMonth.SelectedItem != null && cmbYear.SelectedItem != null)
            {
                Income inc = new Income();
                string total = inc.showIncome(cmbMonth.SelectedItem.ToString(), cmbYear.SelectedItem.ToString());
                lblTotalEarn.Text = "RM" + total;
                lblWhen.Text = cmbMonth.SelectedItem.ToString();
            }
            else
                MessageBox.Show("Please select your date and year");

        }
    }
}
