﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmAdmPro : Form
    {
        public static string email;
        public frmAdmPro(string em)
        {
            InitializeComponent();
            email = em;
        }

        private void grpProfile_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (checkEmpty() == false)
            {
                if (Int32.TryParse(txtPostCode.Text, out int postcodeNum) && txtPostCode.Text.Length == 5)
                {
                    Admin obj1 = new Admin(email);
                    MessageBox.Show(obj1.updateProfile(txtNumber.Text, txtRegion.Text, txtCity.Text, txtAddress.Text, txtPostCode.Text));
                }
                else
                    MessageBox.Show("Postcode must be 5-digit number");
            }
            else
                MessageBox.Show("All text box cannot be empty.");

        }

        public bool checkEmpty()
        {
            bool empty = false;
            if (txtNumber.Text == string.Empty || txtAddress.Text == string.Empty || txtRegion.Text == string.Empty || txtCity.Text == string.Empty || txtPostCode.Text == string.Empty)
                empty = true;
            return empty;
        }

        public void displayProfile()
        {
            Admin obj1 = new Admin(email);
            Admin.viewProfile(obj1);
            string adminID1 = "ID: ADM";
            if (obj1.AdminID < 10)
                adminID1 += ("000" + obj1.AdminID.ToString());
            else if (obj1.AdminID < 100 && obj1.AdminID >= 10)
                adminID1 += ("00" + obj1.AdminID.ToString());
            else if (obj1.AdminID < 1000 && obj1.AdminID >= 100)
                adminID1 += ("0" + obj1.AdminID.ToString());
            else
                adminID1 += obj1.AdminID.ToString();

            lblProName.Text = obj1.Name;
            lblID.Text = adminID1;
        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmAdmPro_Load(object sender, EventArgs e)
        {
            displayProfile();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
