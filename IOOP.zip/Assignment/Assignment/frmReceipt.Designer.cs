﻿namespace Assignment
{
    partial class frmReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCompanyAddress = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.lblReceiptTitle = new System.Windows.Forms.Label();
            this.panelCusDetail = new System.Windows.Forms.Panel();
            this.lblCusTel = new System.Windows.Forms.Label();
            this.lblAdress = new System.Windows.Forms.Label();
            this.lblCusName = new System.Windows.Forms.Label();
            this.lblSoldTo = new System.Windows.Forms.Label();
            this.listTitle = new System.Windows.Forms.ListBox();
            this.panelDetail = new System.Windows.Forms.Panel();
            this.lblttl = new System.Windows.Forms.Label();
            this.lblUrgency = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblNo = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblDiscountAmt = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.listSummary = new System.Windows.Forms.ListBox();
            this.lblPaidAmt = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblThankyou = new System.Windows.Forms.Label();
            this.lblRepNo = new System.Windows.Forms.Label();
            this.lblRecep = new System.Windows.Forms.Label();
            this.lblDt = new System.Windows.Forms.Label();
            this.lblReceptionistName = new System.Windows.Forms.Label();
            this.lblDatetime = new System.Windows.Forms.Label();
            this.lblReceiptNo = new System.Windows.Forms.Label();
            this.panelCusDetail.SuspendLayout();
            this.panelDetail.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCompanyAddress
            // 
            this.lblCompanyAddress.AutoSize = true;
            this.lblCompanyAddress.Location = new System.Drawing.Point(35, 75);
            this.lblCompanyAddress.Name = "lblCompanyAddress";
            this.lblCompanyAddress.Size = new System.Drawing.Size(353, 75);
            this.lblCompanyAddress.TabIndex = 1;
            this.lblCompanyAddress.Text = "69-1, Jalan APU, Taman Teknologi Malaysia,\r\n57000 Kuala Lumpur.\r\nTEL: 012-3456789" +
    "";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCompanyName.Location = new System.Drawing.Point(30, 36);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(366, 25);
            this.lblCompanyName.TabIndex = 2;
            this.lblCompanyName.Text = "FIX-IT-FELIX LAPTOP SERVICES SDN BHD ";
            // 
            // lblReceiptTitle
            // 
            this.lblReceiptTitle.AutoSize = true;
            this.lblReceiptTitle.Font = new System.Drawing.Font("Segoe UI Black", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblReceiptTitle.Location = new System.Drawing.Point(524, 136);
            this.lblReceiptTitle.Name = "lblReceiptTitle";
            this.lblReceiptTitle.Size = new System.Drawing.Size(121, 38);
            this.lblReceiptTitle.TabIndex = 3;
            this.lblReceiptTitle.Text = "Receipt";
            // 
            // panelCusDetail
            // 
            this.panelCusDetail.Controls.Add(this.lblCusTel);
            this.panelCusDetail.Controls.Add(this.lblAdress);
            this.panelCusDetail.Controls.Add(this.lblCusName);
            this.panelCusDetail.Controls.Add(this.lblSoldTo);
            this.panelCusDetail.Location = new System.Drawing.Point(30, 153);
            this.panelCusDetail.Name = "panelCusDetail";
            this.panelCusDetail.Size = new System.Drawing.Size(446, 158);
            this.panelCusDetail.TabIndex = 8;
            // 
            // lblCusTel
            // 
            this.lblCusTel.AutoSize = true;
            this.lblCusTel.Location = new System.Drawing.Point(6, 113);
            this.lblCusTel.Name = "lblCusTel";
            this.lblCusTel.Size = new System.Drawing.Size(47, 25);
            this.lblCusTel.TabIndex = 2;
            this.lblCusTel.Text = "TEL: ";
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Location = new System.Drawing.Point(6, 63);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(74, 25);
            this.lblAdress.TabIndex = 1;
            this.lblAdress.Text = "address";
            // 
            // lblCusName
            // 
            this.lblCusName.AutoSize = true;
            this.lblCusName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusName.Location = new System.Drawing.Point(6, 38);
            this.lblCusName.Name = "lblCusName";
            this.lblCusName.Size = new System.Drawing.Size(62, 25);
            this.lblCusName.TabIndex = 1;
            this.lblCusName.Text = "Name";
            // 
            // lblSoldTo
            // 
            this.lblSoldTo.AutoSize = true;
            this.lblSoldTo.Location = new System.Drawing.Point(6, 13);
            this.lblSoldTo.Name = "lblSoldTo";
            this.lblSoldTo.Size = new System.Drawing.Size(74, 25);
            this.lblSoldTo.TabIndex = 0;
            this.lblSoldTo.Text = "Sold to:\r\n";
            // 
            // listTitle
            // 
            this.listTitle.BackColor = System.Drawing.Color.White;
            this.listTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.listTitle.FormattingEnabled = true;
            this.listTitle.ItemHeight = 25;
            this.listTitle.Items.AddRange(new object[] {
            " No    Description            \t   \t                      \t\t Sub Total (RM)"});
            this.listTitle.Location = new System.Drawing.Point(-1, -1);
            this.listTitle.Name = "listTitle";
            this.listTitle.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listTitle.Size = new System.Drawing.Size(796, 27);
            this.listTitle.TabIndex = 11;
            // 
            // panelDetail
            // 
            this.panelDetail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelDetail.Controls.Add(this.lblttl);
            this.panelDetail.Controls.Add(this.lblUrgency);
            this.panelDetail.Controls.Add(this.lblService);
            this.panelDetail.Controls.Add(this.lblNo);
            this.panelDetail.Controls.Add(this.listTitle);
            this.panelDetail.Location = new System.Drawing.Point(44, 338);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new System.Drawing.Size(796, 322);
            this.panelDetail.TabIndex = 13;
            // 
            // lblttl
            // 
            this.lblttl.AutoSize = true;
            this.lblttl.Location = new System.Drawing.Point(656, 29);
            this.lblttl.Name = "lblttl";
            this.lblttl.Size = new System.Drawing.Size(19, 25);
            this.lblttl.TabIndex = 18;
            this.lblttl.Text = "-";
            // 
            // lblUrgency
            // 
            this.lblUrgency.AutoSize = true;
            this.lblUrgency.Location = new System.Drawing.Point(46, 54);
            this.lblUrgency.Name = "lblUrgency";
            this.lblUrgency.Size = new System.Drawing.Size(19, 25);
            this.lblUrgency.TabIndex = 15;
            this.lblUrgency.Text = "-";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(46, 29);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(19, 25);
            this.lblService.TabIndex = 14;
            this.lblService.Text = "-";
            // 
            // lblNo
            // 
            this.lblNo.AutoSize = true;
            this.lblNo.Location = new System.Drawing.Point(6, 29);
            this.lblNo.Name = "lblNo";
            this.lblNo.Size = new System.Drawing.Size(22, 25);
            this.lblNo.TabIndex = 13;
            this.lblNo.Text = "1";
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.Location = new System.Drawing.Point(738, 663);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(78, 25);
            this.lblSubTotal.TabIndex = 18;
            this.lblSubTotal.Text = "RM 0.00";
            // 
            // lblDiscountAmt
            // 
            this.lblDiscountAmt.AutoSize = true;
            this.lblDiscountAmt.Location = new System.Drawing.Point(738, 689);
            this.lblDiscountAmt.Name = "lblDiscountAmt";
            this.lblDiscountAmt.Size = new System.Drawing.Size(19, 25);
            this.lblDiscountAmt.TabIndex = 19;
            this.lblDiscountAmt.Text = "-";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTotal.Location = new System.Drawing.Point(738, 715);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(81, 25);
            this.lblTotal.TabIndex = 20;
            this.lblTotal.Text = "RM 0.00";
            // 
            // listSummary
            // 
            this.listSummary.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listSummary.FormattingEnabled = true;
            this.listSummary.ItemHeight = 25;
            this.listSummary.Items.AddRange(new object[] {
            "      Sub Total             ",
            "       Discount          \t     ",
            "             Total                ",
            "Paid Amount    ",
            "         Change\t       "});
            this.listSummary.Location = new System.Drawing.Point(608, 663);
            this.listSummary.Name = "listSummary";
            this.listSummary.Size = new System.Drawing.Size(124, 125);
            this.listSummary.TabIndex = 21;
            // 
            // lblPaidAmt
            // 
            this.lblPaidAmt.AutoSize = true;
            this.lblPaidAmt.Location = new System.Drawing.Point(738, 741);
            this.lblPaidAmt.Name = "lblPaidAmt";
            this.lblPaidAmt.Size = new System.Drawing.Size(83, 25);
            this.lblPaidAmt.TabIndex = 22;
            this.lblPaidAmt.Text = "RM  0.00";
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(738, 767);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(93, 25);
            this.lblChange.TabIndex = 23;
            this.lblChange.Text = "RM    0.00";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(51, 660);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(224, 25);
            this.lblDescription.TabIndex = 24;
            this.lblDescription.Text = "*This is your official receipt";
            // 
            // lblThankyou
            // 
            this.lblThankyou.AutoSize = true;
            this.lblThankyou.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblThankyou.Location = new System.Drawing.Point(261, 830);
            this.lblThankyou.Name = "lblThankyou";
            this.lblThankyou.Size = new System.Drawing.Size(363, 25);
            this.lblThankyou.TabIndex = 25;
            this.lblThankyou.Text = "*THANK YOU, PLEASE VISIT US AGAIN*\r\n";
            // 
            // lblRepNo
            // 
            this.lblRepNo.AutoSize = true;
            this.lblRepNo.Location = new System.Drawing.Point(524, 193);
            this.lblRepNo.Name = "lblRepNo";
            this.lblRepNo.Size = new System.Drawing.Size(107, 25);
            this.lblRepNo.TabIndex = 26;
            this.lblRepNo.Text = "Receipt No :";
            // 
            // lblRecep
            // 
            this.lblRecep.AutoSize = true;
            this.lblRecep.Location = new System.Drawing.Point(514, 243);
            this.lblRecep.Name = "lblRecep";
            this.lblRecep.Size = new System.Drawing.Size(117, 25);
            this.lblRecep.TabIndex = 27;
            this.lblRecep.Text = "Receptionist :";
            // 
            // lblDt
            // 
            this.lblDt.AutoSize = true;
            this.lblDt.Location = new System.Drawing.Point(538, 218);
            this.lblDt.Name = "lblDt";
            this.lblDt.Size = new System.Drawing.Size(93, 25);
            this.lblDt.TabIndex = 28;
            this.lblDt.Text = "Datetime :";
            // 
            // lblReceptionistName
            // 
            this.lblReceptionistName.AutoSize = true;
            this.lblReceptionistName.Location = new System.Drawing.Point(655, 243);
            this.lblReceptionistName.Name = "lblReceptionistName";
            this.lblReceptionistName.Size = new System.Drawing.Size(19, 25);
            this.lblReceptionistName.TabIndex = 29;
            this.lblReceptionistName.Text = "-";
            // 
            // lblDatetime
            // 
            this.lblDatetime.AutoSize = true;
            this.lblDatetime.Location = new System.Drawing.Point(655, 218);
            this.lblDatetime.Name = "lblDatetime";
            this.lblDatetime.Size = new System.Drawing.Size(19, 25);
            this.lblDatetime.TabIndex = 30;
            this.lblDatetime.Text = "-";
            // 
            // lblReceiptNo
            // 
            this.lblReceiptNo.AutoSize = true;
            this.lblReceiptNo.Location = new System.Drawing.Point(655, 193);
            this.lblReceiptNo.Name = "lblReceiptNo";
            this.lblReceiptNo.Size = new System.Drawing.Size(19, 25);
            this.lblReceiptNo.TabIndex = 31;
            this.lblReceiptNo.Text = "-";
            // 
            // frmReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(885, 912);
            this.Controls.Add(this.lblReceiptNo);
            this.Controls.Add(this.lblDatetime);
            this.Controls.Add(this.lblReceptionistName);
            this.Controls.Add(this.lblDt);
            this.Controls.Add(this.lblRecep);
            this.Controls.Add(this.lblRepNo);
            this.Controls.Add(this.lblThankyou);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblChange);
            this.Controls.Add(this.lblPaidAmt);
            this.Controls.Add(this.listSummary);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblDiscountAmt);
            this.Controls.Add(this.lblSubTotal);
            this.Controls.Add(this.panelCusDetail);
            this.Controls.Add(this.lblCompanyAddress);
            this.Controls.Add(this.lblReceiptTitle);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.panelDetail);
            this.Name = "frmReceipt";
            this.Text = "Receipt";
            this.Load += new System.EventHandler(this.Receipt_Load);
            this.panelCusDetail.ResumeLayout(false);
            this.panelCusDetail.PerformLayout();
            this.panelDetail.ResumeLayout(false);
            this.panelDetail.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblCompanyAddress;
        private Label lblCompanyName;
        private Label lblReceiptTitle;
        private Panel panelCusDetail;
        private Label lblCusName;
        private Label lblSoldTo;
        private Label lblAdress;
        private ListBox listTitle;
        private Panel panelDetail;
        private Label lblSubTotal;
        private Label lblDiscountAmt;
        private Label lblTotal;
        private ListBox listSummary;
        private Label lblPaidAmt;
        private Label lblChange;
        private Label lblDescription;
        private Label lblThankyou;
        private Label lblttl;
        private Label lblUrgency;
        private Label lblService;
        private Label lblNo;
        private Label lblRepNo;
        private Label lblRecep;
        private Label lblDt;
        private Label lblReceptionistName;
        private Label lblDatetime;
        private Label lblReceiptNo;
        private Label lblCusTel;
    }
}