﻿namespace Assignment
{
    partial class frmRecepProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRecepProfile));
            this.lblTitle = new System.Windows.Forms.Label();
            this.picBoy = new System.Windows.Forms.PictureBox();
            this.lblContactNum = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblAction = new System.Windows.Forms.Label();
            this.btnChangePwd = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblOccupation = new System.Windows.Forms.Label();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.picGirl = new System.Windows.Forms.PictureBox();
            this.btnSetQuest = new System.Windows.Forms.Button();
            this.lblChangePic = new System.Windows.Forms.Label();
            this.panelRight = new System.Windows.Forms.Panel();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.txtContactNum = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBoy)).BeginInit();
            this.panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGirl)).BeginInit();
            this.panelRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(304, 7);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(165, 41);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "My Profile";
            // 
            // picBoy
            // 
            this.picBoy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picBoy.BackgroundImage")));
            this.picBoy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoy.Location = new System.Drawing.Point(60, 22);
            this.picBoy.Margin = new System.Windows.Forms.Padding(2);
            this.picBoy.Name = "picBoy";
            this.picBoy.Size = new System.Drawing.Size(135, 118);
            this.picBoy.TabIndex = 1;
            this.picBoy.TabStop = false;
            // 
            // lblContactNum
            // 
            this.lblContactNum.AutoSize = true;
            this.lblContactNum.BackColor = System.Drawing.Color.LightBlue;
            this.lblContactNum.Location = new System.Drawing.Point(42, 50);
            this.lblContactNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblContactNum.Name = "lblContactNum";
            this.lblContactNum.Size = new System.Drawing.Size(294, 20);
            this.lblContactNum.TabIndex = 6;
            this.lblContactNum.Text = "Email ( You are not allow to change email )";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.LightBlue;
            this.lblEmail.Location = new System.Drawing.Point(42, 118);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(118, 20);
            this.lblEmail.TabIndex = 7;
            this.lblEmail.Text = "Contact Number";
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(231, 242);
            this.txtState.Margin = new System.Windows.Forms.Padding(2);
            this.txtState.Name = "txtState";
            this.txtState.PlaceholderText = "State";
            this.txtState.Size = new System.Drawing.Size(161, 27);
            this.txtState.TabIndex = 34;
            this.txtState.Text = "-";
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(42, 206);
            this.txtStreet.Margin = new System.Windows.Forms.Padding(2);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.PlaceholderText = "Street Address";
            this.txtStreet.Size = new System.Drawing.Size(350, 27);
            this.txtStreet.TabIndex = 33;
            this.txtStreet.Text = "-";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.LightBlue;
            this.lblAddress.Location = new System.Drawing.Point(42, 184);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(62, 20);
            this.lblAddress.TabIndex = 32;
            this.lblAddress.Text = "Address";
            // 
            // txtPostcode
            // 
            this.txtPostcode.Location = new System.Drawing.Point(42, 277);
            this.txtPostcode.Margin = new System.Windows.Forms.Padding(2);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.PlaceholderText = "Postcode";
            this.txtPostcode.Size = new System.Drawing.Size(350, 27);
            this.txtPostcode.TabIndex = 31;
            this.txtPostcode.Text = "-";
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(42, 242);
            this.txtCity.Margin = new System.Windows.Forms.Padding(2);
            this.txtCity.Name = "txtCity";
            this.txtCity.PlaceholderText = "City";
            this.txtCity.Size = new System.Drawing.Size(161, 27);
            this.txtCity.TabIndex = 30;
            this.txtCity.Text = "-";
            // 
            // txtEmail
            // 
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.No;
            this.txtEmail.Location = new System.Drawing.Point(42, 75);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PlaceholderText = "City";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(350, 27);
            this.txtEmail.TabIndex = 38;
            this.txtEmail.Text = "-";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Blue;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnUpdate.Location = new System.Drawing.Point(162, 317);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(109, 33);
            this.btnUpdate.TabIndex = 41;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblAction
            // 
            this.lblAction.AutoSize = true;
            this.lblAction.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAction.Location = new System.Drawing.Point(59, 253);
            this.lblAction.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAction.Name = "lblAction";
            this.lblAction.Size = new System.Drawing.Size(149, 25);
            this.lblAction.TabIndex = 45;
            this.lblAction.Text = "Account Action";
            // 
            // btnChangePwd
            // 
            this.btnChangePwd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnChangePwd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChangePwd.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnChangePwd.ForeColor = System.Drawing.SystemColors.Control;
            this.btnChangePwd.Location = new System.Drawing.Point(19, 279);
            this.btnChangePwd.Margin = new System.Windows.Forms.Padding(2);
            this.btnChangePwd.Name = "btnChangePwd";
            this.btnChangePwd.Size = new System.Drawing.Size(216, 33);
            this.btnChangePwd.TabIndex = 47;
            this.btnChangePwd.Text = "Change Password";
            this.btnChangePwd.UseVisualStyleBackColor = false;
            this.btnChangePwd.Click += new System.EventHandler(this.btnChangePwd_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblName.Location = new System.Drawing.Point(98, 173);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(20, 25);
            this.lblName.TabIndex = 48;
            this.lblName.Text = "-";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblID.Location = new System.Drawing.Point(84, 217);
            this.lblID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(15, 20);
            this.lblID.TabIndex = 49;
            this.lblID.Text = "-";
            // 
            // lblOccupation
            // 
            this.lblOccupation.AutoSize = true;
            this.lblOccupation.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOccupation.Location = new System.Drawing.Point(84, 197);
            this.lblOccupation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOccupation.Name = "lblOccupation";
            this.lblOccupation.Size = new System.Drawing.Size(91, 20);
            this.lblOccupation.TabIndex = 50;
            this.lblOccupation.Text = "Receptionist";
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.LightBlue;
            this.panelLeft.Controls.Add(this.picBoy);
            this.panelLeft.Controls.Add(this.picGirl);
            this.panelLeft.Controls.Add(this.btnSetQuest);
            this.panelLeft.Controls.Add(this.btnChangePwd);
            this.panelLeft.Controls.Add(this.lblOccupation);
            this.panelLeft.Controls.Add(this.lblID);
            this.panelLeft.Controls.Add(this.lblName);
            this.panelLeft.Controls.Add(this.lblAction);
            this.panelLeft.Controls.Add(this.lblChangePic);
            this.panelLeft.Location = new System.Drawing.Point(18, 63);
            this.panelLeft.Margin = new System.Windows.Forms.Padding(2);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(254, 380);
            this.panelLeft.TabIndex = 51;
            // 
            // picGirl
            // 
            this.picGirl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picGirl.BackgroundImage")));
            this.picGirl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picGirl.Location = new System.Drawing.Point(59, 22);
            this.picGirl.Margin = new System.Windows.Forms.Padding(2);
            this.picGirl.Name = "picGirl";
            this.picGirl.Size = new System.Drawing.Size(135, 118);
            this.picGirl.TabIndex = 52;
            this.picGirl.TabStop = false;
            // 
            // btnSetQuest
            // 
            this.btnSetQuest.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSetQuest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetQuest.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSetQuest.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSetQuest.Location = new System.Drawing.Point(19, 317);
            this.btnSetQuest.Margin = new System.Windows.Forms.Padding(2);
            this.btnSetQuest.Name = "btnSetQuest";
            this.btnSetQuest.Size = new System.Drawing.Size(216, 33);
            this.btnSetQuest.TabIndex = 51;
            this.btnSetQuest.Text = "Set Security Question";
            this.btnSetQuest.UseVisualStyleBackColor = false;
            this.btnSetQuest.Click += new System.EventHandler(this.btnSetQuest_Click);
            // 
            // lblChangePic
            // 
            this.lblChangePic.AutoSize = true;
            this.lblChangePic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChangePic.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.lblChangePic.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblChangePic.Location = new System.Drawing.Point(75, 142);
            this.lblChangePic.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblChangePic.Name = "lblChangePic";
            this.lblChangePic.Size = new System.Drawing.Size(108, 20);
            this.lblChangePic.TabIndex = 2;
            this.lblChangePic.Text = "Change Picture";
            this.lblChangePic.Click += new System.EventHandler(this.lblChangePic_Click);
            // 
            // panelRight
            // 
            this.panelRight.BackColor = System.Drawing.Color.LightBlue;
            this.panelRight.Controls.Add(this.lblSubTitle);
            this.panelRight.Controls.Add(this.txtState);
            this.panelRight.Controls.Add(this.txtContactNum);
            this.panelRight.Controls.Add(this.btnUpdate);
            this.panelRight.Controls.Add(this.txtEmail);
            this.panelRight.Controls.Add(this.lblContactNum);
            this.panelRight.Controls.Add(this.txtStreet);
            this.panelRight.Controls.Add(this.lblEmail);
            this.panelRight.Controls.Add(this.lblAddress);
            this.panelRight.Controls.Add(this.txtCity);
            this.panelRight.Controls.Add(this.txtPostcode);
            this.panelRight.Location = new System.Drawing.Point(311, 63);
            this.panelRight.Margin = new System.Windows.Forms.Padding(2);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(432, 380);
            this.panelRight.TabIndex = 52;
            // 
            // lblSubTitle
            // 
            this.lblSubTitle.AutoSize = true;
            this.lblSubTitle.BackColor = System.Drawing.Color.LightBlue;
            this.lblSubTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSubTitle.Location = new System.Drawing.Point(140, 10);
            this.lblSubTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSubTitle.Name = "lblSubTitle";
            this.lblSubTitle.Size = new System.Drawing.Size(160, 28);
            this.lblSubTitle.TabIndex = 53;
            this.lblSubTitle.Text = "Edit Information";
            // 
            // txtContactNum
            // 
            this.txtContactNum.Location = new System.Drawing.Point(42, 141);
            this.txtContactNum.Margin = new System.Windows.Forms.Padding(2);
            this.txtContactNum.Name = "txtContactNum";
            this.txtContactNum.PlaceholderText = "Contact Number";
            this.txtContactNum.Size = new System.Drawing.Size(350, 27);
            this.txtContactNum.TabIndex = 39;
            this.txtContactNum.Text = "-";
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBack.Location = new System.Drawing.Point(18, 7);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(46, 48);
            this.btnBack.TabIndex = 53;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmRecepProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(762, 462);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.panelRight);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmRecepProfile";
            this.Text = "Receptionist Profile Page";
            this.Load += new System.EventHandler(this.frmRecepProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoy)).EndInit();
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGirl)).EndInit();
            this.panelRight.ResumeLayout(false);
            this.panelRight.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private PictureBox picBoy;
        private Label lblContactNum;
        private Label lblEmail;
        private TextBox txtState;
        private TextBox txtStreet;
        private Label lblAddress;
        private TextBox txtPostcode;
        private TextBox txtCity;
        private TextBox txtEmail;
        private Button btnUpdate;
        private Label lblAction;
        private Button btnChangePwd;
        private Label lblName;
        private Label lblID;
        private Label lblOccupation;
        private Panel panelLeft;
        private Button btnSetQuest;
        private Panel panelRight;
        private Label lblSubTitle;
        private Label lblChangePic;
        private Button btnBack;
        private TextBox txtContactNum;
        private PictureBox picGirl;
    }
}