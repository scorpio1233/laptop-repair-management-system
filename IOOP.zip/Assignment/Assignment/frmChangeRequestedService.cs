﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmChangeRequestedService : Form
    {
        public static string email;
        public frmChangeRequestedService()
        {
            InitializeComponent();
        }
        public frmChangeRequestedService(string e)
        {
            InitializeComponent();
            email = e;
        }


        //selected service is urgent or normal
        public static string Urgency(ListBox lstUr)
        {
            string selectedItem = lstUr.GetItemText(lstUr.SelectedIndex);
            return selectedItem;

        }

        //Check Selected Service
        public static string Service(ListBox lstService)
        {
            string selectedItem = lstService.GetItemText(lstService.SelectedItem);
            return selectedItem;
        }

        //Set the fee based on the selected 
        public string Fee(string service, string urgency)
        {
            string fee = "0.00";

            if (service == "Remove virus, malware or spyware" && urgency == "Normal")
                fee = "50.00";
            else if (service == "Remove virus, malware or spyware" && urgency == "Urgent")
                fee = "80.00";
            else if (service == "Troubleshot and fix computer running slow" && urgency == "Normal")
                fee = "60.00";
            else if (service == "Troubleshot and fix computer running slow" && urgency == "Urgent")
                fee = "90.00";
            else if (service == "Laptop screen replacement" && urgency == "Normal")
                fee = "380.00";
            else if (service == "Laptop screen replacement" && urgency == "Urgent")
                fee = "430.00";
            else if (service == "Laptop keyboard replacement" && urgency == "Normal")
                fee = "160.00";
            else if (service == "Laptop keyboard replacement" && urgency == "Urgent")
                fee = "200.00";
            else if (service == "Laptop battery replacement" && urgency == "Normal")
                fee = "180.00";
            else if (service == "Laptop battery replacement" && urgency == "Urgent")
                fee = "210.00";
            else if (service == "Operating System Format and Installation" && urgency == "Normal")
                fee = "100.00";
            else if (service == "Operating System Format and Installation" && urgency == "Urgent")
                fee = "150.00";
            else if (service == "Data backup and recovery" && urgency == "Normal")
                fee = "80.00";
            else if (service == "Data backup and recovery" && urgency == "Urgent")
                fee = "130.00";
            else if (service == "Internet connectivity issues" && urgency == "Normal")
                fee = "70.00";
            else if (service == "Internet connectivity issues" && urgency == "Urgent")
                fee = "100.00";

            return fee;
        }

        private void btnUpdateRequest_Click(object sender, EventArgs e)
        {
            customer obj1 = new customer(Service(lstService), Urgency(lstUr),email);
            MessageBox.Show(obj1.chgrequestservice());
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmChangeRequestedService_Load(object sender, EventArgs e)
        {
            lstService.SelectedIndex = 0;
            lstUr.SelectedIndex = 0;
        }
    }
}
