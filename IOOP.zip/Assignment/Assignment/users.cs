﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class users
    {
        //member field
        private string email;
        private string password;
        private string questionID;
        private string ans;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        //consturctor
        public users(string cemail, string cpassword)
        {
            email = cemail;
            password = cpassword;
        }

        //constructor - account recovery
        public users(string cemail, string cQuestionID, string cAns)
        {
            email = cemail;
            questionID = cQuestionID;
            ans = cAns;
        }

        //login method
        public string login(string em)
        {
            string status = null;
            con.Open();

            SqlCommand cmd = new SqlCommand("select count(*) from Login where Email = @email COLLATE SQL_Latin1_General_CP1_CS_AS and Pass = @password COLLATE SQL_Latin1_General_CP1_CS_AS", con);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@password", password);

            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0)
            {
                SqlCommand cmd2 = new SqlCommand("select Role from Login where Email = '" + email + "' and Pass = '" + password + "'", con);
                string userRole = cmd2.ExecuteScalar().ToString();

                //Identify Role
                if (userRole == "Admin")
                {
                    frmAdminHome a = new frmAdminHome(em);
                    a.ShowDialog();
                }
                else if (userRole == "Receptionist")
                {
                    frmReceptionistHome rHome = new frmReceptionistHome(em);
                    rHome.ShowDialog();
                }
                else if (userRole == "Technician")
                {
                    FrmWlcPage rHome = new FrmWlcPage(em);
                    rHome.ShowDialog();
                }
                else if (userRole == "Customer")
                {
                    frmMenu cHome = new frmMenu(em);
                    cHome.ShowDialog();
                }
            }
            else
                status = "Incorrect email/password";

            con.Close();
            return status;
        }

        //account recovery - find password
        public string findPwd()
        {
            string status = null;
            con.Open();

            SqlCommand cmd = new SqlCommand("select count(*) from Login where Email = @email COLLATE SQL_Latin1_General_CP1_CS_AS and QuestionID = '" + questionID + "' and Ans = '" + ans + "'", con);
            cmd.Parameters.AddWithValue("@email", email);

            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0)
            {
                SqlCommand cmd2 = new SqlCommand("select Pass from Login where Email = '" + email + "' and QuestionID = '" + questionID + "' and Ans = '" + ans + "'", con);
                string founded_password = cmd2.ExecuteScalar().ToString();
                status = "This is your password: " + founded_password;
            }
            else
                status = "Incorrect Email/Question/Answer";

            con.Close();
            return status;
        }
    }
}
