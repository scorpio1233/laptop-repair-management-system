﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    
    internal class Income
    {
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        public string showIncome(string month, string year)
        { 
            con.Open();
            decimal incomeAmount = 0;
            ArrayList allPaymentIncome = new ArrayList();

            SqlCommand cmd = new SqlCommand("select Total from [Payment] where month(PaymentDate) = '" + month + "' and year(PaymentDate) = '" + year + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                for (int k = 0; k < rd.FieldCount; k++)
                    incomeAmount += rd.GetDecimal(k);
            }
            con.Close();
            return incomeAmount.ToString(); 
        }


    }
}
