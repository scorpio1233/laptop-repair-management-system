﻿namespace Assignment
{
    partial class frmReceptionistHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReceptionistHome));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDatetime = new System.Windows.Forms.Label();
            this.timerDatetime = new System.Windows.Forms.Timer(this.components);
            this.picReceipt = new System.Windows.Forms.PictureBox();
            this.btnPayment = new System.Windows.Forms.Button();
            this.picProfile = new System.Windows.Forms.PictureBox();
            this.picPayment = new System.Windows.Forms.PictureBox();
            this.picRegCus = new System.Windows.Forms.PictureBox();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnRegCus = new System.Windows.Forms.Button();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picReceipt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProfile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRegCus)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(135, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(532, 60);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Receptionist Home Page";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 402);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(73, 25);
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Name:  ";
            // 
            // lblDatetime
            // 
            this.lblDatetime.AutoSize = true;
            this.lblDatetime.Location = new System.Drawing.Point(617, 402);
            this.lblDatetime.Name = "lblDatetime";
            this.lblDatetime.Size = new System.Drawing.Size(50, 25);
            this.lblDatetime.TabIndex = 6;
            this.lblDatetime.Text = "Time";
            // 
            // timerDatetime
            // 
            this.timerDatetime.Tick += new System.EventHandler(this.timerDatetime_Tick);
            // 
            // picReceipt
            // 
            this.picReceipt.BackColor = System.Drawing.Color.DodgerBlue;
            this.picReceipt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picReceipt.BackgroundImage")));
            this.picReceipt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picReceipt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picReceipt.Location = new System.Drawing.Point(487, 181);
            this.picReceipt.Name = "picReceipt";
            this.picReceipt.Size = new System.Drawing.Size(78, 68);
            this.picReceipt.TabIndex = 30;
            this.picReceipt.TabStop = false;
            this.picReceipt.Click += new System.EventHandler(this.picReceipt_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPayment.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPayment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPayment.Location = new System.Drawing.Point(230, 145);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(177, 183);
            this.btnPayment.TabIndex = 29;
            this.btnPayment.Text = "Accept\r\nPayment";
            this.btnPayment.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // picProfile
            // 
            this.picProfile.BackColor = System.Drawing.Color.DodgerBlue;
            this.picProfile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picProfile.BackgroundImage")));
            this.picProfile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picProfile.Location = new System.Drawing.Point(691, 181);
            this.picProfile.Name = "picProfile";
            this.picProfile.Size = new System.Drawing.Size(86, 81);
            this.picProfile.TabIndex = 28;
            this.picProfile.TabStop = false;
            this.picProfile.Click += new System.EventHandler(this.picProfile_Click);
            // 
            // picPayment
            // 
            this.picPayment.BackColor = System.Drawing.Color.DodgerBlue;
            this.picPayment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPayment.BackgroundImage")));
            this.picPayment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picPayment.Location = new System.Drawing.Point(282, 181);
            this.picPayment.Name = "picPayment";
            this.picPayment.Size = new System.Drawing.Size(78, 68);
            this.picPayment.TabIndex = 27;
            this.picPayment.TabStop = false;
            this.picPayment.Click += new System.EventHandler(this.picPayment_Click);
            // 
            // picRegCus
            // 
            this.picRegCus.BackColor = System.Drawing.Color.DodgerBlue;
            this.picRegCus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picRegCus.BackgroundImage")));
            this.picRegCus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picRegCus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picRegCus.Location = new System.Drawing.Point(81, 181);
            this.picRegCus.Name = "picRegCus";
            this.picRegCus.Size = new System.Drawing.Size(78, 68);
            this.picRegCus.TabIndex = 26;
            this.picRegCus.TabStop = false;
            this.picRegCus.Click += new System.EventHandler(this.picRegCus_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProfile.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnProfile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnProfile.Location = new System.Drawing.Point(644, 145);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(177, 183);
            this.btnProfile.TabIndex = 25;
            this.btnProfile.Text = "Profile";
            this.btnProfile.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnRegCus
            // 
            this.btnRegCus.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnRegCus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegCus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegCus.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRegCus.Location = new System.Drawing.Point(32, 145);
            this.btnRegCus.Name = "btnRegCus";
            this.btnRegCus.Size = new System.Drawing.Size(177, 183);
            this.btnRegCus.TabIndex = 24;
            this.btnRegCus.Text = "Register \r\nCustomer";
            this.btnRegCus.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRegCus.UseVisualStyleBackColor = false;
            this.btnRegCus.Click += new System.EventHandler(this.btnRegCus_Click);
            // 
            // btnReceipt
            // 
            this.btnReceipt.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnReceipt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReceipt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnReceipt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReceipt.Location = new System.Drawing.Point(436, 145);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(177, 183);
            this.btnReceipt.TabIndex = 23;
            this.btnReceipt.Text = "Generate\r\nReceipt\r\n";
            this.btnReceipt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReceipt.UseVisualStyleBackColor = false;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogout.BackgroundImage")));
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnLogout.Location = new System.Drawing.Point(741, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(80, 84);
            this.btnLogout.TabIndex = 48;
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmReceptionistHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(853, 450);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.picReceipt);
            this.Controls.Add(this.picProfile);
            this.Controls.Add(this.picPayment);
            this.Controls.Add(this.picRegCus);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnRegCus);
            this.Controls.Add(this.btnReceipt);
            this.Controls.Add(this.lblDatetime);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnPayment);
            this.Name = "frmReceptionistHome";
            this.Text = "Receptionist Home Page";
            this.Load += new System.EventHandler(this.frmReceptionistHome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picReceipt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProfile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRegCus)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label lblName;
        private Label lblDatetime;
        private System.Windows.Forms.Timer timerDatetime;
        private PictureBox picReceipt;
        private Button btnPayment;
        private PictureBox picProfile;
        private PictureBox picPayment;
        private PictureBox picRegCus;
        private Button btnProfile;
        private Button btnRegCus;
        private Button btnReceipt;
        private Button btnLogout;
    }
}