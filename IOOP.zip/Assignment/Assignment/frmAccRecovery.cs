﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmAccRecovery : Form
    {
        public frmAccRecovery()
        {
            InitializeComponent();
        }

        private void frmAccRecovery_Load(object sender, EventArgs e)
        {
            cmbSecurityQ.SelectedIndex = 0;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string questionNo = "QUS00";
            for (int i = 0; i < cmbSecurityQ.Items.Count; i++)
            {
                if (cmbSecurityQ.SelectedIndex == i)
                    questionNo += (i+1).ToString();
            }

            if (txtEmail.Text != string.Empty && txtAns.Text != string.Empty)
            {
                users obj1 = new users(txtEmail.Text, questionNo, txtAns.Text);
                MessageBox.Show(obj1.findPwd());
            }
            else
                MessageBox.Show("Please fill in all the text boxes.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmail.Text = string.Empty;
            txtAns.Text = string.Empty;
            cmbSecurityQ.SelectedIndex = 0;
        }
    }
}
