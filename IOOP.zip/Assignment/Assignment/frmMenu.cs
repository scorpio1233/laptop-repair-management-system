namespace Assignment
{
    public partial class frmMenu : Form
    {
        public static string email;
        public static string name;
        public frmMenu()
        {
            InitializeComponent();
        }
        public frmMenu(string e)
        {
            InitializeComponent();
            email = e;
        }
        
        private void frmMenu_Load(object sender, EventArgs e)
        {
            customer obj1 = new customer(email);
            lblName.Text = obj1.showName();
            string id = obj1.showID();
            string customerID = "ID: CUS";
            if (id.Length == 1)
                customerID += ("000" + id);
            else if (id.Length == 2)
                customerID += ("00" + id);
            else if (id.Length == 3)
                customerID += ("0" + id);
            else
                customerID += id;
            lblID.Text = customerID;
        }
        private void btnChangeRequest_Click(object sender, EventArgs e)
        {
            frmChangeRequestedService obj1 = new frmChangeRequestedService(email);
            obj1.ShowDialog();
        }

        private void btnExistingService_Click(object sender, EventArgs e)
        {
            frmExistingRequestedDescription obj2 = new frmExistingRequestedDescription(email);
            obj2.ShowDialog();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            frmCustomerProfile obj3 = new frmCustomerProfile(email);
            obj3.ShowDialog();
        }
        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}