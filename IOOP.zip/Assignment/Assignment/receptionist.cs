﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class receptionist
    {
        //member field
        private int recepID;
        private string name;
        private string email;
        private string telNum;
        private string street;
        private string city;
        private string state;
        private int postcode;
        private string picID;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        //get set method
        public int RecepID { get => recepID; set => recepID = value; }
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string TelNum { get => telNum; set => telNum = value; }
        public string Street { get => street; set => street = value; }
        public string City { get => city; set => city = value; }
        public string State { get => state; set => state = value; }
        public string PicID { get => picID; set => picID = value; }
        public int Postcode { get => postcode; set => postcode = value; }


        //constructor
        public receptionist(string cEmail) 
        {
            email = cEmail;
        }

        //method
        //show name in home page
        public string showName()
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("select Name from Receptionist where Email = '" + email + "'", con);
            string name = cmd.ExecuteScalar().ToString();

            con.Close();
            return name;
        }

        //view profile
        public static void viewProfile(receptionist o1) 
        {
            con.Open();
            SqlCommand cmd2 = new SqlCommand("select * from [Receptionist] where Email = '" + o1.email + "'", con);
            SqlDataReader rd2 = cmd2.ExecuteReader();
            while (rd2.Read())
            {
                o1.recepID = rd2.GetInt32(0);
                o1.name = rd2.GetString(1);
                o1.email = rd2.GetString(2);
                o1.telNum = rd2.GetString(3);
                o1.street = rd2.GetString(4);
                o1.city = rd2.GetString(5);
                o1.state = rd2.GetString(6);
                o1.postcode = rd2.GetInt32(7);
                o1.picID = rd2.GetString(8);
            }
            con.Close();
        }

        //change picture
        public string changePic(string pic)
        {
            string status = null;
            con.Open();
            picID = pic;

            SqlCommand cmd3 = new SqlCommand("update [Receptionist] set PicID = '" + picID + "' where Email = '" + email + "'" , con);
            int i = cmd3.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();
            return status;
        }

        //update Profile
        public string updateProfile(string new_telnum, string new_street, string new_city, string new_state, string new_postcode)
        {
            string status;
            con.Open();

            telNum = new_telnum;
            street = new_street;
            city = new_city;
            state = new_state;
            postcode = Int32.Parse(new_postcode);

            SqlCommand cmd4 = new SqlCommand("update [Receptionist] set TelNum = '" + telNum + "', Street = '" + street + "', City = '" + city + "', State = '" + state + "', postcode = '" + postcode + "' where Email = '" + email + "'", con);
            int i = cmd4.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();

            return status;
        }


    }
}
