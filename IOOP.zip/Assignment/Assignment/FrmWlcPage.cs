namespace Assignment
{
    public partial class FrmWlcPage : Form
    {
        public static string email;
        public static string techid;
        public FrmWlcPage(string mail)
        {
            InitializeComponent();
            email = mail;
        }

        private void btnSWorking_Click(object sender, EventArgs e)
        {
            technician obj1 = new technician(email);
            techid = obj1.getId(email);
            FrmPending form = new FrmPending(email, techid);
            form.Show();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            FrmProfile form = new FrmProfile(email);
            form.Show();
        }

        private void FrmWlcPage_Load(object sender, EventArgs e)
        {
            technician obj1 = new technician(email);
            lblName.Text = "Technician :  " + obj1.getName(email);
            lblID.Text = obj1.getId(email);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            string text = "Are you sure to LOGOUT ?";
            string title = "Logout";

            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(text, title, buttons);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
            
        }
    }
}