﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmPayment : Form
    {
        public static string totalPay;
        public static string orderID;
        public static string subtotal;
        public static string receptionistName;
        public frmPayment()
        {
            InitializeComponent();
        }

        public frmPayment(string cOrderID, string cSubTotal, string cTotalPay, string cReceptionistName)
        {
            InitializeComponent();
            totalPay = cTotalPay; 
            orderID = cOrderID;
            subtotal = cSubTotal;
            receptionistName = cReceptionistName;
        }


        
        private void frmPayment_Load(object sender, EventArgs e)
        {
            lblTotalPayAmt.Text = totalPay;
            cmbPayMethod.SelectedIndex = 0;
        }
    

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtPaidAmt.Text, out double totalPaidAmount))
            {
                if (totalPaidAmount >= double.Parse(lblTotalPayAmt.Text))
                {
                    payment py = new payment(orderID, subtotal, totalPay, totalPaidAmount, receptionistName);
                    string result = py.addPayment();
                    if (result == "Payment Successful.")
                    {
                        DialogResult printReceipt = MessageBox.Show("Payment Succesfully. Do you want to print a receipt?", "Succesful", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (printReceipt == DialogResult.Yes)
                        {
                            this.Hide();
                            frmReceipt obj1 = new frmReceipt(orderID);
                            obj1.ShowDialog();
                            this.Close();
                        }
                        else if(printReceipt == DialogResult.No)
                            this.Close();
                    }
                    else
                        MessageBox.Show("Fail to make payment");
                }
                else
                    MessageBox.Show("Paid amount must more than or equal to total payable amount.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Invalid Input.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtPaidAmt_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(txtPaidAmt.Text, out double totalPaidAmount))
            {
                double change = totalPaidAmount - double.Parse(lblTotalPayAmt.Text);
                if (change > 0)
                {
                    change = Math.Round(change, 2);
                    lblChangeAmt.Text = change.ToString();
                    //Make amount to 2 decimal places
                    if (int.TryParse(lblChangeAmt.Text, out int result))
                        lblChangeAmt.Text = lblChangeAmt.Text + ".00";
                    else
                    {
                        string[] arrayChangeAmt = lblChangeAmt.Text.Split('.');
                        if (arrayChangeAmt[1].Length == 1)
                            lblChangeAmt.Text = lblChangeAmt.Text + "0";
                    }
                }
                else
                    lblChangeAmt.Text = "-";
            }
            else
                lblChangeAmt.Text = "-";
        }


    }
}
