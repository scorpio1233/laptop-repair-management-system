﻿namespace Assignment
{
    partial class FrmViewJob
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBView = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lvService = new System.Windows.Forms.ListView();
            this.ord_id = new System.Windows.Forms.ColumnHeader();
            this.cus_ID = new System.Windows.Forms.ColumnHeader();
            this.cus_name = new System.Windows.Forms.ColumnHeader();
            this.service = new System.Windows.Forms.ColumnHeader();
            this.laptop = new System.Windows.Forms.ColumnHeader();
            this.status = new System.Windows.Forms.ColumnHeader();
            this.btnTake = new System.Windows.Forms.Button();
            this.btnFilter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBView
            // 
            this.btnBView.BackColor = System.Drawing.Color.LightPink;
            this.btnBView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBView.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBView.Location = new System.Drawing.Point(12, 12);
            this.btnBView.Name = "btnBView";
            this.btnBView.Size = new System.Drawing.Size(96, 36);
            this.btnBView.TabIndex = 11;
            this.btnBView.Text = "Back";
            this.btnBView.UseVisualStyleBackColor = false;
            this.btnBView.Click += new System.EventHandler(this.btnBView_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(115, 51);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 41);
            this.label1.TabIndex = 12;
            this.label1.Text = "SERVICE REQUESTED";
            // 
            // lvService
            // 
            this.lvService.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ord_id,
            this.cus_ID,
            this.cus_name,
            this.service,
            this.laptop,
            this.status});
            this.lvService.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lvService.FullRowSelect = true;
            this.lvService.Location = new System.Drawing.Point(31, 106);
            this.lvService.Name = "lvService";
            this.lvService.Size = new System.Drawing.Size(967, 373);
            this.lvService.TabIndex = 13;
            this.lvService.UseCompatibleStateImageBehavior = false;
            this.lvService.View = System.Windows.Forms.View.Details;
            // 
            // ord_id
            // 
            this.ord_id.Text = "Order ID";
            this.ord_id.Width = 100;
            // 
            // cus_ID
            // 
            this.cus_ID.Text = "Customer ID";
            this.cus_ID.Width = 130;
            // 
            // cus_name
            // 
            this.cus_name.Text = "Customer Name";
            this.cus_name.Width = 180;
            // 
            // service
            // 
            this.service.Text = "Service Requested";
            this.service.Width = 200;
            // 
            // laptop
            // 
            this.laptop.Text = "Laptop Model";
            this.laptop.Width = 250;
            // 
            // status
            // 
            this.status.Text = "Status";
            this.status.Width = 100;
            // 
            // btnTake
            // 
            this.btnTake.BackColor = System.Drawing.Color.Gold;
            this.btnTake.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTake.Location = new System.Drawing.Point(830, 494);
            this.btnTake.Name = "btnTake";
            this.btnTake.Size = new System.Drawing.Size(168, 43);
            this.btnTake.TabIndex = 14;
            this.btnTake.Text = "Take This Job";
            this.btnTake.UseVisualStyleBackColor = false;
            this.btnTake.Click += new System.EventHandler(this.btnTake_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackColor = System.Drawing.Color.LightCyan;
            this.btnFilter.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFilter.Location = new System.Drawing.Point(877, 51);
            this.btnFilter.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(103, 33);
            this.btnFilter.TabIndex = 15;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = false;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmViewJob
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(1031, 556);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.btnTake);
            this.Controls.Add(this.lvService);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBView);
            this.Name = "FrmViewJob";
            this.Text = "Service Requested Page";
            this.Load += new System.EventHandler(this.FrmViewJob_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnBView;
        private Label label1;
        private ListView lvService;
        private ColumnHeader cus_name;
        private ColumnHeader cus_ID;
        private ColumnHeader laptop;
        private ColumnHeader service;
        private ColumnHeader status;
        private Button btnTake;
        private Button btnFilter;
        private ColumnHeader ord_id;
    }
}