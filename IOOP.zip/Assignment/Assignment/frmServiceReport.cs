﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmServiceReport : Form
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());


        public frmServiceReport()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {

            string date = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            string order_ID = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            string Tech_ID = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            string Desc = dataGridView1.CurrentRow.Cells[3].Value.ToString();


            frmInformation obj1 = new frmInformation(date, order_ID, Tech_ID, Desc);
            obj1.ShowDialog();
        }

        private void frmServiceReport_Load(object sender, EventArgs e)
        {
            con.Open();
            string query = "select Date, OrderID, TechID, Description from Service";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //Service_Report obj1 = new Service_Report(txtSearch.Text);
            //string status = obj1.showReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "select Date, OrderID, TechID, Description from Service where OrderID = '" + txtSearch.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            txtSearch.Text = String.Empty;
            

        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==(char)13)
                btnSearch.PerformClick();
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "select Date, OrderID, TechID, Description from Service";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }


    }
}
