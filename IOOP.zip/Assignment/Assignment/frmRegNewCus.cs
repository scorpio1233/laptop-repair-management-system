﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmRegNewCus : Form
    {
        public frmRegNewCus()
        {
            InitializeComponent();
        }

        private void frmRegNewCus_Load(object sender, EventArgs e)
        {
            cmbService.SelectedIndex = 0;
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            //Identify urgency
            string urgency = null;
            if (radNormal.Checked == true)
                urgency = "Normal";
            else if (radUrgent.Checked == true)
                urgency = "Urgent";


            //Check is there any empty input
            string[] cus_detail_array = new[] {txtName.Text, txtEmail.Text, txtPhoneNum.Text, txtStreet.Text, txtCity.Text, txtState.Text, txtPostcode.Text, cmbService.SelectedItem.ToString(), urgency, txtRemark.Text}; 
            bool empty_textbox = false;
            for (int i = 0; i < cus_detail_array.Length; i++)
            {
                if (cus_detail_array[i] == string.Empty)
                   empty_textbox = true;
            }
           
            if (empty_textbox == false)
            {
                if (txtEmail.Text.Contains("@") && txtEmail.Text.Contains(".")) //Check email
                {
                    if (Int32.TryParse(txtPostcode.Text, out int postcodeNum) && txtPostcode.Text.Length == 5) // Check postcode
                    {
                        //Create customer
                        customer obj1 = new customer(txtName.Text, txtEmail.Text, txtPhoneNum.Text, txtStreet.Text, txtCity.Text, txtState.Text, txtPostcode.Text);
                        string result = obj1.addCustomer();
                        MessageBox.Show(result, "Result");
                        
                        if (result != "Unable to register." && result != null && result != "Unable to register. Email already existed.")
                        {
                            //Create order                
                            order or = new order(txtEmail.Text, cmbService.SelectedItem.ToString(), urgency, txtRemark.Text);
                            MessageBox.Show(or.addOrder(), "Result");
                            clearInput();
                        }
                    }
                    else
                        MessageBox.Show("Postcode must be 5-digit numbers.");
                }
                else
                    MessageBox.Show("Email must contains '@' and '.'");
            }
            else if (empty_textbox == true)
                MessageBox.Show("Please fill in all the text box.");                
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearInput();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Clear all input method
        public void clearInput()
        {
            txtName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPhoneNum.Text = string.Empty;
            txtPostcode.Text = string.Empty;
            txtRemark.Text = string.Empty;
            txtState.Text = string.Empty;
            txtStreet.Text = string.Empty;
            txtCity.Text = string.Empty;
            cmbService.SelectedIndex = 0;
            radNormal.Checked = true;
        }

    }
}
