﻿namespace Assignment
{
    partial class frmChangePic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChangePic));
            this.picMan = new System.Windows.Forms.PictureBox();
            this.picWoman = new System.Windows.Forms.PictureBox();
            this.radPic1 = new System.Windows.Forms.RadioButton();
            this.radPic2 = new System.Windows.Forms.RadioButton();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picMan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWoman)).BeginInit();
            this.SuspendLayout();
            // 
            // picMan
            // 
            this.picMan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picMan.BackgroundImage")));
            this.picMan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picMan.Location = new System.Drawing.Point(102, 98);
            this.picMan.Name = "picMan";
            this.picMan.Size = new System.Drawing.Size(232, 206);
            this.picMan.TabIndex = 0;
            this.picMan.TabStop = false;
            // 
            // picWoman
            // 
            this.picWoman.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picWoman.BackgroundImage")));
            this.picWoman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picWoman.Location = new System.Drawing.Point(467, 98);
            this.picWoman.Name = "picWoman";
            this.picWoman.Size = new System.Drawing.Size(232, 206);
            this.picWoman.TabIndex = 1;
            this.picWoman.TabStop = false;
            // 
            // radPic1
            // 
            this.radPic1.AutoSize = true;
            this.radPic1.Checked = true;
            this.radPic1.Location = new System.Drawing.Point(166, 324);
            this.radPic1.Name = "radPic1";
            this.radPic1.Size = new System.Drawing.Size(105, 29);
            this.radPic1.TabIndex = 2;
            this.radPic1.TabStop = true;
            this.radPic1.Text = "Picture 1";
            this.radPic1.UseVisualStyleBackColor = true;
            // 
            // radPic2
            // 
            this.radPic2.AutoSize = true;
            this.radPic2.Location = new System.Drawing.Point(533, 324);
            this.radPic2.Name = "radPic2";
            this.radPic2.Size = new System.Drawing.Size(105, 29);
            this.radPic2.TabIndex = 3;
            this.radPic2.Text = "Picture 2";
            this.radPic2.UseVisualStyleBackColor = true;
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnConfirm.Location = new System.Drawing.Point(351, 381);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(112, 34);
            this.btnConfirm.TabIndex = 4;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(272, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(246, 45);
            this.lblTitle.TabIndex = 47;
            this.lblTitle.Text = "Change Picture";
            // 
            // frmChangePic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.radPic2);
            this.Controls.Add(this.radPic1);
            this.Controls.Add(this.picWoman);
            this.Controls.Add(this.picMan);
            this.Name = "frmChangePic";
            this.Text = "Change Picture";
            ((System.ComponentModel.ISupportInitialize)(this.picMan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWoman)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox picMan;
        private PictureBox picWoman;
        private RadioButton radPic1;
        private RadioButton radPic2;
        private Button btnConfirm;
        private Label lblTitle;
    }
}