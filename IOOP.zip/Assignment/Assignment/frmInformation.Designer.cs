﻿namespace Assignment
{
    partial class frmInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblServiceDetail = new System.Windows.Forms.Label();
            this.lblOrder = new System.Windows.Forms.Label();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.grpSummary = new System.Windows.Forms.GroupBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPay = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblDm = new System.Windows.Forms.Label();
            this.lblStat = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblSerDescribe = new System.Windows.Forms.Label();
            this.lblCusName = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblUser3 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblTech = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblCompany = new System.Windows.Forms.Label();
            this.grpSummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblServiceDetail
            // 
            this.lblServiceDetail.AutoSize = true;
            this.lblServiceDetail.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblServiceDetail.Location = new System.Drawing.Point(417, 29);
            this.lblServiceDetail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblServiceDetail.Name = "lblServiceDetail";
            this.lblServiceDetail.Size = new System.Drawing.Size(329, 60);
            this.lblServiceDetail.TabIndex = 11;
            this.lblServiceDetail.Text = "Service Detail";
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblOrder.Location = new System.Drawing.Point(61, 181);
            this.lblOrder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(140, 32);
            this.lblOrder.TabIndex = 15;
            this.lblOrder.Text = "Order ID: ";
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderID.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblOrderID.Location = new System.Drawing.Point(227, 179);
            this.lblOrderID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(2, 34);
            this.lblOrderID.TabIndex = 19;
            // 
            // grpSummary
            // 
            this.grpSummary.BackColor = System.Drawing.Color.Turquoise;
            this.grpSummary.Controls.Add(this.lblPrice);
            this.grpSummary.Controls.Add(this.lblPay);
            this.grpSummary.Controls.Add(this.lblModel);
            this.grpSummary.Controls.Add(this.lblDm);
            this.grpSummary.Controls.Add(this.lblStat);
            this.grpSummary.Controls.Add(this.lblStatus);
            this.grpSummary.Controls.Add(this.lblSerDescribe);
            this.grpSummary.Controls.Add(this.lblCusName);
            this.grpSummary.Controls.Add(this.lblService);
            this.grpSummary.Controls.Add(this.lblUser3);
            this.grpSummary.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grpSummary.Location = new System.Drawing.Point(48, 270);
            this.grpSummary.Margin = new System.Windows.Forms.Padding(4);
            this.grpSummary.Name = "grpSummary";
            this.grpSummary.Padding = new System.Windows.Forms.Padding(4);
            this.grpSummary.Size = new System.Drawing.Size(1013, 319);
            this.grpSummary.TabIndex = 20;
            this.grpSummary.TabStop = false;
            this.grpSummary.Text = "Summary";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPrice.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPrice.Location = new System.Drawing.Point(684, 163);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(2, 27);
            this.lblPrice.TabIndex = 27;
            // 
            // lblPay
            // 
            this.lblPay.AutoSize = true;
            this.lblPay.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPay.Location = new System.Drawing.Point(526, 167);
            this.lblPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPay.Name = "lblPay";
            this.lblPay.Size = new System.Drawing.Size(102, 24);
            this.lblPay.TabIndex = 26;
            this.lblPay.Text = "Payment: ";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblModel.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblModel.Location = new System.Drawing.Point(684, 71);
            this.lblModel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(2, 27);
            this.lblModel.TabIndex = 25;
            // 
            // lblDm
            // 
            this.lblDm.AutoSize = true;
            this.lblDm.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDm.Location = new System.Drawing.Point(526, 74);
            this.lblDm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDm.Name = "lblDm";
            this.lblDm.Size = new System.Drawing.Size(144, 24);
            this.lblDm.TabIndex = 24;
            this.lblDm.Text = "Device Model: ";
            // 
            // lblStat
            // 
            this.lblStat.AutoSize = true;
            this.lblStat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStat.Location = new System.Drawing.Point(170, 239);
            this.lblStat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStat.Name = "lblStat";
            this.lblStat.Size = new System.Drawing.Size(2, 27);
            this.lblStat.TabIndex = 23;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStatus.Location = new System.Drawing.Point(48, 243);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(78, 24);
            this.lblStatus.TabIndex = 22;
            this.lblStatus.Text = "Status: ";
            // 
            // lblSerDescribe
            // 
            this.lblSerDescribe.AutoSize = true;
            this.lblSerDescribe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSerDescribe.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSerDescribe.Location = new System.Drawing.Point(170, 159);
            this.lblSerDescribe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSerDescribe.Name = "lblSerDescribe";
            this.lblSerDescribe.Size = new System.Drawing.Size(2, 27);
            this.lblSerDescribe.TabIndex = 21;
            // 
            // lblCusName
            // 
            this.lblCusName.AutoSize = true;
            this.lblCusName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCusName.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCusName.Location = new System.Drawing.Point(170, 70);
            this.lblCusName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCusName.Name = "lblCusName";
            this.lblCusName.Size = new System.Drawing.Size(2, 27);
            this.lblCusName.TabIndex = 20;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblService.Location = new System.Drawing.Point(47, 163);
            this.lblService.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(88, 24);
            this.lblService.TabIndex = 19;
            this.lblService.Text = "Service: ";
            // 
            // lblUser3
            // 
            this.lblUser3.AutoSize = true;
            this.lblUser3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblUser3.Location = new System.Drawing.Point(48, 74);
            this.lblUser3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser3.Name = "lblUser3";
            this.lblUser3.Size = new System.Drawing.Size(131, 24);
            this.lblUser3.TabIndex = 18;
            this.lblUser3.Text = "CustomerID: ";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(40, 610);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(95, 36);
            this.btnBack.TabIndex = 22;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblTech
            // 
            this.lblTech.AutoSize = true;
            this.lblTech.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTech.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTech.Location = new System.Drawing.Point(576, 183);
            this.lblTech.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTech.Name = "lblTech";
            this.lblTech.Size = new System.Drawing.Size(2, 34);
            this.lblTech.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(372, 185);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 32);
            this.label2.TabIndex = 23;
            this.label2.Text = "Technician ID: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(759, 183);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 32);
            this.label3.TabIndex = 25;
            this.label3.Text = "Date: ";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDate.Location = new System.Drawing.Point(852, 183);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(2, 34);
            this.lblDate.TabIndex = 26;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCompany.Location = new System.Drawing.Point(759, 59);
            this.lblCompany.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(277, 24);
            this.lblCompany.TabIndex = 27;
            this.lblCompany.Text = "FIX-IT FELIX Laptop Repair";
            // 
            // frmInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1195, 661);
            this.Controls.Add(this.lblCompany);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblTech);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.grpSummary);
            this.Controls.Add(this.lblOrderID);
            this.Controls.Add(this.lblOrder);
            this.Controls.Add(this.lblServiceDetail);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmInformation";
            this.Text = "Information";
            this.Load += new System.EventHandler(this.frmInformation_Load);
            this.grpSummary.ResumeLayout(false);
            this.grpSummary.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblServiceDetail;
        private Label lblOrder;
        private Label lblOrderID;
        private GroupBox grpSummary;
        private Button btnBack;
        private Label lblSerDescribe;
        private Label lblCusName;
        private Label lblService;
        private Label lblUser3;
        private Label lblDm;
        private Label lblStat;
        private Label lblStatus;
        private Label lblPrice;
        private Label lblPay;
        private Label lblModel;
        private Label lblTech;
        private Label label2;
        private Label label3;
        private Label lblDate;
        private Label lblCompany;
    }
}