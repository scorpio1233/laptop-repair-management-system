﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmRecepProfile : Form
    {
        public static string email;

        public frmRecepProfile()
        {
            InitializeComponent();
        }

        //consturctor - from home page 
        public frmRecepProfile(string cEmail)
        {
            InitializeComponent();
            email = cEmail;
        }


        private void frmRecepProfile_Load(object sender, EventArgs e)
        {
            displayDetail();
        }

        private void lblChangePic_Click(object sender, EventArgs e)
        {
            frmChangePic obj2 = new frmChangePic(email);
            obj2.ShowDialog();
            displayDetail();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (checkEmpty() == false)
            {
                if (Int32.TryParse(txtPostcode.Text, out int postcodeNum) && txtPostcode.Text.Length == 5)
                {
                    receptionist obj1 = new receptionist(email);
                    MessageBox.Show(obj1.updateProfile(txtContactNum.Text, txtStreet.Text, txtCity.Text, txtState.Text, txtPostcode.Text));
                }
                else
                    MessageBox.Show("Postcode must be 5-digit number");
            }
            else
                MessageBox.Show("All text box cannot be empty.");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //method - display personal information
        public void displayDetail()
        {
            receptionist obj1 = new receptionist(email);

            //calling static method require className.method(..)
            //pass object obj1 to method viewProfile
            receptionist.viewProfile(obj1);

            txtEmail.Text = obj1.Email;
            txtContactNum.Text = obj1.TelNum;
            txtState.Text = obj1.State;
            txtStreet.Text = obj1.Street;
            txtCity.Text = obj1.City;
            txtPostcode.Text = obj1.Postcode.ToString();

            string receptionistID = "ID: REC";
            if (obj1.RecepID < 10)
                receptionistID += ("000" + obj1.RecepID.ToString());
            else if (obj1.RecepID < 100 && obj1.RecepID >= 10)
                receptionistID += ("00" + obj1.RecepID.ToString());
            else if (obj1.RecepID < 1000 && obj1.RecepID >= 100)
                receptionistID += ("0" + obj1.RecepID.ToString());
            else
                receptionistID += obj1.RecepID.ToString();

            lblID.Text = receptionistID;
            lblName.Text = obj1.Name;
            if (obj1.PicID == "PIC01")
            {
                picGirl.Visible = false;
                picBoy.Visible = true;
            }
            else if (obj1.PicID == "PIC02")
            {
                picGirl.Visible = true;
                picBoy.Visible = false;
            }
        }

        public bool checkEmpty()
        {
            bool empty = false;
            if (txtContactNum.Text == string.Empty || txtContactNum.Text == string.Empty || txtState.Text == string.Empty || txtStreet.Text == string.Empty || txtCity.Text == string.Empty || txtPostcode.Text == string.Empty)
                empty = true;
            return empty;
        }

        private void btnChangePwd_Click(object sender, EventArgs e)
        {
            FrmChangePass form = new FrmChangePass(email);
            form.Show();
        }

        private void btnSetQuest_Click(object sender, EventArgs e)
        {
            FrmSetSecure form = new FrmSetSecure(email);
            form.Show();
        }
    }
}
