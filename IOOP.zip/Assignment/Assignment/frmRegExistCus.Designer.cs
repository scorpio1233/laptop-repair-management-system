﻿namespace Assignment
{
    partial class frmRegExistCus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegExistCus));
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            this.btnBack = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.grpService = new System.Windows.Forms.GroupBox();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.radUrgent = new System.Windows.Forms.RadioButton();
            this.radNormal = new System.Windows.Forms.RadioButton();
            this.lblService = new System.Windows.Forms.Label();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.lblRemark = new System.Windows.Forms.Label();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.lvCustomer = new System.Windows.Forms.ListView();
            this.columnCusID = new System.Windows.Forms.ColumnHeader();
            this.columnName = new System.Windows.Forms.ColumnHeader();
            this.columnEmail = new System.Windows.Forms.ColumnHeader();
            this.columnTelNum = new System.Windows.Forms.ColumnHeader();
            this.panelSelectCus = new System.Windows.Forms.Panel();
            this.lblDescription = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.grpService.SuspendLayout();
            this.panelSelectCus.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBack.Location = new System.Drawing.Point(12, 9);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(57, 60);
            this.btnBack.TabIndex = 32;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(233, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(422, 45);
            this.lblTitle.TabIndex = 31;
            this.lblTitle.Text = "Register Existing Customer";
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.Blue;
            this.btnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegister.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRegister.Location = new System.Drawing.Point(507, 677);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(134, 50);
            this.btnRegister.TabIndex = 37;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // grpService
            // 
            this.grpService.BackColor = System.Drawing.Color.LightBlue;
            this.grpService.Controls.Add(this.txtRemark);
            this.grpService.Controls.Add(this.radUrgent);
            this.grpService.Controls.Add(this.radNormal);
            this.grpService.Controls.Add(this.lblService);
            this.grpService.Controls.Add(this.cmbService);
            this.grpService.Controls.Add(this.lblRemark);
            this.grpService.Location = new System.Drawing.Point(75, 423);
            this.grpService.Name = "grpService";
            this.grpService.Size = new System.Drawing.Size(720, 205);
            this.grpService.TabIndex = 36;
            this.grpService.TabStop = false;
            this.grpService.Text = "Service Requested";
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(250, 139);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.PlaceholderText = "Laptop Model";
            this.txtRemark.Size = new System.Drawing.Size(343, 31);
            this.txtRemark.TabIndex = 17;
            // 
            // radUrgent
            // 
            this.radUrgent.AutoSize = true;
            this.radUrgent.Location = new System.Drawing.Point(471, 92);
            this.radUrgent.Name = "radUrgent";
            this.radUrgent.Size = new System.Drawing.Size(91, 29);
            this.radUrgent.TabIndex = 17;
            this.radUrgent.Text = "Urgent";
            this.radUrgent.UseVisualStyleBackColor = true;
            // 
            // radNormal
            // 
            this.radNormal.AutoSize = true;
            this.radNormal.Checked = true;
            this.radNormal.Location = new System.Drawing.Point(269, 92);
            this.radNormal.Name = "radNormal";
            this.radNormal.Size = new System.Drawing.Size(96, 29);
            this.radNormal.TabIndex = 16;
            this.radNormal.TabStop = true;
            this.radNormal.Text = "Normal";
            this.radNormal.UseVisualStyleBackColor = true;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(163, 42);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(67, 25);
            this.lblService.TabIndex = 15;
            this.lblService.Text = "Service";
            // 
            // cmbService
            // 
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Items.AddRange(new object[] {
            "Remove virus, malware or spyware",
            "Troubleshot and fix computer running slow",
            "Laptop screen replacement",
            "Laptop keyboard replacement",
            "Laptop battery replacement",
            "Operating System Format and Installation",
            "Data backup and recovery",
            "Internet connectivity issues"});
            this.cmbService.Location = new System.Drawing.Point(250, 39);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(343, 33);
            this.cmbService.TabIndex = 14;
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(163, 139);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(71, 25);
            this.lblRemark.TabIndex = 16;
            this.lblRemark.Text = "Remark";
            // 
            // lblSubTitle
            // 
            this.lblSubTitle.AutoSize = true;
            this.lblSubTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSubTitle.Location = new System.Drawing.Point(19, 8);
            this.lblSubTitle.Name = "lblSubTitle";
            this.lblSubTitle.Size = new System.Drawing.Size(181, 30);
            this.lblSubTitle.TabIndex = 39;
            this.lblSubTitle.Text = "Select Customer";
            // 
            // lvCustomer
            // 
            this.lvCustomer.BackColor = System.Drawing.SystemColors.Control;
            this.lvCustomer.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnCusID,
            this.columnName,
            this.columnEmail,
            this.columnTelNum});
            this.lvCustomer.FullRowSelect = true;
            this.lvCustomer.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.lvCustomer.Location = new System.Drawing.Point(19, 97);
            this.lvCustomer.MultiSelect = false;
            this.lvCustomer.Name = "lvCustomer";
            this.lvCustomer.Size = new System.Drawing.Size(720, 176);
            this.lvCustomer.TabIndex = 40;
            this.lvCustomer.UseCompatibleStateImageBehavior = false;
            this.lvCustomer.View = System.Windows.Forms.View.Details;
            // 
            // columnCusID
            // 
            this.columnCusID.Text = "Cus ID";
            this.columnCusID.Width = 150;
            // 
            // columnName
            // 
            this.columnName.Text = "Name";
            this.columnName.Width = 150;
            // 
            // columnEmail
            // 
            this.columnEmail.Text = "Email";
            this.columnEmail.Width = 220;
            // 
            // columnTelNum
            // 
            this.columnTelNum.Text = "Contact Number";
            this.columnTelNum.Width = 150;
            // 
            // panelSelectCus
            // 
            this.panelSelectCus.BackColor = System.Drawing.Color.LightBlue;
            this.panelSelectCus.Controls.Add(this.lblDescription);
            this.panelSelectCus.Controls.Add(this.lvCustomer);
            this.panelSelectCus.Controls.Add(this.lblSubTitle);
            this.panelSelectCus.Location = new System.Drawing.Point(56, 98);
            this.panelSelectCus.Name = "panelSelectCus";
            this.panelSelectCus.Size = new System.Drawing.Size(772, 554);
            this.panelSelectCus.TabIndex = 43;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDescription.Location = new System.Drawing.Point(27, 38);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(346, 38);
            this.lblDescription.TabIndex = 45;
            this.lblDescription.Text = "Please select the customer";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Salmon;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClear.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClear.Location = new System.Drawing.Point(247, 677);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(134, 50);
            this.btnClear.TabIndex = 44;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmRegExistCus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(889, 739);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.grpService);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.panelSelectCus);
            this.Name = "frmRegExistCus";
            this.Text = "Register Existing Customer";
            this.Load += new System.EventHandler(this.frmRegExistCus_Load);
            this.grpService.ResumeLayout(false);
            this.grpService.PerformLayout();
            this.panelSelectCus.ResumeLayout(false);
            this.panelSelectCus.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnBack;
        private Label lblTitle;
        private Button btnRegister;
        private GroupBox grpService;
        private TextBox txtRemark;
        private RadioButton radUrgent;
        private RadioButton radNormal;
        private Label lblService;
        private ComboBox cmbService;
        private Label lblRemark;
        private Label lblSubTitle;
        private ListView lvCustomer;
        private ColumnHeader columnCusID;
        private ColumnHeader columnName;
        private ColumnHeader columnEmail;
        private ColumnHeader columnTelNum;
        private Panel panelSelectCus;
        private Button btnClear;
        private Label lblDescription;
    }
}