﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class AdmReceptionist
    {
        private string RecpName;
        private string RecpNum;
        private string RecpEmail;
        private string RecpStreet;
        private string RecpCity;
        private string RecpState;
        private string RecpCode;
        private string RecpPic;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myG6"].ToString());

        public string RecpName1 { get => RecpName; set => RecpName = value; }
        public string RecpNum1 { get => RecpNum; set => RecpNum = value; }
        public string RecpEmail1 { get => RecpEmail; set => RecpEmail = value; }
        public string RecpAddress1 { get => RecpStreet; set => RecpStreet = value; }
        public string RecpCity1 { get => RecpCity; set => RecpCity = value; }
        public string RecpRegion1 { get => RecpState; set => RecpState = value; }
        public string RecpCode1 { get => RecpCode; set => RecpCode = value; }
        public string RecpPic1 { get => RecpPic; set => RecpPic = value; }

        public AdmReceptionist(string rName, string rNum, string rEmail, string rStreet, string rCity, string rState, string rPostcode)
        {
            RecpName = rName;
            RecpNum = rNum;
            RecpEmail = rEmail;
            RecpStreet = rStreet;
            RecpCity = rCity;
            RecpState = rState;
            RecpCode = rPostcode;
        }

        public AdmReceptionist(string rEmail)
        {
            RecpEmail = rEmail;
        }

        public string addReceptionist()
        {
            string status;
            con.Open();

            SqlCommand cmd = new SqlCommand("select count(*) from Receptionist where Email = @email", con);
            cmd.Parameters.AddWithValue("@email", RecpEmail);
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0) //Email already existed
                status = "Unable to register. Email already existed.";
            else
            {
                string default_pwd = "REC";
                var last4 = RecpNum.Substring(RecpNum.Length - 4, 4);
                default_pwd = default_pwd + last4;

                SqlCommand cmd2 = new SqlCommand("insert into Receptionist(Name, Email, TelNum, Street, City, State, Postcode, PicID) values(@name, @em, @num, @street, @city, @state, @postcode, 'PIC01')", con);
                SqlCommand cmd3 = new SqlCommand("insert into Login (Email, Pass, Role) values(@em, @def_pw, 'Receptionist')", con);

                cmd2.Parameters.AddWithValue("@name", RecpName);
                cmd2.Parameters.AddWithValue("@em", RecpEmail);
                cmd2.Parameters.AddWithValue("@num", RecpNum);
                cmd2.Parameters.AddWithValue("@street", RecpStreet);
                cmd2.Parameters.AddWithValue("@city", RecpCity);
                cmd2.Parameters.AddWithValue("@state", RecpState);
                cmd2.Parameters.AddWithValue("@postcode", RecpCode);
                cmd3.Parameters.AddWithValue("@em", RecpEmail);
                cmd3.Parameters.AddWithValue("@def_pw", default_pwd);

                int j = cmd2.ExecuteNonQuery();
                int i = cmd3.ExecuteNonQuery();
                if (j != 0 && i != 0)
                    status = "Registration Successful. \nThis is your default password: " + default_pwd;
                else
                    status = "Unable to register.";
            }
            con.Close();
            return status;

        }
    }
}
