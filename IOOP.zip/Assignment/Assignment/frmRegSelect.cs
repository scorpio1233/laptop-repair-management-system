﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class frmRegSelect : Form
    {
        public frmRegSelect()
        {
            InitializeComponent();
        }

        private void btnNewCus_Click(object sender, EventArgs e)
        {
            frmRegNewCus regnew = new frmRegNewCus();
            regnew.ShowDialog();
        }

        private void picNewCus_Click(object sender, EventArgs e)
        {
            frmRegNewCus regnew = new frmRegNewCus();
            regnew.ShowDialog();
        }

        private void btnExistCus_Click(object sender, EventArgs e)
        {
            frmRegExistCus regnew = new frmRegExistCus();
            regnew.ShowDialog();
        }

        private void picExistCus_Click(object sender, EventArgs e)
        {
            frmRegExistCus regnew = new frmRegExistCus();
            regnew.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
