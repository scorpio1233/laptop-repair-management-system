﻿namespace Assignment
{
    partial class frmAccRecovery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConfirm = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.cmbSecurityQ = new System.Windows.Forms.ComboBox();
            this.lblAns = new System.Windows.Forms.Label();
            this.lblSecurityQ = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtAns = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnConfirm.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnConfirm.Location = new System.Drawing.Point(356, 303);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(128, 44);
            this.btnConfirm.TabIndex = 20;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(160, 130);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PlaceholderText = "Enter your email here";
            this.txtEmail.Size = new System.Drawing.Size(385, 31);
            this.txtEmail.TabIndex = 19;
            // 
            // cmbSecurityQ
            // 
            this.cmbSecurityQ.FormattingEnabled = true;
            this.cmbSecurityQ.Items.AddRange(new object[] {
            "What is the name of your pet?",
            "What is your secondary school name?",
            "What is your favorite movie?",
            "What is your favorite song?",
            "Who is your favorite artist?"});
            this.cmbSecurityQ.Location = new System.Drawing.Point(246, 180);
            this.cmbSecurityQ.Name = "cmbSecurityQ";
            this.cmbSecurityQ.Size = new System.Drawing.Size(299, 33);
            this.cmbSecurityQ.TabIndex = 18;
            // 
            // lblAns
            // 
            this.lblAns.AutoSize = true;
            this.lblAns.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAns.Location = new System.Drawing.Point(70, 232);
            this.lblAns.Name = "lblAns";
            this.lblAns.Size = new System.Drawing.Size(84, 25);
            this.lblAns.TabIndex = 17;
            this.lblAns.Text = "Answer: ";
            // 
            // lblSecurityQ
            // 
            this.lblSecurityQ.AutoSize = true;
            this.lblSecurityQ.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSecurityQ.Location = new System.Drawing.Point(70, 180);
            this.lblSecurityQ.Name = "lblSecurityQ";
            this.lblSecurityQ.Size = new System.Drawing.Size(170, 25);
            this.lblSecurityQ.TabIndex = 16;
            this.lblSecurityQ.Text = "Security Question: ";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(77, 82);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(475, 25);
            this.lblDescription.TabIndex = 15;
            this.lblDescription.Text = "Please select your security question and enter your answer.";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(163, 22);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(289, 45);
            this.lblTitle.TabIndex = 14;
            this.lblTitle.Text = "Account Recovery";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DarkOrange;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClear.Location = new System.Drawing.Point(130, 303);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(129, 44);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtAns
            // 
            this.txtAns.Location = new System.Drawing.Point(160, 229);
            this.txtAns.Name = "txtAns";
            this.txtAns.PlaceholderText = "Enter your answer here";
            this.txtAns.Size = new System.Drawing.Size(385, 31);
            this.txtAns.TabIndex = 23;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblEmail.Location = new System.Drawing.Point(70, 130);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(65, 25);
            this.lblEmail.TabIndex = 22;
            this.lblEmail.Text = "Email: ";
            // 
            // frmAccRecovery
            // 
            this.AcceptButton = this.btnConfirm;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(614, 388);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.cmbSecurityQ);
            this.Controls.Add(this.lblAns);
            this.Controls.Add(this.lblSecurityQ);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.txtAns);
            this.Controls.Add(this.txtEmail);
            this.Name = "frmAccRecovery";
            this.Text = "Account Recovery";
            this.Load += new System.EventHandler(this.frmAccRecovery_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnConfirm;
        private TextBox txtEmail;
        private ComboBox cmbSecurityQ;
        private Label lblAns;
        private Label lblSecurityQ;
        private Label lblDescription;
        private Label lblTitle;
        private Button btnClear;
        private TextBox txtAns;
        private Label lblEmail;
    }
}