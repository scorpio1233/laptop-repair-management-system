﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class FrmServicing : Form
    {
        public static string orderId;
        public static string cusid;
        public static string cusname;
        public static string service;
        public static string laptop;
        public static string status;
        public static string refresh;

        public FrmServicing(string ordid, string idcus, string namecus, string serv, string lp, string sta)
        {
            InitializeComponent();
            orderId = ordid;
            cusid = idcus;
            cusname = namecus;
            service = serv;
            laptop = lp;
            status = sta;
        }

        private void btnBService_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDescribe_Click(object sender, EventArgs e)
        {
            FrmDescription form = new FrmDescription(orderId, cusid, cusname, service, laptop, status);
            form.Show();
            this.Close();
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (chkComplete.Checked == true)
            {
                job obj1 = new job(orderId);
                MessageBox.Show(obj1.updjob(orderId));
                FrmCollection form = new FrmCollection(orderId, cusid, cusname, service, laptop);
                form.Show();
                this.Close();
            }
            else
            {
                lblChk.Text = "*";
                MessageBox.Show("Please check on the field labelled * first");
            }
        }

        private void FrmServicing_Load(object sender, EventArgs e)
        {
            lblCusName.Text = cusname;
            lblLaptop.Text = laptop;
            lblService.Text = service;
            job obj1 = new job(orderId);
            string chk = obj1.getdesc(orderId);
            if (chk == "")
                lblDesc.Text = "No Description Added :(";
            else
                lblDesc.Text = "Description Added :)";
        }
    }
}
